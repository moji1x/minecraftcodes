﻿//
//это не моё, ну говнокод и говнокод чо бубнить то, кому надо переделает
//





Render['GradientSkeet'] = function (x, y, _0x42b4x1b, _0x42b4x1c, _0x42b4x1d, _0x42b4x1e, _0x42b4x1f) {
    Render.GradientRect(x, y, _0x42b4x1b / 4, _0x42b4x1c, _0x42b4x1d, _0x42b4x1f, _0x42b4x1e);
    Render.GradientRect(x + (_0x42b4x1b / 4), y, _0x42b4x1b / 4, _0x42b4x1c, _0x42b4x1d, _0x42b4x1e, _0x42b4x1f)
};
function calcDist(_0x42b4x21, _0x42b4x22) {
    var _0x42b4x23 = _0x42b4x21[0];
    var _0x42b4x24 = _0x42b4x21[1];
    var _0x42b4x25 = _0x42b4x21[2];
    var _0x42b4x26 = _0x42b4x22[0];
    var _0x42b4x27 = _0x42b4x22[1];
    var _0x42b4x28 = _0x42b4x22[2];
    var _0x42b4x29 = _0x42b4x23 - _0x42b4x26;
    var _0x42b4x2a = _0x42b4x24 - _0x42b4x27;
    var _0x42b4x2b = _0x42b4x25 - _0x42b4x28;
    return Math['sqrt'](_0x42b4x29 * _0x42b4x29 + _0x42b4x2a * _0x42b4x2a + _0x42b4x2b * _0x42b4x2b)
}
var x = Render.GetScreenSize()[0] / 115;
var y = Render.GetScreenSize()[1] / 1.13;
function getVelocity(_0x42b4x2f) {
    players = Entity.GetPlayers();
    for (i = 0; i < players['length']; i++) {;
    }; {
        var _0x42b4x30 = Entity.GetProp(_0x42b4x2f, 'CBasePlayer', 'm_vecVelocity[0]');
        var _0x42b4x31 = Math['sqrt'](_0x42b4x30[0] * _0x42b4x30[0] + _0x42b4x30[1] * _0x42b4x30[1])
    }
    return _0x42b4x31
}
var fill = 0;
var cur1 = Globals.Curtime();
function on_round_start() {
    on_plant_time = 0;
    fill = 0;
    planting = false;
    isbomb = 0
}
var bombtick = false;
var screen_size = Global.GetScreenSize();


//germany indicators boss
var menu = {};
var menu_elements = {};
const menu_spacer = "                                                                                  ";
/**
* Concats two elements into an array without increasing the array length.
* Prevents the memory leak in 2.0.0 from happening
*
* @param a {array}
* @param b {any}
*/
menu.concat = function(a, b)
{
    // Creates a new array.
    var arr = [];
    // Push all items from the array 'a' into our array.
    for (var c in a)
    {
        arr.push(a[c]);
    }
    // Push the value 'b' into our array.
    arr.push(b);
    // Return the new array.
    return arr;
}
/**
* Creates a new menu label
*
* @param label {string}
*/
menu.label = function(label)
{
    // Creates the label
    UI.AddLabel(label);
};
/**
* Creates a new menu element
*
* @param func {function}
* @param name {string}
* @param label {string},
* @param properties {array}
*/
menu.new = function(func, name, label, properties, initial_value)
{
    // Fix values
    properties = properties || [];
    initial_value = initial_value || undefined;
    // Get properties
    const final_name = name + menu_spacer + label;
    var final_props = [final_name];
    const element_info_t = {
        path: ["Misc", "JAVASCRIPT", "Script items", final_name],
        cache: initial_value,
        func: func
    };
    // If our properties aren't null, then pack them together.
    if (properties != null)
    {
        for (var i = 0; i < properties.length; i++)
        {
            final_props.push(properties[i]);
        }
    }
    // Create our menu element and return properties
    func.apply(null, final_props);
    // Initialize our menu element if it has an initializer.
    if (initial_value)
    {
        switch (func)
        {
            case UI.AddColorPicker:
                UI.SetColor.apply(null, this.concat(element_info_t.path, initial_value));
                break;
            case UI.AddHotkey:
                break;
            default:
                UI.SetValue.apply(this, this.concat(element_info_t.path, initial_value));
                break;
        }
    }
    menu_elements[label] = element_info_t;
    return element_info_t;
};
/**
* Creates a new menu reference
*
* @param path {array}
*/
menu.reference = function(path, func)
{
    return {
        path: path,
        func: func
    };
};
/**
* Gets the value of a menu element
*
* @param elem {array}
* @return {*}
*/
menu.get = function(elem)
{
    // If the element doesn't exist
    if (!(elem.path))
        throw new Error("[Menu] This element doesn't exist!");
    // Returns the element's value
    switch (elem.func)
    {
        case UI.AddColorPicker:
            return UI.GetColor.apply(null, elem.path);
        case UI.AddHotkey:
            return UI.IsHotkeyActive.apply(null, elem.path);
        default:
            return UI.GetValue.apply(null, elem.path);
    }
};
/**
* Sets the value of a menu element
*
* @param elem {array}
* @param value {*}
*/
menu.set = function(elem, value)
{
    // If the label doesn't exist
    if (!(elem.path))
        throw new Error("[Menu] This element doesn't exist!");
    // Set the element's value
    switch (elem.func)
    {
        case UI.AddColorPicker:
            UI.SetColor.apply(null, this.concat(elem.path, value));
            break;
        case UI.AddHotkey:
            if (menu.get(elem) !== value)
                UI.ToggleHotkey.apply(null, elem.path);
            break;
        default:
            UI.SetValue.apply(null, this.concat(elem.path, value));
            break;
    }
};
/**
* Changes the visibility of a menu elements
*
* @param elem {array}
* @param visible {boolean}
*/
menu.visibility = function(elem, visible)
{
    // If the label doesn't exist
    if (!(elem.path))
        throw new Error("[Menu] This element doesn't exist!");
    // Change the element's visibility
    UI.SetEnabled.apply(null, this.concat(elem.path, visible));
};
/**
* Adds an event to a menu element which is triggered everytime this element's value is changed.
*
* @param elem {array}
* @param func {function}
*/
menu.add_event = function(elem, func)
{
    if (!elem.path)
        throw new Error("[Menu] This element doesn't exist!");
    if (!elem.func)
        throw new Errror("[Menu] This element does not have a valid type. Please, specify one.");
    elem.callback = func;
}
/**
* Handles the menu elements' events. Call this inside a Draw or FSN callback.
*/
menu.handle_events = function()
{
    for (var label in menu_elements)
    {
        const elem = menu_elements[label];
        if (!elem.path || !elem.callback)
            continue;
        const value = menu.get(elem);
        if (elem.cache === undefined)
            elem.cache = value;
        if (elem.cache !== value)
        {
            elem.callback.apply(null, [elem]);
            elem.cache = value;
        }
    }
}
/**
* @brief Normalizes an yaw angle.
* @param angle {number}
* @returns {number}
*/
function normalize_yaw(angle)
{
    var adjusted_yaw = angle;
    if (adjusted_yaw < -180)
        adjusted_yaw += 360;
    if (adjusted_yaw > 180)
        adjusted_yaw -= 360;
    return adjusted_yaw;
}

Render['GradientSkeet'] = function (x, y, _0x42b4x1b, _0x42b4x1c, _0x42b4x1d, _0x42b4x1e, _0x42b4x1f) {
    Render.GradientRect(x, y, _0x42b4x1b / 4, _0x42b4x1c, _0x42b4x1d, _0x42b4x1f, _0x42b4x1e);
    Render.GradientRect(x + (_0x42b4x1b / 4), y, _0x42b4x1b / 4, _0x42b4x1c, _0x42b4x1d, _0x42b4x1e, _0x42b4x1f)
};
Render['Arc'] = function (x, y, _0x42b4x32, _0x42b4x33, _0x42b4x34, _0x42b4x35, _0x42b4x1e) {
    for (var _0x42b4xc = _0x42b4x34; _0x42b4xc < _0x42b4x34 + _0x42b4x35; _0x42b4xc++) {
        const _0x42b4xd = _0x42b4xc * Math['PI'] / 180;
        Render.Line(x + Math['cos'](_0x42b4xd) * _0x42b4x32, y + Math['sin'](_0x42b4xd) * _0x42b4x32, x + Math['cos'](_0x42b4xd) * _0x42b4x33, y + Math['sin'](_0x42b4xd) * _0x42b4x33, _0x42b4x1e)
    }
};
//endregion
//region menu
const voffset = menu.new(UI.AddSliderInt, "| Indicators vertical offset", "", [0, 1000]);
const ref_antiaim_enabled = menu.reference(["Anti-Aim", "Fake angles", "Enabled"]);
const ref_fakelag_enabled = menu.reference(["Anti-Aim", "Fake-Lag", "Enabled"]);
const ref_doubletap = menu.reference(["Rage", "GENERAL", "Exploits", "Doubletap"]);
const ref_doubletap_hk = menu.reference(["Rage", "GENERAL", "Exploits", "Doubletap"], UI.AddHotkey);
const ref_hideshots_hk = menu.reference(["Rage", "GENERAL", "Exploits", "Hide shots"], UI.AddHotkey);
//endregion
//region locals
var last_time = 0;
var planted = false;
var bombsite = -1;
var offset = 0;
const modules = [
    {
        //font = Render.AddFont('Calibri', 18, 900);
        //var _0x42b4x6c = Render.AddFont('Tahoma', 10, 100);
       
        label: "     ",
        condition: function() {
            return menu.get(ref_antiaim_enabled);
        },
        colors: {
            dormant: [255, 0, 0, 225],
            active: [132, 195, 16, 255]
        },
        logic: function() {
            const self = modules[0];
            const real = Local.GetRealYaw(), fake = Local.GetFakeYaw();
            const delta = Math.abs(normalize_yaw(real % 360 - fake % 360)) / 2;
            return delta / 60;
        },
        extra: function(x, y, color) {
            const real = Local.GetRealYaw(), fake = Local.GetFakeYaw();
            const delta = Math.abs(normalize_yaw(real % 360 - fake % 360)) / 2;
            const frac = delta / 60;
    fill = 3.3 - (3.3 + frac - delta);
    if (fill > 3.3) {
        fill = 3.3
    };     
            //var _0x42b4x66, _0x42b4x67, _0x42b4x68, _0x42b4x69, _0x42b4x6a, _0x42b4x6b;
            font = Render.AddFont('Calibri', 18, 900);
            //var _0x42b4x6c = Render.AddFont('Tahoma', 10, 100);
           
            Render.GradientSkeet(7, y - 85 + 70, 100, 30, 1, [0, 0, 0, 55], [0, 0, 0, 0]);
            Render.StringCustom(x-38, y - 14, 1, "FAKE", [ 0, 0, 0,255 ], font);
            Render.StringCustom(x-38, y - 15, 1, "FAKE", color, font);
        }
    },
   
];
//endregion
//region functions


function draw_indicators()
{
    const offset_y = menu.get(voffset);
    const y = Render.GetScreenSize()[1] - offset_y;
    const drawn = 0;
    for (var i = 0; i < modules.length; i++)
    {
        const mod = modules[i];
        if (!mod.condition()) continue;
        const result = mod.logic();
        const label_width = Render.TextSize(mod.label, 4)[0];
        const color = [
            mod.colors.dormant[0] + (mod.colors.active[0] - mod.colors.dormant[0]) * result,
            mod.colors.dormant[1] + (mod.colors.active[1] - mod.colors.dormant[1]) * result,
            mod.colors.dormant[2] + (mod.colors.active[2] - mod.colors.dormant[2]) * result,
            255
        ];
       // Render.GradientRect(15 + offset, y - 130 - 55 * drawn, label_width + 15, 45, 1, [10, 10, 10, 50], [10, 10, 10, 0]);
        Render.String(25 + offset, y - 125 - 55 * drawn, 0, mod.label, color, 4);
        if (mod.extra)
            mod.extra(40 + offset + label_width, y - 106 - 55 * drawn, color);
        drawn++;
    }
}
function on_draw() {
    const me = Entity.GetLocalPlayer();
    if (!me || !Entity.IsAlive(me))
        return;
    draw_indicators();
    draw_timer();
}


Cheat.RegisterCallback("Draw", "on_draw");
//endregion