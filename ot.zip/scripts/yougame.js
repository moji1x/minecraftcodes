
UI.AddSliderInt("", 0, 0);
UI.AddLabel("      Under crosshair indicator");
UI.AddLabel("")
UI.AddCheckbox("Anti-aim indication")
UI.AddDropdown("DT indication type",["no arc","yes arc!!"])
UI.AddHotkey("Minimum damage override")
UI.AddSliderInt("Heavy Pistol/desert eagle Mindmg", 0, 130)
UI.AddSliderInt("Scout Mindmg", 0, 130)
UI.AddSliderInt("AWP Mindmg", 0, 130)
UI.AddSliderInt("Auto Mindmg", 0, 130)
UI.AddSliderInt(" ", 0, 0);
//Get weapon damage 
heavy_cache = UI.GetValue("Rage", "HEAVY PISTOL", "Targeting", "Minimum damage")
scout_cache = UI.GetValue("Rage", "SCOUT", "Targeting", "Minimum damage")
awp_cache = UI.GetValue("Rage", "AWP", "Targeting", "Minimum damage")
auto_cache = UI.GetValue("Rage", "AUTOSNIPER", "Targeting", "Minimum damage")
//get screen size
screen_size = Global.GetScreenSize();
restore_values = false

function override_mindmg() {
   
   if (!UI.IsHotkeyActive("Script items", "Minimum damage override")) {
      if (restore_values) {
         restore_values = false
         UI.SetValue("Rage", "HEAVY PISTOL", "Targeting", "Minimum damage", heavy_cache)
         UI.SetValue("Rage", "SCOUT", "Targeting", "Minimum damage", scout_cache)
         UI.SetValue("Rage", "AWP", "Targeting", "Minimum damage", awp_cache)
         UI.SetValue("Rage", "AUTOSNIPER", "Targeting", "Minimum damage", auto_cache)

      } else {

         heavy_cache = UI.GetValue("Rage", "HEAVY PISTOL", "Targeting", "Minimum damage")
         scout_cache = UI.GetValue("Rage", "SCOUT", "Targeting", "Minimum damage")
         awp_cache = UI.GetValue("Rage", "AWP", "Targeting", "Minimum damage")
         auto_cache = UI.GetValue("Rage", "AUTOSNIPER", "Targeting", "Minimum damage")
      }
      return
   }


   restore_values = true
   
   heavy_value = UI.GetValue("Script items", "Heavy Pistol/desert eagle Mindmg")
   scout_value = UI.GetValue("Script items", "Scout Mindmg")
   awp_value = UI.GetValue("Script items", "AWP Mindmg")
   auto_value = UI.GetValue("Script items", "Auto Mindmg")
   weapon_name = Entity.GetName(Entity.GetWeapon(Entity.GetLocalPlayer()))

   if (weapon_name == "r8 revolver" || weapon_name == "desert eagle" || weapon_name == " 52>;L25@ r8" /* revolver on russian lang */) {
      UI.SetValue("Rage", "HEAVY PISTOL", "Targeting", "Minimum damage", heavy_value)

   }

   if (weapon_name == "ssg 08") {
      UI.SetValue("Rage", "SCOUT", "Targeting", "Minimum damage", scout_value)

   }

   if (weapon_name == "awp") {
      UI.SetValue("Rage", "AWP", "Targeting", "Minimum damage", awp_value)

   }

   if (weapon_name == "scar 20" || weapon_name == "g3sg1") {
      UI.SetValue("Rage", "AUTOSNIPER", "Targeting", "Minimum damage", auto_value)

   }
}


alpha_damage = 255
alpha_legit = 255
alpha_main = 255
alpha_anim = 255
alpha_duck = 255
alpha_anim_state = false
alpha_duck_state = false

//animation function

clamp = function (val, min, max) {
   if (val > max)
      return max
   if (min > val)
      return min
   return val
}

function indication() {
   if (World.GetServerString() == "")
      return;


   add_y = 109
   player = Entity.GetLocalPlayer()

   isDoubletap = UI.IsHotkeyActive("Rage", "Exploits", "Doubletap")
   isInverter = UI.IsHotkeyActive("Anti-Aim", "Fake angles", "Inverter")
   isHideShot = UI.IsHotkeyActive("Rage", "Exploits", "Hide shots")
   isDamageOverride = UI.IsHotkeyActive("Script items", "Minimum damage override")
   isForceBody = UI.IsHotkeyActive("Rage", "General", "Force body aim")
   isFakeDuck = UI.IsHotkeyActive("Anti-Aim", "Extra", "Fake duck")

   if (UI.GetValue("Anti-aim", "Extra", "Pitch") == 3) {
      isLegitAA = true
   } else {
      isLegitAA = false
   }


   //-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
   //animation

   fade_factor = ((1 / .15) * Globals.Frametime()) * 200
   fade_factor_anim = ((1 / .9) * Globals.Frametime()) * 200
   fade_factor_duck = ((1 / .1) * Globals.Frametime()) * 200

   //main
   //Dead animation
   if (!Entity.IsAlive(player) && alpha_main != 0)
      alpha_main = clamp(alpha_main - fade_factor, 0, 255)
   if (Entity.IsAlive(player) && alpha_main != 255)
      alpha_main = clamp(alpha_main + fade_factor, 0, 255)

   //buttons
   //Damage animation
   if (!isDamageOverride && alpha_damage != 0 || alpha_main != 255)
      alpha_damage = clamp(alpha_damage - fade_factor, 0, 255)

   if (isDamageOverride && alpha_damage != 255 && alpha_main == 255)
      alpha_damage = clamp(alpha_damage + fade_factor, 0, 255)
   //Legit AA animation
   if (!isLegitAA && alpha_legit != 0 || alpha_main != 255)
      alpha_legit = clamp(alpha_legit - fade_factor, 0, 255)

   if (isLegitAA && alpha_legit != 255 && alpha_main == 255)
      alpha_legit = clamp(alpha_legit + fade_factor, 0, 255)
   //ANIM/HIDE animation
   if (alpha_main != 255) {
      alpha_anim = clamp(alpha_anim - fade_factor, 0, 255)
   } else {
      if (alpha_anim_state == false) {
         alpha_anim = clamp(alpha_anim + fade_factor_anim, 0, 255)
         if (alpha_anim == 255)
            alpha_anim_state = true
      } else {
         alpha_anim = clamp(alpha_anim - fade_factor_anim, 0, 255)
         if (alpha_anim == 0)
            alpha_anim_state = false
      }
   }


   //Double Tap

   dt_color = [255, 0, 0, alpha_main]

   if (isDoubletap) {
      dt_color = [255 * (1.0 - Exploit.GetCharge()), 255 * Exploit.GetCharge(), 0, alpha_main]

   } else {
      
      dt_color = (isHideShot ? [250, 200, 27, alpha_main]: [255, 0, 0, alpha_main] )
      
   }

   //Damage indicator

   heavy_cur = UI.GetValue ("Rage", "HEAVY PISTOL", "Targeting", "Minimum damage")
   scout_cur = UI.GetValue ("Rage", "SCOUT", "Targeting", "Minimum damage")
   awp_cur = UI.GetValue   ("Rage", "AWP", "Targeting", "Minimum damage")
   auto_cur = UI.GetValue  ("Rage", "AUTOSNIPER", "Targeting", "Minimum damage")
   weapon_name = Entity.GetName(Entity.GetWeapon(Entity.GetLocalPlayer()));
   
      if(weapon_name == "r8 revolver" || weapon_name == "desert eagle" || weapon_name == " 52>;L25@ r8" || weapon_name == "ssg 08" || weapon_name == "awp" || weapon_name == "scar 20" || weapon_name == "g3sg1")
      {
      if (weapon_name == "r8 revolver" || weapon_name == "desert eagle" || weapon_name == " 52>;L25@ r8" /* revolver on russian lang */) {
         dmg_render = heavy_cur
      }
      if (weapon_name == "ssg 08") {
         dmg_render = scout_cur
      }
      if (weapon_name == "awp") {
         dmg_render = awp_cur
      }
      if (weapon_name == "scar 20" || weapon_name == "g3sg1") {
         dmg_render = auto_cur
      }
      } else {
         dmg_render = "-"
      }
   //render

   if (isInverter) {

      Render.String(screen_size[0] / 2 - 21, screen_size[1] / 2 + 30, 0, "DYNAMIC", [0, 0, 0, alpha_main], 3);
      Render.String(screen_size[0] / 2 - 21, screen_size[1] / 2 + 31, 0, "DYNAMIC", [89,119,241, alpha_main], 3);
   } else {
      Render.String(screen_size[0] / 2 - 21, screen_size[1] / 2 + 30, 0, "DYNAMIC", [0, 0, 0, alpha_main], 3);
      Render.String(screen_size[0] / 2 - 21, screen_size[1] / 2 + 31, 0, "DYNAMIC", [89, 119, 241, alpha_main], 3);
   }
   if (isForceBody) {
      Render.String(screen_size[0] / 2 - 13, screen_size[1] / 2 + 20, 0, "BODY", [0, 0, 0, alpha_main], 3);
      Render.String(screen_size[0] / 2 - 13, screen_size[1] / 2 + 21, 0, "BODY", [89, 119, 241, alpha_main], 3);
   } else {
      Render.String(screen_size[0] / 2 - 32, screen_size[1] / 2 + 20, 0, "YOUGAME YAW", [0, 0, 0, alpha_main], 3);
      Render.String(screen_size[0] / 2 - 32, screen_size[1] / 2 + 21, 0, "YOUGAME YAW", [89,119,241, alpha_main], 3);

   }
   Render.String(screen_size[0] / 2 - 7, screen_size[1] / 2 + 40, 0, "DT", [0, 0, 0, alpha_main], 3);
   Render.String(screen_size[0] / 2 - 7, screen_size[1] / 2 + 41, 0, "DT", dt_color, 3);

   if (alpha_damage > 0) {
      add_y = add_y + -58;
   }
   if (alpha_damage > 0) {
      Render.String(screen_size[0] / 2 + -7, screen_size[1] / 2 + 1 + add_y, 0, dmg_render.toString(), [0, 0, 0, alpha_damage], 3);
      Render.String(screen_size[0] / 2 + -7, screen_size[1] / 2 + add_y, 0, dmg_render.toString(), [255, 255, 255, alpha_damage], 3);
   }
   //--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
   
   
   
      if(UI.GetValue("DT indication type") == 1){
// i love to fuck you mom

   //render arc
    if (Exploit.GetCharge() < 1 && Entity.IsAlive(player)) {
        
   //971
        x = (screen_size[0] / 2 + -13)
        y = (screen_size[1] / 2 + 45)
        distance = 4.29
        inner_radius = 2.32
        segments = 23
        angle = 90;
        max_angle = 360 * Exploit.GetCharge();
        if (Exploit.GetCharge() <= 0.23076923191547394)
           max_angle = 0;

       render_arc(x, y, distance, inner_radius, -90, 360, segments, [0, 0, 0, 255]);
       render_arc(x, y, distance, inner_radius, -90, max_angle, segments, dt_color);



         function render_arc(x, y, radius, radius_inner, start_angle, end_angle, segments, dt_color) {
          while (360 % segments != 0) {
             segments++;
          }

          segments = 360 / segments;

          for (var i = start_angle; i < start_angle + end_angle; i = i + segments) {

             var rad = i * Math.PI / 180;
               var rad2 = (i + segments) * Math.PI / 180;

             var rad_cos = Math.cos(rad)
              var rad_sin = Math.sin(rad)

              var rad2_cos = Math.cos(rad2);
              var rad2_sin = Math.sin(rad2);

              var x1_outer = x + rad_cos * radius;
              var y1_outer = y + rad_sin * radius;

              var x2_outer = x + rad2_cos * radius;
             var y2_outer = y + rad2_sin * radius;

             var x1_inner = x + rad_cos * radius_inner;
             var y1_inner = y + rad_sin * radius_inner;

             var x2_inner = x + rad2_cos * radius_inner;
             var y2_inner = y + rad2_sin * radius_inner;

             Render.Polygon([
                [x1_outer, y1_outer],
                [x2_outer, y2_outer],
                [x1_inner, y1_inner]
             ],
                dt_color
             );

             Render.Polygon([
                  [x1_inner, y1_inner],
                  [x2_outer, y2_outer],
                 [x2_inner, y2_inner]
               ],
                  dt_color
             );
          }
         }
      }
   }
}

function menu_cb() {
   enabled = UI.GetValue("Script items", "Anti-aim indication");
   UI.SetEnabled("Script items", "Minimum damage override",               enabled);
   UI.SetEnabled("Script items", "Heavy Pistol/desert eagle Mindmg",      enabled);
	UI.SetEnabled("Script items", "Scout Mindmg",                          enabled);
	UI.SetEnabled("Script items", "AWP Mindmg",                            enabled);
   UI.SetEnabled("Script items", "Auto Mindmg",                           enabled);
   UI.SetEnabled("Script items", "DT indication type",                           enabled);
}
function unload()
{
   UI.SetValue("Rage", "HEAVY PISTOL", "Targeting", "Minimum damage", heavy_cache)
   UI.SetValue("Rage", "SCOUT", "Targeting", "Minimum damage",        scout_cache)
   UI.SetValue("Rage", "AWP", "Targeting", "Minimum damage",          awp_cache)
   UI.SetValue("Rage", "AUTOSNIPER", "Targeting", "Minimum damage",   auto_cache)
}
Cheat.RegisterCallback("Unload", "unload");
Global.RegisterCallback("Draw", "menu_cb")
Global.RegisterCallback("Draw", "indication")
Global.RegisterCallback("CreateMove", "override_mindmg")

UI.AddLabel("Keybinds, AA Ind, DT Ind, Watermark")
UI.AddLabel("")
//Watermark\\

UI.AddLabel("                   Watermark")
UI.AddCheckbox("Watermark")
var username = ""
UI.AddColorPicker("Theme color");
function waterdraw() {
	if (UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Watermark")) {
    if (!World.GetServerString()) return;
    var today = new Date();
    var hours1 = today.getHours();
    var minutes1 = today.getMinutes();
    var seconds1 = today.getSeconds();
    var hours = hours1 <= 9 ? "0" + today.getHours() + ":" : today.getHours() + ":";
    var minutes = minutes1 <= 9 ? "0" + today.getMinutes() + ":" : today.getMinutes() + ":";
    var seconds = seconds1 <= 9 ? "0" + today.getSeconds() : today.getSeconds();
    var serverip = World.GetServerString();
    var ping = Math.floor(Global.Latency() * 1000 / 1.5);
    var color = UI.GetColor("Misc", "JAVASCRIPT", "Script items", "Theme color");
    var font = Render.AddFont("Verdana", 7, 300);
    var text = "yougame [gay] | Yougame.biz | delay: " +Math.round(Entity.GetProp(Entity.GetLocalPlayer(), "CPlayerResource", "m_iPing")).toString()+ "ms | " +Globals.Tickrate().toString()+ "tick | " + hours + minutes + seconds;
    var h = 18;
    var w = Render.TextSizeCustom(text, font)[0] + 8;
    var x = Global.GetScreenSize()[0];
    var y = 10;
    x = x - w - 10;

    Render.FilledRect(x, y, w, 2, [color[0], color[1], color[2], color[3]]);
    Render.FilledRect(x, y + 0, w, h, [17, 17, 17, 50]);

    Render.StringCustom(x + 4, y + 4, 0, text, [255, 255, 255, 255], font);
	}
}
Cheat.RegisterCallback("Draw", "waterdraw");

//Hotkeys\\

UI.AddLabel("                   Hotkeys            ");
const x1 = UI.AddSliderInt("Hotkeys_x", 0, Global.GetScreenSize()[0]);
const y1 = UI.AddSliderInt("Hotkeys_y", 0, Global.GetScreenSize()[1]);
UI.AddColorPicker("Hotkeys");
var colorhotkeys = UI.GetColor("Misc", "JAVASCRIPT", "Script items", "Hotkeys");
if (colorhotkeys[3] == 0) {
    UI.SetColor("Misc", "JAVASCRIPT", "Script items", "Hotkeys", [89, 119, 239, 3]);
}
var alpha = 0;
var maxwidth = 0;
var swalpha = 0;
var fdalpha = 0;
var apalpha = 0;
var aialpha = 0;
var spalpha = 0;
var fbalpha = 0;
var dtalpha = 0;
var hsalpha = 0;
var doalpha = 0;
var textalpha = 0;
var h = new Array();

function in_bounds(vec, x, y, x2, y2) {
    return (vec[0] > x) && (vec[1] > y) && (vec[0] < x2) && (vec[1] < y2)
}

function main_hotkeys() {
        if (!World.GetServerString()) return;
        const x = UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Hotkeys_x"),
            y = UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Hotkeys_y");
        colorhotkeys = UI.GetColor("Misc", "JAVASCRIPT", "Script items", "Hotkeys");
        var font = Render.AddFont("Verdana", 7, 100);
        var frames = 8 * Globals.Frametime();
        var width = 75;
        var maxwidth = 0;
        if (UI.IsHotkeyActive("Anti-Aim", "Extra", "Slow walk")) {
            swalpha = Math.min(swalpha + frames, 1);
        } else {
            swalpha = swalpha - frames;
            if (swalpha < 0) swalpha = 0;
            if (swalpha == 0) {
                h.splice(h.indexOf("Slow motion"));
            }
        }

        if (UI.IsHotkeyActive("Anti-Aim", "Extra", "Fake duck")) {
            fdalpha = Math.min(fdalpha + frames, 1);
        } else {
            fdalpha = fdalpha - frames;
            if (fdalpha < 0) fdalpha = 0;
            if (fdalpha == 0) {
                h.splice(h.indexOf("Duck peek assist"));
            }
        }

        if (UI.IsHotkeyActive("Misc", "GENERAL", "Movement", "Auto peek")) {
            apalpha = Math.min(apalpha + frames, 1);
        } else {
            apalpha = apalpha - frames;
            if (apalpha < 0) apalpha = 0;
            if (apalpha == 0) {
                h.splice(h.indexOf("Quick peek"));
            }
        }

        if (UI.IsHotkeyActive("Anti-Aim", "Fake angles", "Inverter")) {
            aialpha = Math.min(aialpha + frames, 1);
        } else {
            aialpha = aialpha - frames;
            if (aialpha < 0) aialpha = 0;
            if (aialpha == 0) {
                h.splice(h.indexOf("Anti-aim inverter"));
            }
        }

        if (UI.IsHotkeyActive("Anti-Aim", "Fake angles", "Inverter")) {
            aialpha = Math.min(aialpha + frames, 1);
        } else {
            aialpha = aialpha - frames;
            if (aialpha < 0) aialpha = 0;
            if (aialpha == 0) {
                h.splice(h.indexOf("Inverter"));
            }
        }

        if (UI.IsHotkeyActive("Rage", "GENERAL", "General", "Force safe point")) {
            spalpha = Math.min(spalpha + frames, 1);
        } else {
            spalpha = spalpha - frames;
            if (spalpha < 0) spalpha = 0;
            if (spalpha == 0) {
                h.splice(h.indexOf("Safe point override"));
            }
        }

        if (UI.IsHotkeyActive("Rage", "GENERAL", "General", "Force body aim")) {
            fbalpha = Math.min(fbalpha + frames, 1);
        } else {
            fbalpha = fbalpha - frames;
            if (fbalpha < 0) fbalpha = 0;
            if (fbalpha == 0) {
                h.splice(h.indexOf("Force body aim"));
            }
        }

        if (UI.IsHotkeyActive("Rage", "Exploits", "Doubletap")) {
            dtalpha = Math.min(dtalpha + frames, 1);
        } else {
            dtalpha = dtalpha - frames;
            if (dtalpha < 0) dtalpha = 0;
            if (dtalpha == 0) {
                h.splice(h.indexOf("Double tap"));
            }
        }

        if (UI.IsHotkeyActive("Rage", "Exploits", "Hide shots")) {
            hsalpha = Math.min(hsalpha + frames, 1);
        } else {
            hsalpha = hsalpha - frames;
            if (hsalpha < 0) hsalpha = 0;
            if (hsalpha == 0) {
                h.splice(h.indexOf("On shot anti-aim"));
            }
        }

        if (UI.IsHotkeyActive("Script items", "Minimum Damage Override")) {
            doalpha = Math.min(doalpha + frames, 1);
        } else {
            doalpha = doalpha - frames;
            if (doalpha < 0) doalpha = 0;
            if (doalpha == 0) {
                h.splice(h.indexOf("Damage override"));
            }
        }

        if (UI.IsHotkeyActive("Anti-Aim", "Extra", "Slow walk")) {
            if (h.indexOf("Slow motion") == -1)
                h.push("Slow motion")
        }
        if (UI.IsHotkeyActive("Anti-Aim", "Extra", "Fake duck")) {
            if (h.indexOf("Duck peek assist") == -1)
                h.push("Duck peek assist")
        }
        if (UI.IsHotkeyActive("Misc", "GENERAL", "Movement", "Auto peek")) {
            if (h.indexOf("Quick peek") == -1)
                h.push("Quick peek")
        }
        if (UI.IsHotkeyActive("Anti-Aim", "Fake angles", "Inverter")) {
            if (h.indexOf("Anti-aim inverter") == -1)
                h.push("Anti-aim inverter")
        }
        if (UI.IsHotkeyActive("Rage", "GENERAL", "General", "Force safe point")) {
            if (h.indexOf("Safe point override") == -1)
                h.push("Safe point override")
        }
        if (UI.IsHotkeyActive("Rage", "GENERAL", "General", "Force body aim")) {
            if (h.indexOf("Force body aim") == -1)
                h.push("Force body aim")
        }
        if (UI.IsHotkeyActive("Rage", "Exploits", "Doubletap")) {
            if (h.indexOf("Double tap") == -1)
                h.push("Double tap")
        }
        if (UI.IsHotkeyActive("Rage", "Exploits", "Hide shots")) {
            if (h.indexOf("On shot anti-aim") == -1)
                h.push("On shot anti-aim")
        }
        if (UI.IsHotkeyActive("Script items", "Minimum Damage Override")) {
            if (h.indexOf("Damage override") == -1)
                h.push("Damage override")
        }

        if (h.length > 0) {
            alpha = Math.min(alpha + frames, 1);
        } else {
            alpha = alpha - frames;
            if (alpha < 0) alpha = 0;
        }
        for (i = 0; i < h.length; i++) {
            if (Render.TextSizeCustom(h[i], font)[0] > maxwidth) {
                maxwidth = Render.TextSizeCustom(h[i], font)[0];
            }
        }
        if (maxwidth == 0) maxwidth = 50;
        width = width + maxwidth;
        if (alpha > 0) {
                Render.FilledRect(x, y + 3, width, 2, [colorhotkeys[0], colorhotkeys[1], colorhotkeys[2], alpha * 255]);
                Render.FilledRect(x, y + 5, width, 18, [17, 17, 17, alpha * 50]);
                Render.StringCustom(x + width / 2 - (Render.TextSizeCustom("keybindings", font)[0] / 2) + 2, y + 9, 0, "keybindings", [0, 0, 0, alpha * 255 / 1.3], font);
                Render.StringCustom(x + width / 2 - (Render.TextSizeCustom("keybindings", font)[0] / 2) + 1, y + 8, 0, "keybindings", [255, 255, 255, alpha * 255], font);
                //Render.FilledRect(x, y + 23, width, 18 * h.length, [17, 17, 17, Math.min(colorhotkeys[3], alpha * 255)]);
                for (i = 0; i < h.length; i++) {
                    switch (h[i]) {
                        case 'Slow motion':
                            Render.FilledRect(x, y + 23 + 18 * i, width, 18, [17, 17, 17, Math.min(colorhotkeys[3], Math.min(swalpha * 255, colorhotkeys[3]))]);
                            Render.StringCustom(x + 3, y + 26 + 18 * i, 0, h[i], [0, 0, 0, swalpha * 255 / 1.3], font);
                            Render.StringCustom(x + 2, y + 26 + 18 * i, 0, h[i], [255, 255, 255, swalpha * 255], font);

                            Render.StringCustom(x - 3 + width - Render.TextSizeCustom("[holding]", font)[0], y + 26 + 18 * i, 0, "[holding]", [0, 0, 0, swalpha * 255 / 1.3], font);
                            Render.StringCustom(x - 2 + width - Render.TextSizeCustom("[holding]", font)[0], y + 26 + 18 * i, 0, "[holding]", [255, 255, 255, swalpha * 255], font);
                            break;
                        case 'Duck peek assist':
                            Render.FilledRect(x, y + 23 + 18 * i, width, 18, [17, 17, 17, Math.min(colorhotkeys[3], Math.min(fdalpha * 255, colorhotkeys[3]))]);
                            Render.StringCustom(x + 3, y + 26 + 18 * i, 0, h[i], [0, 0, 0, fdalpha * 255 / 1.3], font);
                            Render.StringCustom(x + 2, y + 26 + 18 * i, 0, h[i], [255, 255, 255, fdalpha * 255], font);

                            Render.StringCustom(x - 3 + width - Render.TextSizeCustom("[holding]", font)[0], y + 26 + 18 * i, 0, "[holding]", [0, 0, 0, fdalpha * 255 / 1.3], font);
                            Render.StringCustom(x - 2 + width - Render.TextSizeCustom("[holding]", font)[0], y + 26 + 18 * i, 0, "[holding]", [255, 255, 255, fdalpha * 255], font);
                            break;
                        case 'Quick peek':
                            Render.FilledRect(x, y + 23 + 18 * i, width, 18, [17, 17, 17, Math.min(colorhotkeys[3], Math.min(apalpha * 255, colorhotkeys[3]))]);
                            Render.StringCustom(x + 3, y + 26 + 18 * i, 0, h[i], [0, 0, 0, apalpha * 255 / 1.3], font);
                            Render.StringCustom(x + 2, y + 26 + 18 * i, 0, h[i], [255, 255, 255, apalpha * 255], font);

                            Render.StringCustom(x - 3 + width - Render.TextSizeCustom("[holding]", font)[0], y + 26 + 18 * i, 0, "[holding]", [0, 0, 0, apalpha * 255 / 1.3], font);
                            Render.StringCustom(x - 2 + width - Render.TextSizeCustom("[holding]", font)[0], y + 26 + 18 * i, 0, "[holding]", [255, 255, 255, apalpha * 255], font);
                            break;
                        case 'Anti-aim inverter':
                            Render.FilledRect(x, y + 23 + 18 * i, width, 18, [17, 17, 17, Math.min(colorhotkeys[3], Math.min(aialpha * 255, colorhotkeys[3]))]);
                            Render.StringCustom(x + 3, y + 26 + 18 * i, 0, h[i], [0, 0, 0, aialpha * 255 / 1.3], font);
                            Render.StringCustom(x + 2, y + 26 + 18 * i, 0, h[i], [255, 255, 255, aialpha * 255], font);

                            Render.StringCustom(x - 3 + width - Render.TextSizeCustom("[toggled]", font)[0], y + 26 + 18 * i, 0, "[toggled]", [0, 0, 0, aialpha * 255 / 1.3], font);
                            Render.StringCustom(x - 2 + width - Render.TextSizeCustom("[toggled]", font)[0], y + 26 + 18 * i, 0, "[toggled]", [255, 255, 255, aialpha * 255], font);
                            break;
                        case 'Safe point override':
                            Render.FilledRect(x, y + 23 + 18 * i, width, 18, [17, 17, 17, Math.min(colorhotkeys[3], Math.min(spalpha * 255, colorhotkeys[3]))]);
                            Render.StringCustom(x + 3, y + 26 + 18 * i, 0, h[i], [0, 0, 0, spalpha * 255 / 1.3], font);
                            Render.StringCustom(x + 2, y + 26 + 18 * i, 0, h[i], [255, 255, 255, spalpha * 255], font);

                            Render.StringCustom(x - 3 + width - Render.TextSizeCustom("[toggled]", font)[0], y + 26 + 18 * i, 0, "[toggled]", [0, 0, 0, spalpha * 255 / 1.3], font);
                            Render.StringCustom(x - 2 + width - Render.TextSizeCustom("[toggled]", font)[0], y + 26 + 18 * i, 0, "[toggled]", [255, 255, 255, spalpha * 255], font);
                            break;
                        case 'Force body aim':
                            Render.FilledRect(x, y + 23 + 18 * i, width, 18, [17, 17, 17, Math.min(colorhotkeys[3], Math.min(fbalpha * 255, colorhotkeys[3]))]);
                            Render.StringCustom(x + 3, y + 26 + 18 * i, 0, h[i], [0, 0, 0, fbalpha * 255 / 1.3], font);
                            Render.StringCustom(x + 2, y + 26 + 18 * i, 0, h[i], [255, 255, 255, fbalpha * 255], font);

                            Render.StringCustom(x - 3 + width - Render.TextSizeCustom("[holding]", font)[0], y + 26 + 18 * i, 0, "[holding]", [0, 0, 0, fbalpha * 255 / 1.3], font);
                            Render.StringCustom(x - 2 + width - Render.TextSizeCustom("[holding]", font)[0], y + 26 + 18 * i, 0, "[holding]", [255, 255, 255, fbalpha * 255], font);
                            break;
                        case 'Double tap':
                            Render.FilledRect(x, y + 23 + 18 * i, width, 18, [17, 17, 17, Math.min(colorhotkeys[3], Math.min(dtalpha * 255, colorhotkeys[3]))]);
                            Render.StringCustom(x + 3, y + 26 + 18 * i, 0, h[i], [0, 0, 0, dtalpha * 255 / 1.3], font);
                            Render.StringCustom(x + 2, y + 26 + 18 * i, 0, h[i], [255, 255, 255, dtalpha * 255], font);

                            Render.StringCustom(x - 3 + width - Render.TextSizeCustom("[toggled]", font)[0], y + 26 + 18 * i, 0, "[toggled]", [0, 0, 0, dtalpha * 255 / 1.3], font);
                            Render.StringCustom(x - 2 + width - Render.TextSizeCustom("[toggled]", font)[0], y + 26 + 18 * i, 0, "[toggled]", [255, 255, 255, dtalpha * 255], font);
                            break;
                        case 'On shot anti-aim':
                            Render.FilledRect(x, y + 23 + 18 * i, width, 18, [17, 17, 17, Math.min(colorhotkeys[3], Math.min(hsalpha * 255, colorhotkeys[3]))]);
                            Render.StringCustom(x + 3, y + 26 + 18 * i, 0, h[i], [0, 0, 0, hsalpha * 255 / 1.3], font);
                            Render.StringCustom(x + 2, y + 26 + 18 * i, 0, h[i], [255, 255, 255, hsalpha * 255], font);

                            Render.StringCustom(x - 3 + width - Render.TextSizeCustom("[holding]", font)[0], y + 26 + 18 * i, 0, "[holding]", [0, 0, 0, hsalpha * 255 / 1.3], font);
                            Render.StringCustom(x - 2 + width - Render.TextSizeCustom("[holding]", font)[0], y + 26 + 18 * i, 0, "[holding]", [255, 255, 255, hsalpha * 255], font);
                            break;
                        case 'Damage override':
                            Render.FilledRect(x, y + 23 + 18 * i, width, 18, [17, 17, 17, Math.min(colorhotkeys[3], Math.min(doalpha * 255, colorhotkeys[3]))]);
                            Render.StringCustom(x + 3, y + 26 + 18 * i, 0, h[i], [0, 0, 0, doalpha * 255 / 1.3], font);
                            Render.StringCustom(x + 2, y + 26 + 18 * i, 0, h[i], [255, 255, 255, doalpha * 255], font);

                            Render.StringCustom(x - 3 + width - Render.TextSizeCustom("[holding]", font)[0], y + 26 + 18 * i, 0, "[holding]", [0, 0, 0, doalpha * 255 / 1.3], font);
                            Render.StringCustom(x - 2 + width - Render.TextSizeCustom("[holding]", font)[0], y + 26 + 18 * i, 0, "[holding]", [255, 255, 255, doalpha * 255], font);
                            break;
                    }

                }
        }
        if (Global.IsKeyPressed(1) && UI.IsMenuOpen()) {
            const mouse_pos = Global.GetCursorPosition();
            if (in_bounds(mouse_pos, x, y, x + width, y + 30)) {
                UI.SetValue("Misc", "JAVASCRIPT", "Script items", "Hotkeys_x", mouse_pos[0] - width / 2);
                UI.SetValue("Misc", "JAVASCRIPT", "Script items", "Hotkeys_y", mouse_pos[1] - 20);
            }
        }
}
Global.RegisterCallback("Draw", "main_hotkeys")

// dt ind 

function get_icon(a) {
    var letter = ""
    switch (a) {
        case "desert eagle":
            letter = "a"
            break
        case "dual berettas":
            letter = "b"
            break
        case "five seven":
            letter = "c"
            break
        case "glock 18":
            letter = "d"
            break
        case "ak 47":
            letter = "e"
            break
        case "aug":
            letter = "f"
            break
        case "awp":
            letter = "g"
            break
        case "famas":
            letter = "h"
            break
        case "m249":
            letter = "i"
            break
        case "g3sg1":
            letter = "j"
            break
        case "galil ar":
            letter = "k"
            break
        case "m4a4":
            letter = "l"
            break
        case "m4a1 s":
            letter = "m"
            break
        case "mac 10":
            letter = "n"
            break
        case "p2000":
            letter = "o"
            break
        case "mp5 sd":
            letter = "p"
            break
        case "ump 45":
            letter = "q"
            break
        case "xm1014":
            letter = "r"
            break
        case "pp bizon":
            letter = "s"
            break
        case "mag 7":
            letter = "t"
            break
        case "negev":
            letter = "u"
            break
        case "sawed off":
            letter = "v"
            break
        case "tec 9":
            letter = "w"
            break
        case "zeus x27":
            letter = "x"
            break
        case "p250":
            letter = "y"
            break
        case "mp7":
            letter = "z"
            break
        case "mp9":
            letter = "A"
            break
        case "nova":
            letter = "B"
            break
        case "p90":
            letter = "C"
            break
        case "scar 20":
            letter = "D"
            break
        case "sg 553":
            letter = "E"
            break
        case "ssg 08":
            letter = "F"
            break
        case "knife":
            letter = "G"
            break
        case "flashbang":
            letter = "H"
            break
        case "high explosive grenade":
            letter = "I"
            break
        case "smoke grenade":
            letter = "J"
            break
        case "molotov":
            letter = "K"
            break
        case "decoy grenade":
            letter = "L"
            break
        case "incendiary grenade":
            letter = "M"
            break
        case "c4 explosive":
            letter = "N"
            break
        case "usp s":
            letter = "P"
            break
        case "cz75 auto":
            letter = "Q"
            break
        case "r8 revolver":
            letter = "R"
            break
        case "bayonet":
            letter = "V"
            break
        case "flip knife":
            letter = "W"
            break
        case "gut knife":
            letter = "X"
            break
        case "karambit":
            letter = "Y"
            break
        case "m9 bayonet":
            letter = "Z"
            break
        case "falchion knife":
            letter = "1"
            break
        case "bowie knife":
            letter = "2"
            break
        case "butterfly knife":
            letter = "3"
            break
        case "shadow daggers":
            letter = "4"
            break
        case "ursus knife":
            letter = "5"
            break
        case "navaja knife":
            letter = "6"
            break
        case "stiletto knife":
            letter = "7"
            break
        case "skeleton knife":
            letter = "8"
            break
        case "huntsman knife":
            letter = "0"
            break
        case "talon knife":
            letter = "8"
            break
        case "classic knife":
            letter = "25"
            break
        case "paracord knife":
            letter = "Z"
            break
        case "survival knife":
            letter = "Z"
            break
        case "nomad knife":
            letter = "Z"
            break
        default:
            letter = ""
            break
    }
    return letter
}

UI.AddLabel("                   Tickbase            ");
UI.AddSliderInt("Tickbase_x", 0, Global.GetScreenSize()[0]);
UI.AddSliderInt("Tickbase_y", 0, Global.GetScreenSize()[1]);

function in_bounds(vec, x, y, x2, y2) {
    return (vec[0] > x) && (vec[1] > y) && (vec[0] < x2) && (vec[1] < y2)
}
var fa = 0;
var sa = 0;

function main_dt() {
    if (!World.GetServerString()) return;

    const x = UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Tickbase_x"),
        y = UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Tickbase_y");

    localplayer_index = Entity.GetLocalPlayer();
    localplayer_weapon = Entity.GetWeapon(localplayer_index);
    weapon_name = Entity.GetName(localplayer_weapon);
    g_Local_classname = Entity.GetClassName(localplayer_weapon);
    var nextattack = Entity.GetProp(localplayer_weapon, "CBaseCombatWeapon", "m_flNextPrimaryAttack");
    var CanShoot = false;
    if (nextattack <= Globals.Curtime()) {
        CanShoot = true;
    }

    var frames = 8 * Globals.Frametime();

    var font = Render.AddFont("Verdana", 7, 100);
    var fontbullet = Render.AddFont("bullet", 18, 100);
    if (CanShoot && Exploit.GetCharge() == 1 && UI.IsHotkeyActive("Rage", "Exploits", "Doubletap")) {
        var text = "DT [v3.5 debug] | tickbase(v): 18";
        var color = [89, 119, 239, 255];
    } else if (CanShoot && Exploit.GetCharge() == 1 && UI.IsHotkeyActive("Rage", "Exploits", "Hide shots")) {
        var text = "DT [v3.5 debug] | tickbase(v): 7";
        var color = [89, 119, 239, 255];
    } else {
        var text = "DT [v3.5 debug] | tickbase(v): 0";
        var color = [89, 89, 89, 255];
    }
    var w = Render.TextSizeCustom(text, font)[0] + 8;

    Render.FilledRect(x, y, w, 2, color);
    Render.FilledRect(x, y + 2, w, 18, [17, 17, 17, 50]);
    Render.StringCustom(x + 5, y + 5, 0, text, [0, 0, 0, 180], font);
    Render.StringCustom(x + 4, y + 4, 0, text, [255, 255, 255, 255], font);

    Render.String(x + 4, y + 22, 0, get_icon(weapon_name), [255, 255, 255, 255], 5);
    if ((g_Local_classname == "CKnife" || g_Local_classname == "CWeaponSSG08" || g_Local_classname == "CWeaponAWP" || weapon_name == "r8 revolver" || g_Local_classname == "CHEGrenade" || g_Local_classname == "CMolotovGrenade" || g_Local_classname == "CIncendiaryGrenade" || g_Local_classname == "CFlashbang" || g_Local_classname == "CSmokeGrenade" || g_Local_classname == "CDecoyGrenade" || g_Local_classname == "CWeaponTaser" || g_Local_classname == "CC4")) {
        //return
    } else {
        if (CanShoot) {
            fa = Math.min(fa + frames, 1);
            Render.StringCustom(x + 10 + Render.TextSize(get_icon(weapon_name), 5)[0], y + 18, 0, "A", [255, 255, 255, fa * 255], fontbullet);
        } else {
            fa = 0;
        }
        if (CanShoot && Exploit.GetCharge() == 1 && UI.IsHotkeyActive("Rage", "Exploits", "Doubletap")) {
            sa = Math.min(sa + frames, 1);
            Render.StringCustom(x + 30 + Render.TextSize(get_icon(weapon_name), 5)[0], y + 18, 0, "A", [255, 255, 255, sa * 255], fontbullet);
        } else {
            sa = 0;
        }
    }


    if (Global.IsKeyPressed(1) && UI.IsMenuOpen()) {
        const mouse_pos = Global.GetCursorPosition();
        if (in_bounds(mouse_pos, x, y, x + w, y + 30)) {
            UI.SetValue("Misc", "JAVASCRIPT", "Script items", "Tickbase_x", mouse_pos[0] - w / 2);
            UI.SetValue("Misc", "JAVASCRIPT", "Script items", "Tickbase_y", mouse_pos[1] - 20);
        }
    }
}
Global.RegisterCallback("Draw", "main_dt");

// dt ind

//Anti-aims
UI.AddLabel("                   Antiaim            ");
UI.AddSliderInt("Antiaim_x", 0, Global.GetScreenSize()[0]);
UI.AddSliderInt("Antiaim_y", 0, Global.GetScreenSize()[1]);

function in_bounds(vec, x, y, x2, y2) {
    return (vec[0] > x) && (vec[1] > y) && (vec[0] < x2) && (vec[1] < y2)
}

function draw_arc(x, y, radius, start_angle, percent, thickness, color) {
        var precision = (2 * Math.PI) / 30;
        var step = Math.PI / 180;
        var inner = radius - thickness;
        var end_angle = (start_angle + percent) * step;
        var start_angle = (start_angle * Math.PI) / 180;

        for (; radius > inner; --radius) {
            for (var angle = start_angle; angle < end_angle; angle += precision) {
                var cx = Math.round(x + radius * Math.cos(angle));
                var cy = Math.round(y + radius * Math.sin(angle));

                var cx2 = Math.round(x + radius * Math.cos(angle + precision));
                var cy2 = Math.round(y + radius * Math.sin(angle + precision));

                Render.Line(cx, cy, cx2, cy2, color);
            }
        }
}

function main_aa() {
    if (!World.GetServerString()) return;

    const x = UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Antiaim_x"),
        y = UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Antiaim_y");

    var font = Render.AddFont("Verdana", 7, 100);
    var RealYaw = Local.GetRealYaw();
    var FakeYaw = Local.GetFakeYaw();
    var delta = Math.min(Math.abs(RealYaw - FakeYaw) / 2, 60).toFixed(1);
    var safety = Math.min(Math.round(1.7 * Math.abs(delta)), 100);
    if (UI.IsHotkeyActive("Anti-Aim", "Fake angles", "Inverter")) {
        var side = "<";
    } else {
        var side = ">";
    }
    var text = "    FAKE (" + delta.toString() + "  ) | safety: " + safety.toString() + "% | side: " + side;
    var w = Render.TextSizeCustom(text, font)[0] + 8;

    Render.FilledRect(x - w, y, w, 2, [89, 89 + (delta / 2), 89 + (delta / 0.4), 255]);
    Render.FilledRect(x - w, y + 2, w, 18, [17, 17, 17, 50]);
    Render.StringCustom(x + 5 - w, y + 5, 0, text, [0, 0, 0, 180], font);
    Render.StringCustom(x + 4 - w, y + 4, 0, text, [255, 255, 255, 255], font);
    Render.Circle(x + 18 - w + Render.TextSizeCustom("FAKE (" + delta.toString(), font)[0], y + 8, 1, [255, 255, 255, 255]);
    draw_arc(x + 7 - w, y + 10, 5, 0, delta * 6, 2, [89, 119, 239, 255]);
    if (Global.IsKeyPressed(1) && UI.IsMenuOpen()) {
        const mouse_pos = Global.GetCursorPosition();
        if (in_bounds(mouse_pos, x - w, y, x + w, y + 30)) {
            UI.SetValue("Misc", "JAVASCRIPT", "Script items", "Antiaim_x", mouse_pos[0] + w / 2);
            UI.SetValue("Misc", "JAVASCRIPT", "Script items", "Antiaim_y", mouse_pos[1] - 20);
        }
    }
}
Global.RegisterCallback("Draw", "main_aa");

// anti aims

UI.AddSliderInt(" ", 0, 0);
UI.AddLabel("Low delta, anti bf, Jump scout and co")
UI.AddLabel("")
var jitter_cache = UI.GetValue("Anti-Aim", "Rage Anti-Aim", "Jitter offset")
var yaw_cache = UI.GetValue("Anti-Aim", "Rage Anti-Aim", "Yaw offset")
UI.AddCheckbox("Low delta");

function Safe_Head()
{
    localplayer_index = Entity.GetLocalPlayer( );


        if (UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Low delta") && UI.IsHotkeyActive("Anti-Aim", "Extra", "Slow walk"))
        {
            UI.SetValue("Anti-Aim", "Rage Anti-Aim", "Yaw offset", 10);
            UI.SetValue("Anti-Aim", "Rage Anti-Aim", "Jitter offset", 0);
            AntiAim.SetOverride(1);
            AntiAim.SetFakeOffset(0);
            AntiAim.SetRealOffset(-30);
        }
        else
        {
            UI.SetValue("Anti-Aim", "Rage Anti-Aim", "Jitter offset", jitter_cache);
            AntiAim.SetOverride(0);
        }
}

function Main()
{
    Cheat.RegisterCallback("CreateMove", "Safe_Head");
}
Main();
// anti brute force
UI.AddLabel("")
UI.AddDropdown("Anti Bruteforce", ["Off", "On Hit", "On Shot"]);
function GetScriptOption(name)
{
    var Value = UI.GetValue("Misc", "JAVASCRIPT", "Script items", name);
    return Value;
}

function radian(degree)
{
    return degree * Math.PI / 180.0;
}

function ExtendVector(vector, angle, extension)
{
    var radianAngle = radian(angle);
    return [extension * Math.cos(radianAngle) + vector[0], extension * Math.sin(radianAngle) + vector[1], vector[2]];
}

function VectorAdd(a, b)
{
    return [a[0] + b[0], a[1] + b[1], a[2] + b[2]];
}

function VectorSubtract(a, b)
{
    return [a[0] - b[0], a[1] - b[1], a[2] - b[2]];
}

function VectorMultiply(a, b)
{
    return [a[0] * b[0], a[1] * b[1], a[2] * b[2]];
}

function VectorLength(x, y, z)
{
    return Math.sqrt(x * x + y * y + z * z);
}

function VectorNormalize(vec)
{
    var length = VectorLength(vec[0], vec[1], vec[2]);
    return [vec[0] / length, vec[1] / length, vec[2] / length];
}

function VectorDot(a, b)
{
    return a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
}

function VectorDistance(a, b)
{
    return VectorLength(a[0] - b[0], a[1] - b[1], a[2] - b[2]);
}

function ClosestPointOnRay(target, rayStart, rayEnd)
{
    var to = VectorSubtract(target, rayStart);
    var dir = VectorSubtract(rayEnd, rayStart);
    var length = VectorLength(dir[0], dir[1], dir[2]);
    dir = VectorNormalize(dir);

    var rangeAlong = VectorDot(dir, to);
    if (rangeAlong < 0.0)
    {
        return rayStart;
    }
    if (rangeAlong > length)
    {
        return rayEnd;
    }
    return VectorAdd(rayStart, VectorMultiply(dir, [rangeAlong, rangeAlong, rangeAlong]));
}

function Flip()
{
    UI.ToggleHotkey("Anti-Aim", "Fake angles", "Inverter");
}

var lastHitTime = 0.0;
var lastImpactTimes =
[
    0.0
];
var lastImpacts =
[
    [0.0, 0.0, 0.0]
];

function OnHurt()
{
    if (GetScriptOption("Anti Bruteforce") == 0) return;
    if (Entity.GetEntityFromUserID(Event.GetInt("userid")) !== Entity.GetLocalPlayer()) return;
    var hitbox = Event.GetInt('hitgroup');

    if (hitbox == 1 || hitbox == 6 || hitbox == 7)  //head, both toe
    {
        var curtime = Global.Curtime();
        if (Math.abs(lastHitTime - curtime) > 0.5)   //0.2s backtrack + 0.2 extand + 0.1 extra
        {
            lastHitTime = curtime;
            Flip();
        }
    }
}

function OnBulletImpact()
{
    if (GetScriptOption("Anti Bruteforce") !== 2) return;

    var curtime = Global.Curtime();
    if (Math.abs(lastHitTime - curtime) < 0.5) return;

    var entity = Entity.GetEntityFromUserID(Event.GetInt("userid"));
    var impact = [Event.GetFloat("x"), Event.GetFloat("y"), Event.GetFloat("z"), curtime];
    var source;
    if (Entity.IsValid(entity) && Entity.IsEnemy(entity))
    {
        if (!Entity.IsDormant(entity))
        {
            source = Entity.GetEyePosition(entity);
        }
        else if (Math.abs(lastImpactTimes[entity] - curtime) < 0.1)
        {
            source = lastImpacts[entity];
        }
        else
        {
            lastImpacts[entity] = impact;
            lastImpactTimes[entity] = curtime;
            return;
        }
        var local = Entity.GetLocalPlayer();
        var localEye = Entity.GetEyePosition(local);
        var localOrigin = Entity.GetProp(local, "CBaseEntity", "m_vecOrigin");
        var localBody = VectorMultiply(VectorAdd(localEye, localOrigin), [0.5, 0.5, 0.5]);

        var bodyVec = ClosestPointOnRay(localBody, source, impact);
        var bodyDist = VectorDistance(localBody, bodyVec);
        
        if (bodyDist < 85.0)       //he clearly shot at us!
        {
            var realAngle = Local.GetRealYaw();
            var fakeAngle = Local.GetFakeYaw();

            var headVec = ClosestPointOnRay(localEye, source, impact);
            var headDist = VectorDistance(localEye, headVec);
            var feetVec = ClosestPointOnRay(localOrigin, source, impact);
            var feetDist = VectorDistance(localOrigin, feetVec);

            var closestRayPoint;
            var realPos;
            var fakePos;

            if (bodyDist < headDist && bodyDist < feetDist)     //that's a pelvis
            {                                                   //pelvis direction = goalfeetyaw + 180       
                closestRayPoint = bodyVec;
                realPos = ExtendVector(bodyVec, realAngle + 180.0, 10.0);
                fakePos = ExtendVector(bodyVec, fakeAngle + 180.0, 10.0);
            }
            else if (feetDist < headDist)                       //ow my toe
            {                                                   //toe direction = goalfeetyaw -30 +- 90
                closestRayPoint = feetVec;
                var realPos1 = ExtendVector(bodyVec, realAngle - 30.0 + 60.0, 10.0);
                var realPos2 = ExtendVector(bodyVec, realAngle - 30.0 - 60.0, 10.0);
                var fakePos1 = ExtendVector(bodyVec, fakeAngle - 30.0 + 60.0, 10.0);
                var fakePos2 = ExtendVector(bodyVec, fakeAngle - 30.0 - 60.0, 10.0);
                if (VectorDistance(feetVec, realPos1) < VectorDistance(feetVec, realPos2))
                {
                    realPos = realPos1;
                }
                else
                {
                    realPos = realPos2;
                }
                if (VectorDistance(feetVec, fakePos1) < VectorDistance(feetVec, fakePos2))
                {
                    fakePos = fakePos1;
                }
                else
                {
                    fakePos = fakePos2;
                }
            }
            else                                                //ow my head i feel like i slept for 2 days
            {
                closestRayPoint = headVec;
                realPos = ExtendVector(bodyVec, realAngle, 10.0);
                fakePos = ExtendVector(bodyVec, fakeAngle, 10.0);
            }

            if (VectorDistance(closestRayPoint, fakePos) < VectorDistance(closestRayPoint, realPos))        //they shot at our fake. they will probably not gonna shoot it again.
            {
                lastHitTime = curtime;
                Flip();
            }
        }

        lastImpacts[entity] = impact;
        lastImpactTimes[entity] = curtime;
    }
}

Cheat.RegisterCallback("player_hurt", "OnHurt");
Cheat.RegisterCallback("bullet_impact", "OnBulletImpact");

// Scout on jump lol \\

UI.AddLabel("");

var oldHitChance = UI.GetValue("Rage", "SCOUT", "Accuracy", "Hitchance");
var oldAccBoost = UI.GetValue("Rage", "SCOUT", "Accuracy", "Accuracy boost");

UI.AddCheckbox("Jumpscout Hitchance");
UI.AddSliderInt("Hitchance", 1, 100);
UI.AddSliderInt("Accuracy Boost", 1, 100);

var isInAir = function(){
if(Global.IsKeyPressed((0x20))){
return true;
}else{
return false;
}
}

function updateValues(){
if(isInAir()){
var Hitchance = UI.GetValue("Script Items","Hitchance");
var AccuracyBoost = UI.GetValue("Script Items", "Accuracy Boost");
UI.SetValue("Rage", "SCOUT", "Accuracy", "Hitchance", Hitchance);
UI.SetValue("Rage", "SCOUT", "Accuracy", "Accuracy boost", AccuracyBoost);
}else{
UI.SetValue("Rage", "SCOUT", "Accuracy", "Hitchance", oldHitChance);
UI.SetValue("Rage", "SCOUT", "Accuracy", "Accuracy boost", oldAccBoost);
}
}

Global.RegisterCallback("CreateMove", "updateValues");

// nigga granade
//By 0xc0666 aka fallen#4008
UI.AddLabel("")
UI.AddCheckbox("Disable player on grenade")
UI.AddSliderInt
function disable()
{
var g_Local = Entity.GetLocalPlayer( );
var g_Local_weapon = Entity.GetWeapon(g_Local);
var weapon_name = Entity.GetName(g_Local_weapon);
var g_Local_classname = Entity.GetClassName( g_Local_weapon );

if (UI.GetValue( "Misc", "JAVASCRIPT", "Script items", "Disable player on grenade") && ( g_Local_classname == "CHEGrenade" || g_Local_classname == "CMolotovGrenade" || g_Local_classname == "CIncendiaryGrenade" || g_Local_classname == "CFlashbang" || g_Local_classname == "CSmokeGrenade" || g_Local_classname == "CDecoyGrenade" ))
           {
            UI.SetValue("Visual", "SELF", "Chams", "Visible override", true )
            UI.SetValue("Visual", "SELF", "Chams", "Visible transparency", "99")
           }
    else
           {
            UI.SetValue("Visual", "SELF", "Chams", "Visible override", false )
            UI.SetValue("Visual", "SELF", "Chams", "Visible transparency", "0")
           }
}

Cheat.RegisterCallback("Draw","disable")

// custom scope
UI.AddLabel("")
const global_choked_commands = Globals.ChokedCommands, global_realtime = Globals.Realtime, global_frametime = Globals.Frametime, global_curtime = Globals.Curtime, global_tick_interval = Globals.TickInterval, global_tickrate = Globals.Tickrate, global_tickcount = Globals.Tickcount, global_frame_stage = Globals.FrameStage, ui_get_menu_position = UI.GetMenuPosition, ui_update_list = UI.UpdateList, ui_remove_item = UI.RemoveItem, ui_get_hotkey = UI.GetHotkey, ui_set_hotkey_state = UI.SetHotkeyState, ui_get_hotkey_state = UI.GetHotkeyState, ui_toggle_hotkey = UI.ToggleHotkey, ui_set_color = UI.SetColor, ui_add_sub_tab = UI.AddSubTab, ui_add_textbox = UI.AddTextbox, ui_add_color_picker = UI.AddColorPicker, ui_add_multi_dropdown = UI.AddMultiDropdown, ui_add_dropdown = UI.AddDropdown, ui_add_hotkey = UI.AddHotkey, ui_add_slider_float = UI.AddSliderFloat, ui_add_slider_int = UI.AddSliderInt, ui_add_checkbox = UI.AddCheckbox, ui_set_value = UI.SetValue, ui_get_children = UI.GetChildren, ui_get_value = UI.GetValue, ui_get_string = UI.GetString, ui_get_color = UI.GetColor, ui_is_menu_open = UI.IsMenuOpen, ui_set_enabled = UI.SetEnabled, entity_draw_flag = Entity.DrawFlag, entity_get_ccs_weapon_info = Entity.GetCCSWeaponInfo, entity_get_render_box = Entity.GetRenderBox, entity_get_weapons = Entity.GetWeapons, entity_get_entities_by_class_id = Entity.GetEntitiesByClassID, entity_get_hitbox_position = Entity.GetHitboxPosition, entity_get_eye_position = Entity.GeteyePosition, entity_get_game_rules_proxy = Entity.GetGameRulesProxy, entity_is_bot = Entity.IsBot, entity_get_weapon = Entity.GetWeapon, entity_set_prop = Entity.SetProp, entity_get_prop = Entity.GetProp, entity_get_render_origin = Entity.GetRenderOrigin, entity_get_name = Entity.GetName, entity_get_class_name = Entity.GetClassName, entity_get_class_id = Entity.GetClassID, entity_is_dormant = Entity.IsDormant, entity_is_alive = Entity.IsAlive, entity_is_valid = Entity.IsValid, entity_is_local_player = Entity.IsLocalPlayer, entity_is_enemy = Entity.IsEnemy, entity_is_teammate = Entity.IsTeammate, entity_get_entity_from_user_id = Entity.GetEntityFromUserID, entity_get_local_player = Entity.GetLocalPlayer, entity_get_teammates = Entity.GetTeammates, entity_get_enemies = Entity.GetEnemies, entity_get_players = Entity.GetPlayers, entity_get_entities = Entity.GetEntities, render_text_size = Render.TextSize, render_string = Render.String, render_filled_circle = Render.FilledCircle, render_textured_rect = Render.TexturedRect, render_add_texture = Render.AddTexture, render_find_font = Render.FindFont, render_add_font = Render.AddFont, render_polygon = Render.Polygon, render_gradient_rect = Render.GradientRect, render_get_screen_size = Render.GetScreenSize, render_world_to_screen = Render.WorldToScreen, render_circle = Render.Circle, render_filled_rect = Render.FilledRect, render_rect = Render.Rect, render_line = Render.Line, convar_set_string = Convar.SetString, convar_get_string = Convar.GetString, convar_set_float = Convar.SetFloat, convar_get_float = Convar.GetFloat, convar_set_int = Convar.SetInt, convar_get_int = Convar.GetInt, event_get_string = Event.GetString, event_get_float = Event.GetFloat, event_get_int = Event.GetInt, trace_raw_line = Trace.RawLine, trace_smoke = Trace.Smoke, trace_bullet = Trace.Bullet, trace_line = Trace.Line, usercmd_get_movement = UserCMD.GetMovement, usercmd_set_view_angles = UserCMD.SetViewAngles, usercmd_send = UserCMD.Send, usercmd_choke = UserCMD.Choke, usercmd_set_buttons = UserCMD.SetButtons, usercmd_get_buttons = UserCMD.GetButtons, usercmd_set_movement = UserCMD.SetMovement, sound_stop_microphone = Sound.StopMicrophone, sound_play_microphone = Sound.PlayMicrophone, sound_play = Sound.Play, local_get_inaccuracy = Local.GetInaccuracy, local_get_spread = Local.GetSpread, local_get_fake_yaw = Local.GetFakeYaw, local_get_real_yaw = Local.GetRealYaw, local_set_clan_tag = Local.SetClanTag, local_set_view_angles = Local.SetViewAngles, local_get_view_angles = Local.GetViewAngles, local_latency = Local.Latency, cheat_is_legit_config_active = Cheat.IsLegitConfigActive, cheat_is_rage_config_active = Cheat.IsRageConfigActive, cheat_get_username = Cheat.GetUsername, cheat_print_chat = Cheat.PrintChat, cheat_register_callback = Cheat.RegisterCallback, cheat_execute_command = Cheat.ExecuteCommand, cheat_print_color = Cheat.PrintColor, cheat_print = Cheat.Print, input_force_cursor = Input.ForceCursor, input_get_cursor_position = Input.GetCursorPosition, input_is_key_pressed = Input.IsKeyPressed, world_get_server_string = World.GetServerString, world_get_map_name = World.GetMapName, antiaim_set_lby_offset = AntiAim.SetLBYOffset, antiaim_set_real_offset = AntiAim.SetRealOffset, antiaim_set_fake_offset = AntiAim.SetFakeOffset, antiaim_get_override = AntiAim.GetOverride, antiaim_set_override = AntiAim.SetOverride, exploit_override_tolerance = Exploit.OverrideTolerance, exploit_override_shift = Exploit.OverrideShift, exploit_enable_recharge = Exploit.EnableRecharge, exploit_disable_recharge = Exploit.DisableRecharge, exploit_recharge = Exploit.Recharge, exploit_get_charge = Exploit.GetCharge, ragebot_get_targets = Ragebot.GetTargets, ragebot_ignore_target = Ragebot.IgnoreTarget, ragebot_force_hitbox_safety = Ragebot.ForceHitboxSafety, ragebot_force_target_minimum_damage = Ragebot.ForceTargetMinimumDamage, ragebot_force_target_hitchance = Ragebot.ForceTargetHitchance, ragebot_force_target_safety = Ragebot.ForceTargetSafety, ragebot_force_target = Ragebot.ForceTarget, ragebot_get_target = Ragebot.GetTarget, material_refresh = Material.Refresh, material_set_key_value = Material.SetKeyValue, material_get = Material.Get, material_destroy = Material.Destroy, material_create = Material.Create;

var screen_size = render_get_screen_size();
var sv_cheats_cache = 0;
var removals_cache = 0;

UI.AddCheckbox("Custom scope lines");
UI.AddColorPicker("Scope lines color");
UI.AddSliderInt("Scope lines height", 0, 500);
UI.AddSliderInt("Scope lines offset", 0, 500);

function get_weapon(entity) {
    if (entity_get_name(entity_get_weapon(entity)) == 'g3sg1' || entity_get_name(entity_get_weapon(entity)) == 'scar 20') return 'auto';
    else if (entity_get_name(entity_get_weapon(entity)) == 'awp') return 'awp';
    else if (entity_get_name(entity_get_weapon(entity)) == 'desert eagle') return 'deagle';
    else if (entity_get_name(entity_get_weapon(entity)) == 'r8 revolver') return 'revolver';
    else if (entity_get_name(entity_get_weapon(entity)) == 'ssg 08') return 'scout';
    else return 'other';
}

function set_dropdown_value(value, index, enable) /*credits to ed*/ {
    var mask = 1 << index;
    return enable ? (value | mask) : (value & ~mask);
}

function draw() {
    var local_player = entity_get_local_player();

    if (entity_is_alive(local_player)) {
        if (ui_get_value("Misc", "JAVASCRIPT", "Script items", "Custom scope lines")) {
            var scoped = entity_get_prop(local_player, "CCSPlayer", "m_bIsScoped");
            var offset = ui_get_value("Misc", "JAVASCRIPT", "Script items", "Scope lines offset");
            var height = ui_get_value("Misc", "JAVASCRIPT", "Script items", "Scope lines height");
            var color = ui_get_color("Misc", "JAVASCRIPT", "Script items", "Scope lines color");
            sv_cheats_cache = ui_get_value("Misc.", "GENERAL", "Miscellaneous", "Force sv_cheats");
            removals_cache = ui_get_value("Visual", "WORLD", "Entities", "Removals");
            if (scoped) {
                if (get_weapon(local_player) == "auto" || get_weapon(local_player) == "awp" || get_weapon(local_player) == "scout") {
                    ui_set_value("Misc.", "GENERAL", "Miscellaneous", "Force sv_cheats", 1);
                    convar_set_float("r_drawvgui", 0);
                    ui_set_value("Visual", "WORLD", "Entities", "Removals", set_dropdown_value(removals_cache, 2, false));
                    render_gradient_rect(screen_size[0] / 2 + offset, screen_size[1] / 2, height, 1, 1, [color[0], color[1], color[2], color[3]], [color[0], color[1], color[2], 0]);
                    render_gradient_rect(screen_size[0] / 2 - height - offset, screen_size[1] / 2, height, 1, 1, [color[0], color[1], color[2], 0], [color[0], color[1], color[2], color[3]]);
                    render_gradient_rect(screen_size[0] / 2, screen_size[1] / 2 + offset, 1, height, 0, [color[0], color[1], color[2], color[3]], [color[0], color[1], color[2], 0]);
                    render_gradient_rect(screen_size[0] / 2, screen_size[1] / 2 - height - offset, 1, height, 0, [color[0], color[1], color[2], 0], [color[0], color[1], color[2], color[3]]);
                }
            } if (!scoped) {
                convar_set_float("r_drawvgui", 1);
                ui_set_value("Misc.", "GENERAL", "Miscellaneous", "Force sv_cheats", 1);
                ui_set_value("Visual", "WORLD", "Entities", "Removals", set_dropdown_value(removals_cache, 2, true));
            }
        }
    } else {
        convar_set_float("r_drawvgui", 1);
    }
}

function unload() {
    convar_set_float("r_drawvgui", 1);
    ui_set_value("Visual", "WORLD", "Entities", "Removals", set_dropdown_value(removals_cache, 2, true));
    ui_set_value("Misc.", "GENERAL", "Miscellaneous", "Force sv_cheats", sv_cheats_cache);
}

cheat_register_callback("Unload", "unload");
cheat_register_callback("Draw", "draw");

// custom scope

// trail bro

UI.AddLabel("")

var trails = [];

function rgb(speed) {
    var timer = Global.Tickcount();
    var result = [0, 0, 0, 255];

    result[0] = Math.floor(Math.sin(timer * speed + 0) * 127 + 128);
    result[1] = Math.floor(Math.sin(timer * speed + 2) * 127 + 128);
    result[2] = Math.floor(Math.sin(timer * speed + 4) * 127 + 128);
    return result;
}

function trail() {
    var localPlayer = Entity.GetLocalPlayer();
    if (Entity.IsValid(localPlayer)){
        var position = Entity.GetHitboxPosition(localPlayer, 6);
        if(Array.isArray(position)){
            trails.push({remove:Global.Tickcount() + UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Trail timer"), location:position});

            trails.forEach(function(x, y){
                var location = trails[y]["location"];
                var rainbow = rgb(UI.GetValue("Misc", "JAVASCRIPT", "Script items", "RGB Speed")/500);
                rainbow[3] = 50;
                if (!UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Trail RGB")) {
                    var color = UI.GetColor("Misc", "JAVASCRIPT", "Script items", "Trail color");
                    rainbow = color;
                }
                var position = Render.WorldToScreen([location[0], location[1], location[2]-50.0]);
                Render.FilledRect(position[0], position[1], 15, 15, rainbow);

                var time = Global.Tickcount();
                if (trails[y]["remove"] <= time){
                    trails.splice(y, 1);
                }
            })
        }
    }
}

function init(){
    Global.RegisterCallback("Draw", "trail");
    UI.AddCheckbox('Trail RGB');
    UI.AddSliderInt("RGB Speed", 1, 100);
    UI.AddColorPicker("Trail color");
    UI.AddSliderInt("Trail timer", 1, 500);

}

init();

// trail end bro