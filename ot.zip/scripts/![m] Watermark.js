const screen_size = Global.GetScreenSize();

UI.AddLabel("==Watermark==");

UI.AddCheckbox("Watermark");

UI.AddColorPicker("Watermark color");

UI.AddSliderInt("Watermark X", 0, screen_size[0]);

UI.AddSliderInt("Watermark Y", 0, screen_size[1]);

//---------------------------------------------MENU INTERFACE---------------------------------------------//


function interface() {

    if (UI.GetValue("Script items", "Watermark")) {

        UI.SetEnabled("Script Items", "Watermark color", true)

        UI.SetEnabled("Script Items", "Watermark X", true)

        UI.SetEnabled("Script Items", "Watermark Y", true)

    }
    else {

        UI.SetEnabled("Script Items", "Watermark color", false)

        UI.SetEnabled("Script Items", "Watermark X", false)

        UI.SetEnabled("Script Items", "Watermark Y", false)

    }

}

function menuopen() {
    if (UI.IsMenuOpen() == true) {
        interface();
    }
}

Cheat.RegisterCallback("Draw", "menuopen")
//---------------------------------------------MENU INTERFACE---------------------------------------------//

function main()
{
    if (!UI.GetValue("MISC", "JAVASCRIPT", "Script Items", "Watermark")) return;

  var watermark_name = Entity.GetName(Entity.GetLocalPlayer( ));
  var today = new Date();
  var hours1 = today.getHours();
  var minutes1 = today.getMinutes();
  var seconds1 = today.getSeconds();
  var localplayer_index = Entity.GetLocalPlayer();
  var velocity = Entity.GetProp(localplayer_index, "CBasePlayer", "m_vecVelocity[0]");
  var speed = Math.sqrt(velocity[0] * velocity[0] + velocity[1] * velocity[1]);
  var finalspeed = Math.min( 9999, speed ) + 0.2
  var hours = hours1 <= 9 ? "0" + today.getHours() + ":" : today.getHours() + ":";
  var minutes = minutes1 <= 9 ? "0" + today.getMinutes() + ":" : today.getMinutes() + ":";
  var seconds = seconds1 <= 9 ? "0" + today.getSeconds() : today.getSeconds()    ;
  const tickrate = Globals.Tickrate();
   const ping = Math.floor(Global.Latency() * 1000 / 1.5);
   const fps = Math.floor( 1 / Global.Frametime() );
   const fontpixel = Render.AddFont( "Verdana", 7, 100);
   const fontpixel2 = Render.AddFont( "Verdana", 10, 100);

   var watercolor = UI.GetColor("Misc", "JAVASCRIPT", "Script items", "Watermark color"); 

    const x = UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Watermark X"),
          y = UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Watermark Y");



function HSVtoRGB(h, s, v)
{
    if (!UI.GetValue("MISC", "JAVASCRIPT", "Script Items", "Watermark")) return;

    var r, g, b, i, f, p, q, t;

    i = Math.floor(h * 6);
  f = h * 6 - i;
    p = v * (1 - s);
    q = v * (1 - f * s);
    t = v * (1 - (1 - f) * s);

    switch (i % 6)
    {
        case 0: r = v, g = t, b = p; break;
        case 1: r = q, g = v, b = p; break;
        case 2: r = p, g = v, b = t; break;
        case 3: r = p, g = q, b = v; break;
        case 4: r = t, g = p, b = v; break;
        case 5: r = v, g = p, b = q; break;
    }

    return { r: Math.round(r * 255), g: Math.round(g * 255), b: Math.round(b * 255) };
}
    Render.GradientRect(x + 4, y + 10, 107, 60, 0, [watercolor[0], watercolor[1], watercolor[2], watercolor[3]], [65, 65, 175, 0]);
    Render.FilledRect(x, y + 5, 115, 70, [15, 15, 15, 155]);
    Render.FilledRect(x + 6, y + 12, 103, 57, [15, 15, 15, 255]);
    Render.Rect(x, y + 5, 115, 70, [15, 15, 15, 255]);
    Render.StringCustom(x + 13, y + 13, 0, "  game      ", [255, 255, 255, 255], fontpixel2);
    Render.StringCustom(x + 14, y + 13, 0, "         sense      ", [watercolor[0], watercolor[1], watercolor[2], watercolor[3]], fontpixel2);
    Render.StringCustom(x + 13, y + 42, 0, "     delay: " + ping + "ms      ", [255, 255, 255, 255], fontpixel);
    Render.StringCustom(x + 13, y + 30, 0, "         " + tickrate + " tick           ", [255, 255, 255, 255], fontpixel);
    Render.StringCustom(x + 9, y + 54, 0, "         " + hours + minutes + seconds+ "      ", [255, 255, 255, 255], fontpixel);

}

Global.RegisterCallback("Draw", "main")