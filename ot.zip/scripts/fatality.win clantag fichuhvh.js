UI.AddDropdown( "Custom ClanTag", [ "Disabled", "fatality.win clantag by fichuhvh. self coded btw."] );
UI.AddSliderInt( "Custom ClanTag Speed", 1, 10 );
var lasttime = 0;
function onRender( )
{
    var tag = UI.GetValue( "Script Items", "Custom ClanTag" );
    var speed = UI.GetValue( "Script Items", "Custom ClanTag Speed" );
    var time = parseInt((Globals.Curtime() * speed))
    if (time != lasttime)
    {
        if(tag == 0) { Local.SetClanTag(""); }
        if(tag == 1)
            {
            switch((time) % 56)
            {
            case 1: { Local.SetClanTag(" "); break; }
            case 2: { Local.SetClanTag(""); break; }
            case 3: { Local.SetClanTag(" "); break; }
            case 4: { Local.SetClanTag("f "); break; }
            case 5: { Local.SetClanTag("fa "); break; }
            case 6: { Local.SetClanTag("fat "); break; }
            case 7: { Local.SetClanTag("fata "); break; }
            case 8: { Local.SetClanTag("fatal "); break; }
            case 9: { Local.SetClanTag("fatali "); break; }
            case 10: { Local.SetClanTag("fatalit "); break; }
            case 11: { Local.SetClanTag("fatality "); break; }
            }
        }
    }
    lasttime = time;
}
Cheat.RegisterCallback("Draw", "onRender");