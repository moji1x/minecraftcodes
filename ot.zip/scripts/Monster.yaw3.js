UI.AddLabel("****************************************");
UI.AddLabel("Welcome in my js ALL")
UI.AddLabel(" PRIVTE Load dt speed ")
UI.AddLabel("load PRIVTE dobule tap torerance ")
UI.AddLabel("Load PRIVTE dobule tap Recharge ")
UI.AddLabel("Load PRIVET AA")
UI.AddLabel("Load Other")
UI.AddLabel("****************************************");
UI.AddLabel("****************************************");


UI.AddLabel(" Category double tap")
UI.AddSliderInt("Double tap tolerance", 0, 3);

function can_shift_shot(ticks_to_shift) {
    var me = Entity.GetLocalPlayer();
    var wpn = Entity.GetWeapon(me);

    if (me == null || wpn == null)
        return false;

    var tickbase = Entity.GetProp(me, "CCSPlayer", "m_nTickBase");
    var curtime = Globals.TickInterval() * (tickbase-ticks_to_shift)

    if (curtime < Entity.GetProp(me, "CCSPlayer", "m_flNextAttack"))
        return false;

    if (curtime < Entity.GetProp(wpn, "CBaseCombatWeapon", "m_flNextPrimaryAttack"))
        return false;

    return true;
}

function _TBC_CREATE_MOVE() {
    var is_charged = Exploit.GetCharge()
    var reserve = UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Double tap tolerance")

    Exploit[(is_charged != 1 ? "Enable" : "Disable") + "Recharge"]()

    if (can_shift_shot(14) && is_charged != 1) {
        Exploit.DisableRecharge();
        Exploit.Recharge()
    }

    Exploit.OverrideTolerance(reserve);
    Exploit.OverrideShift(14-reserve);
}

function _TBC_UNLOAD() {
    Exploit.EnableRecharge();
}

Cheat.RegisterCallback("CreateMove", "_TBC_CREATE_MOVE");
Cheat.RegisterCallback("Unload", "_TBC_UNLOAD");


UI.AddCheckbox("Double TT");
UI.SetValue("Rage", "GENERAL", "Exploits", "Teleport release", true);
function on_ragebot_fire()
{
    ragebot_target_exploit = Event.GetInt("exploit");
    if (UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Doubletap Teleport"))
    {
        (ragebot_target_exploit == 2) ? UI.ToggleHotkey("Rage", "GENERAL", "Exploits", "Doubletap") : UI.ToggleHotkey("Rage", "GENERAL", "Exploits", "Doubletap");
    }   
}
Global.RegisterCallback("ragebot_fire", "on_ragebot_fire");
//


UI.AddCheckbox("Doubletap Recharge ")
var time, delay, fillbar, shotsfired;
var Xoffset = 'Indicator X offset';
var Yoffset = 'Indicator Y offset';

//Weapon fire event
function EVENT_WEAPON_FIRE()
{
    iShotsFired = Event.GetInt("userid"); iShotsFired_index = Entity.GetEntityFromUserID(iShotsFired);
 
    if(Entity.GetLocalPlayer() == iShotsFired_index)
    {
            //Released only once
            if(shotsfired == 0)
            {
                time = Globals.Curtime();
                delay = time+0.3;
                fillbar = 0;
            }              
    }    
}

//Draw
function HUD_REDRAW()
{

    if(UI.GetValue( "Rage", "GENERAL", "Exploits", "Doubletap" ))
    {
        font = Render.AddFont("Verdana Bold", 16, 500);
           const fontpixel = Render.AddFont( "Verdana Bold", 7, 100);
     
        //Enabled
        if(UI.IsHotkeyActive("Rage", "GENERAL", "Exploits", "Doubletap"))
        {
            curtime = Globals.Curtime();
         
            //>_<
            if (curtime < delay)
            {
                fillbar+=1;
                shotsfired = 1;    
           
                //Not allowing fill more
                if(fillbar > 60);
            }
            else
            {
               
            }    
        }
        else
        {
			
        }    
    }    
}

function can_shift_shot(ticks_to_shift) {
    var me = Entity.GetLocalPlayer();
    var wpn = Entity.GetWeapon(me);

    if (me == null || wpn == null)
        return false;

    var tickbase = Entity.GetProp(me, "CCSPlayer", "m_nTickBase");
    var curtime = Globals.TickInterval() * (tickbase-ticks_to_shift)

    if (curtime < Entity.GetProp(me, "CCSPlayer", "m_flNextAttack"))
        return false;

    if (curtime < Entity.GetProp(wpn, "CBaseCombatWeapon", "m_flNextPrimaryAttack"))
        return false;

    return true;
}

function _TBC_CREATE_MOVE() {
    var is_charged = Exploit.GetCharge()

    Exploit[(is_charged != 1 ? "Enable" : "Disable") + "Recharge"]()

    if (can_shift_shot(14) && is_charged != 1) {
        Exploit.DisableRecharge();
        Exploit.Recharge()
    }

    Exploit.OverrideTolerance(0);
    Exploit.OverrideShift(14);
}

function _TBC_UNLOAD() {
    Exploit.EnableRecharge();
}
function Main()
{
    Global.RegisterCallback("CreateMove", "_TBC_CREATE_MOVE");
    Global.RegisterCallback("Unload", "_TBC_UNLOAD");
    Global.RegisterCallback("Draw", "HUD_REDRAW");
    Global.RegisterCallback("weapon_fire", "EVENT_WEAPON_FIRE");


    
}

UI.AddLabel("****************************************");

UI.AddLabel("****************************************");
UI.AddLabel("Category a n t / a i m")
UI.AddCheckbox("Safe Revolver");
UI.AddCheckbox("Prevent Anti-Aim Correction");
UI.AddCheckbox("Prevent Height Advantage");
var old_fake_desync = UI.GetValue("Anti-Aim", "Fake angles", "Fake desync");
var old_at_targets = UI.GetValue("Anti-Aim", "Rage Anti-Aim", "At targets");
var old_auto_direction = UI.GetValue("Anti-Aim", "Rage Anti-Aim", "Auto direction");
var old_yaw_offset = UI.GetValue("Anti-Aim", "Rage Anti-Aim", "Yaw offset");
var prevent_correction = false;
var last_prevent_time = 0;
var in_act_pha = false;
var in_act_pac = false;
var in_act_sr = false;
function distance(a, b) {
    ax = a[0], ay = a[1], az = a[2];
    bx = b[0], by = b[1], bz = b[2];
    dx = ax - bx, dy = ay - by, dz = az - bz;
    return Math.sqrt(dx * dx + dy * dy + dz * dz);
}
function distance2D( x1, y1, x2, y2 ) {
    xs = x2 - x1, ys = y2 - y1;
       
    xs *= xs;
    ys *= ys;
    
    return Math.sqrt( xs + ys );
}
function difference(a, b) {
    if (a > b) {
      return a - b;
    } else {
      return b - a;
    }
}
function get_nearest_player() {
    players = Entity.GetPlayers();
    local_origin = Entity.GetRenderOrigin(Entity.GetLocalPlayer());
    target_origin = 0;
    target = 0;
    for (i=0; i < players.length; i++) {
        if (!Entity.IsAlive(players[i]))
            continue;
        //if (Entity.IsBot(players[i]))
        //    continue;
        if (Entity.IsTeammate(players[i])) //filters local player too
            continue;
        /*if (Entity.IsValid(players[i])) //doesn't work on bots (?)
              continue;*/
        if(Entity.IsDormant(players[i]))
            continue;
        entity_origin = Entity.GetRenderOrigin(players[i]);
        if (target === 0)
            target_origin = [999999, 999999, 999999]; //FK FLT_MAX LOL
        if (distance(local_origin, target_origin) > distance(local_origin, entity_origin)){
            target = players[i];
            target_origin = entity_origin;
        }
    }
    return target;
}
function player_hurt() {
    target = Event.GetInt("userid");
    attacker = Event.GetInt("attacker");
    damage = Event.GetInt("dmg_health");
    hitgroup = Event.GetInt("hitgroup");
    if ((Entity.GetLocalPlayer() === Entity.GetEntityFromUserID(target))
    && Entity.GetLocalPlayer() !==  Entity.GetEntityFromUserID(attacker)) {
        health = Entity.GetProp(Entity.GetLocalPlayer(), "CBasePlayer", "m_iHealth");
        if (hitgroup === 1 && (health / damage) >= 2)
            prevent_correction = true;
        else
            prevent_correction = false;
    }
}
function create_move() {
    local_weapon_id = Entity.GetProp(Entity.GetWeapon(Entity.GetLocalPlayer()), "CBaseAttributableItem", "m_iItemDefinitionIndex");
    local_origin = Entity.GetProp(Entity.GetLocalPlayer(), "CBaseEntity", "m_vecOrigin");
    if (UI.GetValue("Safe Revolver"))
        if(local_weapon_id === 262208) {
            in_act_sr = Math.round(1/Globals.Frametime()) < 65 ? true : false;
            UI.SetValue("Anti-Aim", "Fake-Lag", "Enabled", Math.round(1/Globals.Frametime()) < 65 ? false : true);
        }
        else {
            in_act_sr = false;
            UI.SetValue("Anti-Aim", "Fake-Lag", "Enabled", true);
        }
           
    if (UI.GetValue("Prevent Anti-Aim Correction")) {
        if (prevent_correction) {
            in_act_pac = true;
            fake_desync = UI.GetValue("Anti-Aim", "Fake angles", "Fake desync"); 
            UI.SetValue("Anti-Aim", "Fake angles", "Fake desync", fake_desync ? false : true);
            last_prevent_time = Globals.Curtime();
            prevent_correction = false;
        }
        else if (Globals.Curtime() - last_prevent_time > 2.5) {
            in_act_pac = false;
            UI.SetValue("Anti-Aim", "Fake angles", "Fake desync", old_fake_desync);
        }
    }
    if (UI.GetValue("Prevent Height Advantage")) {
        target = get_nearest_player();
       
        if (target === 0 || !Entity.IsAlive(target)) {
            in_act_pha = false;
            UI.SetValue("Anti-Aim", "Rage Anti-Aim", "At targets", old_at_targets);
            UI.SetValue("Anti-Aim", "Rage Anti-Aim", "Auto direction", old_auto_direction);
            UI.SetValue("Anti-Aim", "Rage Anti-Aim", "Yaw offset", old_yaw_offset);
            return;
        }
        local_origin = Entity.GetRenderOrigin(Entity.GetLocalPlayer());
        target_origin = Entity.GetRenderOrigin(target);
        if ((target_origin[2] > local_origin[2])
        && difference(target_origin[2], local_origin[2]) > 64
        && distance2D(local_origin[0], local_origin[1], target_origin[0], target_origin[1]) < 400) {
            in_act_pha = true;
            UI.SetValue("Anti-Aim", "Rage Anti-Aim", "At targets", true); //test if target ent meets w at target
            UI.SetValue("Anti-Aim", "Rage Anti-Aim", "Auto direction", false);
            UI.SetValue("Anti-Aim", "Rage Anti-Aim", "Yaw offset", 180);
        } else {
            in_act_pha = false;
            UI.SetValue("Anti-Aim", "Rage Anti-Aim", "At targets", old_at_targets);
            UI.SetValue("Anti-Aim", "Rage Anti-Aim", "Auto direction", old_auto_direction);
            UI.SetValue("Anti-Aim", "Rage Anti-Aim", "Yaw offset", old_yaw_offset);
        }
    }
}
function draw() {
    if (!UI.GetValue("Prevent Anti-Aim Correction")
    && !UI.GetValue("Prevent Height Advantage")
    && !UI.GetValue("Safe Revolver"))
        return;
    active_features = [];
    if (UI.GetValue("Prevent Anti-Aim Correction"))
        active_features.push(["prevent correction", in_act_pac ? [0, 255, 0, 220] : [255, 255, 0, 220]]);
    if (UI.GetValue("Prevent Height Advantage"))
        active_features.push(["prevent height", in_act_pha ? [0, 255, 0, 220] : [255, 255, 0, 220]]);
    if (UI.GetValue("Safe Revolver"))
        active_features.push(["safe revolver", in_act_sr ? [0, 255, 0, 220] : [255, 255, 0, 220]]);
    Render.FilledRect(
        20, 400, 160, 80, [18, 18, 18, 220]
    );
    Render.String(
        100, 404, 1, "active features", [255, 255, 255, 220], 8
    );
    Render.Line(
        30, 415, 170, 415, [160, 160, 160, 220]
    );
    pos = 0;
    for (i=0; i < active_features.length; i++) {
        Render.String(
            30, 418 + pos, 0, active_features[i][0], active_features[i][1], 8
        );
        pos = pos + 12;
    }
}
Cheat.RegisterCallback("player_hurt", "player_hurt");
Cheat.RegisterCallback("CreateMove", "create_move");
Cheat.RegisterCallback("Draw", "draw");


UI.AddLabel("****************************************");

UI.AddLabel(" Category Others")

var iVictim_index, First_pos, Second_pos, Third_pos, Fourth_pos, Fifth_pos, First, Second, Third, Fourth, Five, iDamageCount = iOffsetCount = YOffsetFirst = YOffsetSecond = YOffsetThird = YOffsetFourth = YOffsetFive = loadFont = HitAttack = 0; 

const first_screen_pos = [], second_screen_pos = [], third_screen_pos = [], fourth_screen_pos = [], fifth_screen_pos = [];

function EVENT_PLAYER_HURT()
{
    iAttacker = Event.GetInt("attacker"); iAttacker_index = Entity.GetEntityFromUserID(iAttacker);
  
    iVictim = Event.GetInt("userid"); iVictim_index = Entity.GetEntityFromUserID(iVictim); 
  
    if(Entity.GetLocalPlayer() == iVictim_index && Entity.GetLocalPlayer() !== iAttacker_index)    return;
  
    if(Entity.GetLocalPlayer() == iAttacker_index)
    {
        HitAttack = 1;
      
        if(iDamageCount == 5) iDamageCount = 0; if(iOffsetCount == 5) iOffsetCount = 0;
      
        iDamageCount+=1;
      
        iOffsetCount+=1;       
      
        if(iDamageCount == 1)    {    First = Event.GetInt("dmg_health");    First_pos = Entity.GetRenderOrigin(iVictim_index);    } 
        if(iDamageCount == 2)    {    Second = Event.GetInt("dmg_health");    Second_pos = Entity.GetRenderOrigin(iVictim_index);    }             
        if(iDamageCount == 3)    {    Third = Event.GetInt("dmg_health");    Third_pos = Entity.GetRenderOrigin(iVictim_index);    }     
        if(iDamageCount == 4)    {    Fourth = Event.GetInt("dmg_health");    Fourth_pos = Entity.GetRenderOrigin(iVictim_index);    }     
        if(iDamageCount == 5)    {    Five = Event.GetInt("dmg_health");    Fifth_pos = Entity.GetRenderOrigin(iVictim_index);    }

        if(iOffsetCount == 1)    YOffsetFirst = 255; if(iOffsetCount == 2)    YOffsetSecond = 255; if(iOffsetCount == 3)    YOffsetThird = 255; if(iOffsetCount == 4)    YOffsetFourth = 255; if(iOffsetCount == 5)    YOffsetFive = 200;             
    }     
}

function HUD_REDRAW()
{
    if(loadFont == 0)
    {
        fontSM2 = Render.AddFont("Verdana", 10, 550)
        loadFont = 1;
    }
  
    if(!HitAttack || !getCustomValue('Quake Damage Numbers'))    return;

    if(Entity.IsValid(iVictim_index))
    {
        
  
        if(iDamageCount < 6)   
        {
            if(iDamageCount == 1)    first_screen_pos = Render.WorldToScreen(First_pos);    if(iDamageCount == 2)    second_screen_pos = Render.WorldToScreen(Second_pos);
            if(iDamageCount == 3)    third_screen_pos = Render.WorldToScreen(Third_pos);    if(iDamageCount == 4)    fourth_screen_pos = Render.WorldToScreen(Fourth_pos);
            if(iDamageCount == 5)    fifth_screen_pos = Render.WorldToScreen(Fifth_pos);first_screen_pos = Render.WorldToScreen(First_pos);
        }
        
        color = UI.GetColor("Misc", "JAVASCRIPT", "Script items", "Color");
            Render.StringCustom(first_screen_pos[0]-15+1, first_screen_pos[1]-50+YOffsetFirst-255+1, 1, "" + First, [ 0, 0,0, YOffsetFirst ], fontSM2);
            Render.StringCustom(first_screen_pos[0]-15, first_screen_pos[1]-50+YOffsetFirst-255, 1, "" + First, alp( color, YOffsetFirst ), fontSM2);
        
            Render.StringCustom(second_screen_pos[0]+15+1, second_screen_pos [1]-50+YOffsetSecond-255+1, 1, "" + Second, [ 0, 0, 0, YOffsetSecond ], fontSM2);
            Render.StringCustom(second_screen_pos[0]+15, second_screen_pos [1]-50+YOffsetSecond-255, 1, "" + Second, alp( color, YOffsetSecond ), fontSM2);
        
            Render.StringCustom(third_screen_pos[0]-25+1, third_screen_pos[1]-50+YOffsetThird-255+1, 1, "" + Third, [ 0,0,0, YOffsetThird ], fontSM2);
            Render.StringCustom(third_screen_pos[0]-25, third_screen_pos[1]-50+YOffsetThird-255, 1, "" + Third, alp( color, YOffsetThird ), fontSM2);
        
            Render.StringCustom(fourth_screen_pos[0]+25+1, fourth_screen_pos[1]-50+YOffsetFourth-255+1, 1, "" + Fourth, [ 0, 0, 0, YOffsetFourth ], fontSM2);
            Render.StringCustom(fourth_screen_pos[0]+25, fourth_screen_pos[1]-50+YOffsetFourth-255, 1, "" + Fourth, alp(color, YOffsetFourth ), fontSM2);
        
            Render.StringCustom(fifth_screen_pos[0]-10+1, fifth_screen_pos[1]-50+YOffsetFive-255+1, 1, "" + Five, [ 0, 0, 0, YOffsetFive ], fontSM2);
            Render.StringCustom(fifth_screen_pos[0]-10, fifth_screen_pos[1]-50+YOffsetFive-255, 1, "" + Five, alp( color, YOffsetFive ), fontSM2);
        
    }     
} 

function getCustomValue(name)
{
    var value = UI.GetValue("Misc", "JAVASCRIPT", "Script items", name);
    return value;
}

function pushY()
{
    //Push Y
        if(YOffsetFirst > 1)    YOffsetFirst--; if(YOffsetSecond > 1)    YOffsetSecond--; if(YOffsetThird > 1)    YOffsetThird--; if(YOffsetFourth > 1)    YOffsetFourth--; if(YOffsetFive > 1)    YOffsetFive--;
}

function alp(c, a) {
  return [c[0], c[1], c[2], a]
}

function Main()
{
    Global.RegisterCallback("Draw", "HUD_REDRAW");
    Global.RegisterCallback("player_hurt", "EVENT_PLAYER_HURT");
    Global.RegisterCallback("CreateMove", "pushY");
    UI.AddCheckbox('Quake Damage Numbers');
    UI.AddColorPicker("Color");
    UI.AddCheckbox("Premade Settings");
}

Main();

const global_choked_commands = Globals.ChokedCommands, global_realtime = Globals.Realtime, global_frametime = Globals.Frametime, global_curtime = Globals.Curtime, global_tick_interval = Globals.TickInterval, global_tickrate = Globals.Tickrate, global_tickcount = Globals.Tickcount, global_frame_stage = Globals.FrameStage, ui_get_menu_position = UI.GetMenuPosition, ui_update_list = UI.UpdateList, ui_remove_item = UI.RemoveItem, ui_get_hotkey = UI.GetHotkey, ui_set_hotkey_state = UI.SetHotkeyState, ui_get_hotkey_state = UI.GetHotkeyState, ui_toggle_hotkey = UI.ToggleHotkey, ui_set_color = UI.SetColor, ui_add_sub_tab = UI.AddSubTab, ui_add_textbox = UI.AddTextbox, ui_add_color_picker = UI.AddColorPicker, ui_add_multi_dropdown = UI.AddMultiDropdown, ui_add_dropdown = UI.AddDropdown, ui_add_hotkey = UI.AddHotkey, ui_add_slider_float = UI.AddSliderFloat, ui_add_slider_int = UI.AddSliderInt, ui_add_checkbox = UI.AddCheckbox, ui_set_value = UI.SetValue, ui_get_children = UI.GetChildren, ui_get_value = UI.GetValue, ui_get_string = UI.GetString, ui_get_color = UI.GetColor, ui_is_menu_open = UI.IsMenuOpen, ui_set_enabled = UI.SetEnabled, entity_draw_flag = Entity.DrawFlag, entity_get_ccs_weapon_info = Entity.GetCCSWeaponInfo, entity_get_render_box = Entity.GetRenderBox, entity_get_weapons = Entity.GetWeapons, entity_get_entities_by_class_id = Entity.GetEntitiesByClassID, entity_get_hitbox_position = Entity.GetHitboxPosition, entity_get_eye_position = Entity.GeteyePosition, entity_get_game_rules_proxy = Entity.GetGameRulesProxy, entity_is_bot = Entity.IsBot, entity_get_weapon = Entity.GetWeapon, entity_set_prop = Entity.SetProp, entity_get_prop = Entity.GetProp, entity_get_render_origin = Entity.GetRenderOrigin, entity_get_name = Entity.GetName, entity_get_class_name = Entity.GetClassName, entity_get_class_id = Entity.GetClassID, entity_is_dormant = Entity.IsDormant, entity_is_alive = Entity.IsAlive, entity_is_valid = Entity.IsValid, entity_is_local_player = Entity.IsLocalPlayer, entity_is_enemy = Entity.IsEnemy, entity_is_teammate = Entity.IsTeammate, entity_get_entity_from_user_id = Entity.GetEntityFromUserID, entity_get_local_player = Entity.GetLocalPlayer, entity_get_teammates = Entity.GetTeammates, entity_get_enemies = Entity.GetEnemies, entity_get_players = Entity.GetPlayers, entity_get_entities = Entity.GetEntities, render_text_size = Render.TextSize, render_string = Render.String, render_filled_circle = Render.FilledCircle, render_textured_rect = Render.TexturedRect, render_add_texture = Render.AddTexture, render_find_font = Render.FindFont, render_add_font = Render.AddFont, render_polygon = Render.Polygon, render_gradient_rect = Render.GradientRect, render_get_screen_size = Render.GetScreenSize, render_world_to_screen = Render.WorldToScreen, render_circle = Render.Circle, render_filled_rect = Render.FilledRect, render_rect = Render.Rect, render_line = Render.Line, convar_set_string = Convar.SetString, convar_get_string = Convar.GetString, convar_set_float = Convar.SetFloat, convar_get_float = Convar.GetFloat, convar_set_int = Convar.SetInt, convar_get_int = Convar.GetInt, event_get_string = Event.GetString, event_get_float = Event.GetFloat, event_get_int = Event.GetInt, trace_raw_line = Trace.RawLine, trace_smoke = Trace.Smoke, trace_bullet = Trace.Bullet, trace_line = Trace.Line, usercmd_get_movement = UserCMD.GetMovement, usercmd_set_view_angles = UserCMD.SetViewAngles, usercmd_send = UserCMD.Send, usercmd_choke = UserCMD.Choke, usercmd_set_buttons = UserCMD.SetButtons, usercmd_get_buttons = UserCMD.GetButtons, usercmd_set_movement = UserCMD.SetMovement, sound_stop_microphone = Sound.StopMicrophone, sound_play_microphone = Sound.PlayMicrophone, sound_play = Sound.Play, local_get_inaccuracy = Local.GetInaccuracy, local_get_spread = Local.GetSpread, local_get_fake_yaw = Local.GetFakeYaw, local_get_real_yaw = Local.GetRealYaw, local_set_clan_tag = Local.SetClanTag, local_set_view_angles = Local.SetViewAngles, local_get_view_angles = Local.GetViewAngles, local_latency = Local.Latency, cheat_is_legit_config_active = Cheat.IsLegitConfigActive, cheat_is_rage_config_active = Cheat.IsRageConfigActive, cheat_get_username = Cheat.GetUsername, cheat_print_chat = Cheat.PrintChat, cheat_register_callback = Cheat.RegisterCallback, cheat_execute_command = Cheat.ExecuteCommand, cheat_print_color = Cheat.PrintColor, cheat_print = Cheat.Print, input_force_cursor = Input.ForceCursor, input_get_cursor_position = Input.GetCursorPosition, input_is_key_pressed = Input.IsKeyPressed, world_get_server_string = World.GetServerString, world_get_map_name = World.GetMapName, antiaim_set_lby_offset = AntiAim.SetLBYOffset, antiaim_set_real_offset = AntiAim.SetRealOffset, antiaim_set_fake_offset = AntiAim.SetFakeOffset, antiaim_get_override = AntiAim.GetOverride, antiaim_set_override = AntiAim.SetOverride, exploit_override_tolerance = Exploit.OverrideTolerance, exploit_override_shift = Exploit.OverrideShift, exploit_enable_recharge = Exploit.EnableRecharge, exploit_disable_recharge = Exploit.DisableRecharge, exploit_recharge = Exploit.Recharge, exploit_get_charge = Exploit.GetCharge, ragebot_get_targets = Ragebot.GetTargets, ragebot_ignore_target = Ragebot.IgnoreTarget, ragebot_force_hitbox_safety = Ragebot.ForceHitboxSafety, ragebot_force_target_minimum_damage = Ragebot.ForceTargetMinimumDamage, ragebot_force_target_hitchance = Ragebot.ForceTargetHitchance, ragebot_force_target_safety = Ragebot.ForceTargetSafety, ragebot_force_target = Ragebot.ForceTarget, ragebot_get_target = Ragebot.GetTarget, material_refresh = Material.Refresh, material_set_key_value = Material.SetKeyValue, material_get = Material.Get, material_destroy = Material.Destroy, material_create = Material.Create;

var screen_size = render_get_screen_size();
var sv_cheats_cache = 0;
var removals_cache = 0;

UI.AddCheckbox("Custom scope lines");
UI.AddColorPicker("Scope lines color");
UI.AddSliderInt("Scope lines height", 0, 500);
UI.AddSliderInt("Scope lines offset", 0, 500);

function get_weapon(entity) {
    if (entity_get_name(entity_get_weapon(entity)) == 'g3sg1' || entity_get_name(entity_get_weapon(entity)) == 'scar 20') return 'auto';
    else if (entity_get_name(entity_get_weapon(entity)) == 'awp') return 'awp';
    else if (entity_get_name(entity_get_weapon(entity)) == 'desert eagle') return 'deagle';
    else if (entity_get_name(entity_get_weapon(entity)) == 'r8 revolver') return 'revolver';
    else if (entity_get_name(entity_get_weapon(entity)) == 'ssg 08') return 'scout';
    else return 'other';
}

function set_dropdown_value(value, index, enable) /*credits to ed*/ {
    var mask = 1 << index;
    return enable ? (value | mask) : (value & ~mask);
}

function draw() {
    var local_player = entity_get_local_player();

    if (entity_is_alive(local_player)) {
        if (ui_get_value("Misc", "JAVASCRIPT", "Script items", "Custom scope lines")) {
            var scoped = entity_get_prop(local_player, "CCSPlayer", "m_bIsScoped");
            var offset = ui_get_value("Misc", "JAVASCRIPT", "Script items", "Scope lines offset");
            var height = ui_get_value("Misc", "JAVASCRIPT", "Script items", "Scope lines height");
            var color = ui_get_color("Misc", "JAVASCRIPT", "Script items", "Scope lines color");
            sv_cheats_cache = ui_get_value("Misc.", "GENERAL", "Miscellaneous", "Force sv_cheats");
            removals_cache = ui_get_value("Visual", "WORLD", "Entities", "Removals");
            if (scoped) {
                if (get_weapon(local_player) == "auto" || get_weapon(local_player) == "awp" || get_weapon(local_player) == "scout") {
                    ui_set_value("Misc.", "GENERAL", "Miscellaneous", "Force sv_cheats", 1);
                    convar_set_float("r_drawvgui", 0);
                    ui_set_value("Visual", "WORLD", "Entities", "Removals", set_dropdown_value(removals_cache, 2, false));
                    render_gradient_rect(screen_size[0] / 2 + offset, screen_size[1] / 2, height, 1, 1, [color[0], color[1], color[2], color[3]], [color[0], color[1], color[2], 0]);
                    render_gradient_rect(screen_size[0] / 2 - height - offset, screen_size[1] / 2, height, 1, 1, [color[0], color[1], color[2], 0], [color[0], color[1], color[2], color[3]]);
                    render_gradient_rect(screen_size[0] / 2, screen_size[1] / 2 + offset, 1, height, 0, [color[0], color[1], color[2], color[3]], [color[0], color[1], color[2], 0]);
                    render_gradient_rect(screen_size[0] / 2, screen_size[1] / 2 - height - offset, 1, height, 0, [color[0], color[1], color[2], 0], [color[0], color[1], color[2], color[3]]);
                }
            } if (!scoped) {
                convar_set_float("r_drawvgui", 1);
                ui_set_value("Misc.", "GENERAL", "Miscellaneous", "Force sv_cheats", 1);
                ui_set_value("Visual", "WORLD", "Entities", "Removals", set_dropdown_value(removals_cache, 2, true));
            }
        }
    } else {
        convar_set_float("r_drawvgui", 1);
    }
}

function unload() {
    convar_set_float("r_drawvgui", 1);
    ui_set_value("Visual", "WORLD", "Entities", "Removals", set_dropdown_value(removals_cache, 2, true));
    ui_set_value("Misc.", "GENERAL", "Miscellaneous", "Force sv_cheats", sv_cheats_cache);
}

cheat_register_callback("Unload", "unload");
cheat_register_callback("Draw", "draw");
///This java skript create Lucer [HARDLINE]
UI.SetValue( "Misc", "GENERAL", "Misc", "Force sv_cheats", true );
UI.SetValue( "Misc", "GENERAL", "Misc", "Hidden cvars", true );
Global.ExecuteCommand( "@panorama_disable_blur 1" );
UI.AddLabel("****************************************");
