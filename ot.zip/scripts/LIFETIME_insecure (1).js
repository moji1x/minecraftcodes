var ilililililililillililililililililili=3;var ilililililililillilililililililililiilililililililillililililililililili=2;if(ilililililililillilililililililililiilililililililillililililililililili>ilililililililillililililililililili){Cheat.PrintColor([255,0,0,255],"\n\n--Your license has expired!")}else{UI.AddLabel("           --- insecure.js ---");const global_print=Global.Print;global_print_chat=Global.PrintChat;global_print_color=Global.PrintColor;global_register_callback=Global.RegisterCallback,global_execute_command=Global.ExecuteCommand,global_frame_stage=Global.FrameStage,global_tickcount=Global.Tickcount,global_tickrate=Global.Tickrate,global_tick_interval=Global.TickInterval,global_curtime=Global.Curtime,global_realtime=Global.Realtime,global_frametime=Global.Frametime,global_latency=Global.Latency,global_get_view_angles=Global.GetViewAngles,global_set_view_angles=Global.SetViewAngles,global_get_map_name=Global.GetMapName,global_is_key_pressed=Global.IsKeyPressed,global_get_screen_size=Global.GetScreenSize,global_get_cursor_position=Global.GetCursorPosition,global_play_sound=Global.PlaySound,global_play_microphone=Global.PlayMicrophone,global_stop_microphone=Global.StopMicrophone,global_get_username=Global.GetUsername,global_set_clan_tag=Global.SetClanTag,globals_tickcount=Globals.Tickcount,globals_tickrate=Globals.Tickrate,globals_tick_interval=Globals.TickInterval,globals_curtime=Globals.Curtime,globals_realtime=Globals.Realtime,globals_frametime=Globals.Frametime,sound_play=Sound.Play,sound_play_microphone=Sound.PlayMicrophone,sound_stop_microphone=Sound.StopMicrophone,cheat_get_username=Cheat.GetUsername,cheat_register_callback=cheat_register_callback=new Proxy(Cheat.RegisterCallback,{apply:function(_,_,args){switch(args[0]){case"paint":Cheat.RegisterCallback("Draw",args[1]);break;case"create_move":Cheat.RegisterCallback("CreateMove",args[1]);break;case"fsn":Cheat.RegisterCallback("FrameStageNotify",args[1]);break;default:Cheat.RegisterCallback(args[0],args[1]);break}}}),cheat_execute_command=Cheat.ExecuteCommand,cheat_frame_stage=Cheat.FrameStage,cheat_print=Cheat.Print,cheat_print_chat=Cheat.PrintChat,cheat_print_color=Cheat.PrintColor,local_latency=Local.Latency,local_get_view_angles=Local.GetViewAngles,local_set_view_angles=Local.SetViewAngles,local_set_clan_tag=Local.SetClanTag,local_get_real_yaw=Local.GetRealYaw,local_get_fake_yaw=Local.GetFakeYaw,local_get_spread=Local.GetSpread,local_get_inaccuracy=Local.GetInaccuracy,world_get_map_name=World.GetMapName,world_get_server_string=World.GetServerString,input_get_cursor_position=Input.GetCursorPosition,input_is_key_pressed=Input.IsKeyPressed,render_string=Render.String,render_text_size=Render.TextSize,render_line=Render.Line,render_rect=Render.Rect,render_filled_rect=Render.FilledRect,render_gradient_rect=Render.GradientRect,render_circle=Render.Circle,render_filled_circle=Render.FilledCircle,render_polygon=Render.Polygon,render_world_to_screen=Render.WorldToScreen,render_add_font=Render.AddFont,render_find_font=Render.FindFont,render_string_custom=Render.StringCustom,render_textured_rect=Render.TexturedRect,render_add_texture=Render.AddTexture,render_text_size_custom=Render.TextSizeCustom,render_get_screen_size=Render.GetScreenSize,ui_get_value=UI.GetValue,ui_set_value=UI.SetValue,ui_add_checkbox=UI.AddCheckbox,ui_add_slider_int=UI.AddSliderInt,ui_add_slider_float=UI.AddSliderFloat,ui_add_hotkey=UI.AddHotkey,ui_add_label=UI.AddLabel,ui_add_dropdown=UI.AddDropdown,ui_add_multi_dropdown=UI.AddMultiDropdown,ui_add_color_picker=UI.AddColorPicker,ui_add_textbox=UI.AddTextbox,ui_set_enabled=UI.SetEnabled,ui_get_string=UI.GetString,ui_get_color=UI.GetColor,ui_set_color=UI.SetColor,ui_is_hotkey_active=UI.IsHotkeyActive,ui_toggle_hotkey=UI.ToggleHotkey,ui_is_menu_open=UI.IsMenuOpen,convar_get_int=Convar.GetInt,convar_set_int=Convar.SetInt,convar_get_float=Convar.GetFloat,convar_set_float=Convar.SetFloat,convar_get_string=Convar.GetString,convar_set_string=Convar.SetString,event_get_int=Event.GetInt,event_get_float=Event.GetFloat,event_get_string=Event.GetString,entity_get_entities=Entity.GetEntities,entity_get_entities_by_class_i_d=Entity.GetEntitiesByClassID,entity_get_players=Entity.GetPlayers,entity_get_enemies=Entity.GetEnemies,entity_get_teammates=Entity.GetTeammates,entity_get_local_player=Entity.GetLocalPlayer,entity_get_game_rules_proxy=Entity.GetGameRulesProxy,entity_get_entity_from_user_i_d=Entity.GetEntityFromUserID,entity_is_teammate=Entity.IsTeammate,entity_is_enemy=Entity.IsEnemy,entity_is_bot=Entity.IsBot,entity_is_local_player=Entity.IsLocalPlayer,entity_is_valid=Entity.IsValid,entity_is_alive=Entity.IsAlive,entity_is_dormant=Entity.IsDormant,entity_get_class_i_d=Entity.GetClassID,entity_get_class_name=Entity.GetClassName,entity_get_name=Entity.GetName,entity_get_weapon=Entity.GetWeapon,entity_get_weapons=Entity.GetWeapons,entity_get_render_origin=Entity.GetRenderOrigin,entity_get_prop=Entity.GetProp,entity_set_prop=Entity.SetProp,entity_get_hitbox_position=Entity.GetHitboxPosition,entity_get_eye_position=Entity.GetEyePosition,trace_line=Trace.Line,trace_bullet=Trace.Bullet,usercmd_set_movement=UserCMD.SetMovement,usercmd_get_movement=UserCMD.GetMovement,usercmd_set_angles=UserCMD.SetAngles,usercmd_force_jump=UserCMD.ForceJump,usercmd_force_crouch=UserCMD.ForceCrouch,antiaim_get_override=AntiAim.GetOverride,antiaim_set_override=AntiAim.SetOverride,antiaim_set_real_offset=AntiAim.SetRealOffset,antiaim_set_fake_offset=AntiAim.SetFakeOffset,antiaim_set_l_b_y_offset=AntiAim.SetLBYOffset,exploit_get_charge=Exploit.GetCharge,exploit_recharge=Exploit.Recharge,exploit_disable_recharge=Exploit.DisableRecharge,exploit_enable_recharge=Exploit.EnableRecharge,ragebot_override_minimum_damage=Ragebot.OverrideMinimumDamage,ragebot_override_hitchance=Ragebot.OverrideHitchance,ragebot_override_accuracy_boost=Ragebot.OverrideAccuracyBoost,ragebot_override_multipoint_scale=Ragebot.OverrideMultipointScale,ragebot_force_safety=Ragebot.ForceSafety;var menu1={_class:"BetterUI"};const menu1_spacer="                                                                                  ";menu1.concat=function(a,b){var arr=[];for(var c in a){arr.push(a[c])}arr.push(b);return arr};menu1.label=function(label){UI.AddLabel(label)};menu1.call=function(func,name,label,properties){const final_name=name+menu1_spacer+label;var final_props=[final_name];const element_info_t={path:["Misc","JAVASCRIPT",final_name]};if(properties!=null){for(var i=0;i<properties.length;i++){final_props.push(properties[i])}}func.apply(null,final_props);return element_info_t};menu1.reference=function(path){const element_info_t={path:path};return element_info_t};menu1.get=function(elem){if(!elem.path)throw new Error("[Menu] This element doesn't exist!");return UI.GetValue.apply(null,elem.path)};menu1.get_hotkey=function(elem){if(!elem.path)throw new Error("[Menu] This element doesn't exist!");return UI.IsHotkeyActive.apply(null,elem.path)};menu1.get_color=function(elem){if(!elem.path)throw new Error("[Menu] This element doesn't exist!");return UI.GetColor.apply(null,elem.path)};menu1.set=function(elem,value){if(!elem.path)throw new Error("[Menu] This element doesn't exist!");const properties=elem;UI.SetValue.apply(null,this.concat(properties.path,value))};menu1.set_color=function(elem,color){if(!elem.path)throw new Error("[Menu] This element doesn't exist!");const properties=elem;UI.SetColor.apply(null,this.concat(properties.path,color))};menu1.toggle=function(elem){if(!elem.path)throw new Error("[Menu] This element doesn't exist!");UI.ToggleHotkey.apply(null,elem.path)};menu1.visibility=function(elem,visible){if(!elem.path)throw new Error("[Menu] This element doesn't exist!");const properties=elem;UI.SetEnabled.apply(null,this.concat(properties.path,visible))};var vector={_class:"vector"};vector["new"]=function(data){return{x:data[0],y:data[1],z:data[2]}};vector.operate=function(vec,vec2,operation){switch(operation){case"+":return{x:vec.x+vec2.x,y:vec.y+vec2.y,z:vec.z+vec2.z};case"-":return{x:vec.x-vec2.x,y:vec.y-vec2.y,z:vec.z-vec2.z};case"*":return{x:vec.x*vec2.x,y:vec.y*vec2.y,z:vec.z*vec2.z};case"/":return{x:vec.x/vec2.x,y:vec.y/vec2.y,z:vec.z/vec2.z};default:throw new Error("[Vector] Invalid operation type.")}};vector.length2d=function(vec){return Math.sqrt(vec.x*vec.x+vec.y*vec.y)};vector.angles=function(vec){return{x:-Math.atan2(vec.z,this.length2d(vec))*180/Math.PI,y:Math.atan2(vec.y,vec.x)*180/Math.PI,z:0}};vector.fov_to=function(origin,destination,view){const angles=this.angles(this.operate(destination,origin,"-"));const delta=this["new"]([Math.abs(view.x-angles.x),Math.abs(view.y%360-angles.y%360)%360,0]);if(delta.y>180)delta.y=360-delta.y;return this.length2d(delta)};vector.to_array=function(vec){return[vec.x,vec.y,vec.z]};function normalize_yaw(angle){var adjusted_yaw=angle;if(adjusted_yaw<-180)adjusted_yaw+=360;if(adjusted_yaw>180)adjusted_yaw-=360;return adjusted_yaw}var plugin={_info:{_title:"",_version:"",_author:""},last_hit_lby:[],last_target_visibility:false,override_flip:false,last_override_time:globals_curtime()};const enable=menu1.call(ui_add_checkbox,"Advanced body freestanding","lby_enable",[]);const body=menu1.call(ui_add_dropdown,"Body freestanding","lby_body_mode",[["Hide real angle","Hide fake angle"]]);const smart=menu1.call(ui_add_checkbox,"Smart switch","lby_smart",[]);const flip=menu1.call(ui_add_multi_dropdown,"Body inverter flip","lby_body",[["Walk","Run","In air"]]);const ref_inverter=menu1.reference(["Anti-Aim","Fake angles","Inverter"]);const ref_bodyflip=menu1.reference(["Anti-Aim","Fake angles","Inverter flip"]);const ref_inverter_legit=menu1.reference(["Anti-Aim","Legit Anti-Aim","Direction key"]);const ref_ragebot=menu1.reference(["Rage","GENERAL","General","Enabled"]);function update_anti_aim_state(state){if(menu1.get(ref_ragebot)){if(menu1.get_hotkey(ref_inverter)!==state)menu1.toggle(ref_inverter);return}state=(state+1)%2;if(menu1.get_hotkey(ref_inverter_legit)!==state)menu1.toggle(ref_inverter_legit)}function get_closest_target(){const players=entity_get_enemies();const me=entity_get_local_player();const data={id:null,fov:180};for(var i=0;i<players.length;i++){const e=players[i];const destination=vector["new"](entity_get_hitbox_position(e,0)),origin=vector["new"](entity_get_eye_position(me));const angles=vector["new"](local_get_view_angles());const fov=vector.fov_to(origin,destination,angles);if(fov<data.fov){data.id=e;data.fov=fov}}return data.id}function get_target_visibility(){const target=get_closest_target();if(!target||!entity_is_valid(target))return false;if(entity_is_dormant(target))return false;const me=entity_get_local_player();var origin=vector["new"](entity_get_eye_position(me)),velocity=vector["new"](entity_get_prop(me,"CBasePlayer","m_vecVelocity[0]")),destination=entity_get_hitbox_position(target,0);velocity=vector.operate(velocity,vector["new"]([.25,.25,.25]),"*");origin=vector.operate(origin,velocity,"+");const result=trace_line(me,vector.to_array(origin),destination)[0];return result===target}function get_optimal_angle(){const _mode=menu1.get(body);const me=entity_get_local_player();const origin=vector["new"](entity_get_render_origin(me));var yaw=local_get_view_angles()[1];var data={left:0,right:0};for(var r=yaw-90;r<=yaw+90;r+=30){if(r===yaw)continue;const rad=r*Math.PI/180;const point=vector.operate(origin,vector["new"]([256*Math.cos(rad),256*Math.sin(rad),0]),"+");const line=trace_line(me,vector.to_array(origin),vector.to_array(point));const side=r<yaw?"left":"right";data[side]+=line[1]}data.left/=3;data.right/=3;if(data.left>data.right)return _mode===0?0:1;return _mode===0?1:0}function update_inverter_flip(){if(!menu1.get(flip))return;const visible=get_target_visibility();const now=globals_curtime();if(plugin.last_override_time+.3<now)plugin.override_flip=false;if(visible!==plugin.last_target_visibility){plugin.override_flip=true;plugin.last_override_time=now}plugin.last_target_visibility=visible;if(plugin.override_flip){menu1.set(ref_bodyflip,0);return}menu1.set(ref_bodyflip,menu1.get(flip))}function update_anti_aim(){const me=entity_get_local_player();if(!entity_is_valid(me)||!entity_is_alive(me))return;const _smart=menu1.get(smart);update_inverter_flip();if(_smart){const target=get_closest_target();if(target==null){update_anti_aim_state(get_optimal_angle());return}if(plugin.last_hit_lby[target]==null){update_anti_aim_state(get_optimal_angle());return}if(plugin.last_hit_lby[target]===0){update_anti_aim_state(1);return}update_anti_aim_state(0);return}update_anti_aim_state(get_optimal_angle())}function do_indicators(){const me=entity_get_local_player();if(!entity_is_valid(me)||!entity_is_alive(me))return;const y=render_get_screen_size()[1];const yaw=local_get_real_yaw(),fake=local_get_fake_yaw();var delta=Math.round(normalize_yaw(yaw-fake)/2),abs=Math.abs(delta);if(menu1.get(ref_ragebot))delta*=-1;render_string(10,y/2+16,0,"FAKE",[10,10,10,125],4);render_string(10,y/2+15,0,"FAKE",[192-abs*71/60,32+abs*146/60,28,200],4);render_filled_rect(12,y/2+46,64,4,[10,10,10,125]);render_filled_rect(43,y/2+47,1,2,[232,232,232,200]);render_string(41,y/2+52,1,abs.toString(),[232,232,232,200],3);render_circle(48,y/2+52,1,[232,232,232,200]);if(delta>0){render_filled_rect(44,y/2+47,abs*31/60,2,[232,232,232,200]);return}render_filled_rect(44-abs*31/60,y/2+47,abs*31/60,2,[232,232,232,200])}function on_tick(){if(!menu1.get(enable))return;update_anti_aim()}function on_frame(){if(!menu1.get(enable))return;do_indicators()}function on_player_hurt(){const me=entity_get_local_player();const attacker=entity_get_entity_from_user_i_d(event_get_int("attacker"));const userid=entity_get_entity_from_user_i_d(event_get_int("userid"));if(me!==attacker&&me===userid){plugin.last_hit_lby[attacker]=menu1.get_hotkey(ref_inverter)}}function reset(){plugin.last_hit_lby=[]}cheat_register_callback("create_move","on_tick");cheat_register_callback("paint","on_frame");cheat_register_callback("player_hurt","on_player_hurt");cheat_register_callback("player_connect_full","reset");function vec_sub(A,B){var C=[];var i;for(i=0;i<3;i++){C[i]=A[i]-B[i]}return C}function vec_div(A,B){var C=[];var i;for(i=0;i<3;i++){C[i]=A[i]/B}return C}function vec_add(A,B){var C=[];var i;for(i=0;i<3;i++){C[i]=A[i]+B[i]}return C}function vec_mul(A,B){var C=[];var i;for(i=0;i<3;i++){C[i]=A[i]*B}return C}function dotProduct(A,B){var product=0;var i;for(i=0;i<3;i++){product+=A[i]*B[i]}return product}function getDistance(A,B){var delta=vec_sub(A,B);return Math.sqrt(delta[0]*delta[0]+delta[1]*delta[1]+delta[2]*delta[2])}function computeDistance(A,B,C){var d=vec_div(vec_sub(C,B),getDistance(C,B));var v=vec_sub(A,B);var t=dotProduct(v,d);var P=vec_add(B,vec_mul(d,t));return getDistance(P,A)}UI.AddCheckbox("Dodge bruteforce");UI.AddSliderInt("Max Brute Distance",0,60);UI.AddCheckbox("Anti-Onetap");var shots=0;function onBulletImpact(){var ent=Entity.GetEntityFromUserID(Event.GetInt("userid"));var local=Entity.GetLocalPlayer();if(ent==local||Entity.IsTeammate(ent)&&UI.GetValue("Dodge bruteforce"))return;var pos=[Event.GetFloat("x"),Event.GetFloat("y"),Event.GetFloat("z")];var delta=computeDistance(Entity.GetHitboxPosition(Entity.GetLocalPlayer(),0),Entity.GetEyePosition(ent),pos);if(delta<UI.GetValue("Max Brute Distance"))UI.ToggleHotkey("Anti-Aim","Fake angles","Inverter");if(UI.GetValue("Anti-Onetap")){shots++;if(!(shots%4))UI.ToggleHotkey("Anti-Aim","Fake angles","Inverter")}}function playerhurt(){if(Entity.GetEntityFromUserID(Event.GetInt("userid"))==Entity.GetLocalPlayer())UI.ToggleHotkey("Anti-Aim","Fake angles","Inverter")}Cheat.RegisterCallback("player_hurt","playerhurt");Cheat.RegisterCallback("bullet_impact","onBulletImpact");var master={dir:"back",cycle:false,GetYawOffset:function(){return UI.GetValue("Anti-Aim","Rage Anti-Aim","Yaw offset")},SetYawOffset:function(yaw){return UI.SetValue("Anti-Aim","Rage Anti-Aim","Yaw offset",yaw)},GetJitterOffset:function(){return UI.GetValue("Anti-Aim","Rage Anti-Aim","Jitter offset")},SetJitterOffset:function(jitter){return UI.SetValue("Anti-Aim","Rage Anti-Aim","Jitter offset",jitter)},RandomYaw:function(){return UI.GetValue("Misc","JAVASCRIPT","Yaw offset randomization")},RandomJitter:function(){return UI.GetValue("Misc","JAVASCRIPT","Jitter offset randomization")},JitterOffsetJitter:function(){return UI.GetValue("Misc","JAVASCRIPT","Jitter offset jitter")}};function ui(){UI.AddCheckbox("Jitter Randomizer");UI.AddSliderInt("Jitter offset randomization",0,90);UI.AddSliderInt("Jitter offset jitter",0,90)}function getRandomInt(min,max){min=Math.ceil(min);max=Math.floor(max);return Math.floor(Math.random()*(max-min))+min}function jitter(){if(UI.GetValue("Jitter Randomizer")){master.cycle=!master.cycle;master.SetJitterOffset((master.cycle?master.JitterOffsetJitter()/2*2:-(master.JitterOffsetJitter()/2)*2)+getRandomInt(-master.RandomJitter(),master.RandomJitter()))}}function main1(){ui();Global.RegisterCallback("CreateMove","jitter")}main1();UI.AddSliderInt("         +Weapon Features+",0,0);const menu={menu_types:{TYPE_VALUE:0,TYPE_COLOR:1,TYPE_KEYBIND:2,TYPE_REFERENCE:3},menu_array:[],create_checkbox:function(created_var_name){return this.menu_array.push({type:this.menu_types.TYPE_VALUE,var_name:UI.AddCheckbox(created_var_name),is_item_visible:true})-1},create_slider_int:function(created_var_name,created_var_min,created_var_max){return this.menu_array.push({type:this.menu_types.TYPE_VALUE,var_name:UI.AddSliderInt(created_var_name,created_var_min,created_var_max),is_item_visible:true})-1},create_slider_float:function(created_var_name,created_var_min,created_var_max){return this.menu_array.push({type:this.menu_types.TYPE_VALUE,var_name:UI.AddSliderFloat(created_var_name,created_var_min,created_var_max),is_item_visible:true})-1},create_dropdown:function(created_var_name,created_var_dropdown_array){return this.menu_array.push({type:this.menu_types.TYPE_VALUE,var_name:UI.AddDropdown(created_var_name,created_var_dropdown_array),is_item_visible:true})-1},create_multi_dropdown:function(created_var_name,created_var_dropdown_array){return this.menu_array.push({type:this.menu_types.TYPE_VALUE,var_name:UI.AddMultiDropdown(created_var_name,created_var_dropdown_array),is_item_visible:true})-1},create_colorpicker:function(created_var_name){return this.menu_array.push({type:this.menu_types.TYPE_COLOR,var_name:UI.AddColorPicker(created_var_name),is_item_visible:true})-1},create_keybind:function(created_var_name){return this.menu_array.push({type:this.menu_types.TYPE_KEYBIND,var_name:UI.AddHotkey(created_var_name),is_item_visible:true})-1},create_menu_reference:function(var_path,var_type){return this.menu_array.push({type:this.menu_types.TYPE_REFERENCE,var_name:var_path,is_item_visible:true,reference_subtype:var_type})-1},get_item_value:function(var_index){if(typeof this.menu_array[var_index]!="undefined"){const var_type=this.menu_array[var_index].type==this.menu_types.TYPE_REFERENCE?this.menu_array[var_index].reference_subtype:this.menu_array[var_index].type;switch(var_type){case this.menu_types.TYPE_VALUE:return UI.GetValue.apply(null,this.menu_array[var_index].var_name);case this.menu_types.TYPE_COLOR:return UI.GetColor.apply(null,this.menu_array[var_index].var_name);case this.menu_types.TYPE_KEYBIND:return UI.IsHotkeyActive.apply(null,this.menu_array[var_index].var_name);default:throw new Error("[onetap] invalid type specified for get_script_item_value call (variable name "+menu_array[var_index].var_name+", specified type: "+type+")\n")}}throw new Error("[onetap] invalid menu item specified for get_script_item_value\n")},set_item_visibility:function(var_index,visibility_status){if(typeof this.menu_array[var_index]!="undefined"){if(this.menu_array[var_index].is_item_visible!=visibility_status&&UI.IsMenuOpen()){UI.SetEnabled.apply(null,this.menu_array[var_index].var_name.concat(visibility_status));this.menu_array[var_index].is_item_visible=visibility_status}}else{throw new Error("[onetap] invalid menu item specified for set_item_visibility\n")}},set_item_value:function(var_index,new_value){if(typeof this.menu_array[var_index]!="undefined"){const var_type=this.menu_array[var_index].type==this.menu_types.TYPE_REFERENCE?this.menu_array[var_index].reference_subtype:this.menu_array[var_index].type;switch(var_type){case this.menu_types.TYPE_VALUE:UI.SetValue.apply(null,this.menu_array[var_index].var_name.concat(new_value));break;case this.menu_types.TYPE_COLOR:UI.SetColor.apply(null,this.menu_array[var_index].var_name.concat(new_value));break;case this.menu_types.TYPE_KEYBIND:const keybind_state=this.get_item_value(var_index);if(keybind_state!=new_value){UI.ToggleHotkey.apply(null,this.menu_array[var_index].var_name)}break;default:throw new Error("[onetap] invalid type specified for set_item_value (variable name "+menu_array[var_index].var_name+", specified type: "+this.menu_array[var_index].type+")\n")}}else{throw new Error("[onetap] invalid menu item specified for set_item_value\n")}}};const master_switch=menu.create_checkbox("Doubletap improvements");const doubletap_speed=menu.create_slider_int("Speed",0,4);const doubletap_enabled_hotkey_reference=menu.create_menu_reference(["Rage","Doubletap"],menu.menu_types.TYPE_KEYBIND);const doubletap_enabled_value_reference=menu.create_menu_reference(["Rage","Doubletap"],menu.menu_types.TYPE_VALUE);const utility={log_prefix:"",log_prefix_col:[0,255,0,200],log:function(string){Cheat.PrintColor(this.log_prefix_col,this.log_prefix);Cheat.Print(string+"\n")}};const able_to_shift_shot=function(local,ticks_to_shift){const server_time=(Entity.GetProp(local,"CCSPlayer","m_nTickBase")-ticks_to_shift)*Globals.TickInterval();return server_time>Entity.GetProp(local,"CCSPlayer","m_flNextAttack")&&server_time>Entity.GetProp(Entity.GetWeapon(local),"CBaseCombatWeapon","m_flNextPrimaryAttack")};const on_move=function(){if(menu.get_item_value(doubletap_enabled_value_reference)&&menu.get_item_value(doubletap_enabled_hotkey_reference)&&menu.get_item_value(master_switch)){const desired_doubletap_speed=menu.get_item_value(doubletap_speed);Exploit.OverrideShift(10+desired_doubletap_speed);Exploit.OverrideTolerance(4-desired_doubletap_speed);const local=Entity.GetLocalPlayer();const exploit_charge=Exploit.GetCharge();exploit_charge!=1?Exploit.EnableRecharge():Exploit.DisableRecharge();const able_to_shift=able_to_shift_shot(local,12+desired_doubletap_speed);const can_doubletap=exploit_charge==1&&able_to_shift;var should_recharge_doubletap=!can_doubletap&&able_to_shift;const enemies=Entity.GetEnemies().filter(function(entity_index){return Entity.IsValid(entity_index)&&Entity.IsAlive(entity_index)&&!Entity.IsDormant(entity_index)});const local_eyepos=Entity.GetEyePosition(local);if(can_doubletap||should_recharge_doubletap){for(var i=0;i<enemies.length;i++){const entity_index=enemies[i];const entity_health=Entity.GetProp(entity_index,"CBasePlayer","m_iHealth");for(var hitbox=2;hitbox<=4;hitbox++){const hitbox_position=Entity.GetHitboxPosition(entity_index,hitbox);if(typeof hitbox_position!="undefined"){const trace=Trace.Bullet(local,entity_index,local_eyepos,hitbox_position);if(can_doubletap&&trace[1]>=entity_health/2){Ragebot.ForceTargetMinimumDamage(entity_index,entity_health/2)}else if(should_recharge_doubletap&&trace[2]){should_recharge_doubletap=false;break}}}}}if(should_recharge_doubletap){Exploit.DisableRecharge();Exploit.Recharge()}}};const on_unload=function(){Exploit.EnableRecharge()};Cheat.RegisterCallback("CreateMove","on_move");Cheat.RegisterCallback("Unload","on_unload");function vectorangles(forward){var angles=[];if(forward[1]==0&&forward[0]==0){angles[0]=forward[2]>0?270:90;angles[1]=0}else{angles[0]=Math.atan2(-forward[2],Math.sqrt(forward[0]*forward[0]+forward[1]*forward[1]))*-180/Math.PI;angles[1]=Math.atan2(forward[1],forward[0])*180/Math.PI;if(angles[1]>90)angles[1]-=180;else if(angles[1]<90)angles[1]+=180;else if(angles[1]==90)angles[1]=0}return angles}function anglevectors(angles){var sy=Math.sin(angles[1]*180/Math.PI);var cy=Math.cos(angles[1]*180/Math.PI);var sp=Math.sin(angles[0]*180/Math.PI);var cp=Math.cos(angles[0]*180/Math.PI);return[cp*cy,cp*sy,-sp]}var currentAction=2;var lastTickShot=0;function reset(){lastTickShot=0}var lasttarget=0;function onRageShoot(){if(!UI.IsHotkeyActive("Rage","GENERAL","Exploits","Doubletap")&&!UI.GetValue("Rage","GENERAL","Exploits","Doubletap"))return;var type=Event.GetInt("exploit");if(type==1){currentAction=1;lastTickShot=Globals.Tickcount()}if(type==2){currentAction=2}lasttarget=Event.GetInt("target_index")}function onCM(){var local=Entity.GetLocalPlayer();if(!local||!Entity.IsAlive(local)||currentAction==2)return;if(!UI.IsHotkeyActive("Rage","GENERAL","Exploits","Doubletap")&&!UI.GetValue("Rage","GENERAL","Exploits","Doubletap"))return;if(!Entity.IsAlive(lasttarget)||lastTickShot+12<Globals.Tickcount()){lasttarget=0;return}var velo=Entity.GetProp(local,"DT_CSPlayer","m_vecVelocity[0]");var speed=Math.sqrt(velo[0]*velo[0]+velo[1]*velo[2]+velo[2]*velo[2]);var direction=vectorangles(velo);direction[1]=Local.GetViewAngles()[1]-direction[1];var forward=anglevectors(direction);var negative=[];negative[0]=forward[0]*speed;negative[1]=forward[1]*speed;negative[2]=forward[2]*speed;UserCMD.SetMovement([negative[0],negative[1],0])}Cheat.RegisterCallback("ragebot_fire","onRageShoot");Cheat.RegisterCallback("CreateMove","onCM");Cheat.RegisterCallback("round_start","reset");UI.AddCheckbox("Damage Override");UI.AddHotkey("Override Hotkey");UI.AddCheckbox("Display indicator");UI.AddSliderInt("Heavy Pistol Mindmg",0,130);UI.AddSliderInt("Scout Mindmg",0,130);UI.AddSliderInt("AWP Mindmg",0,130);UI.AddSliderInt("Auto Mindmg",0,130);var heavy_cache=UI.GetValue("Rage","HEAVY PISTOL","Targeting","Minimum damage");var scout_cache=UI.GetValue("Rage","SCOUT","Targeting","Minimum damage");var awp_cache=UI.GetValue("Rage","AWP","Targeting","Minimum damage");var auto_cache=UI.GetValue("Rage","AUTOSNIPER","Targeting","Minimum damage");function isActive(a){return UI.IsHotkeyActive("JAVASCRIPT",a)}function setValue(cat,value){UI.SetValue("Rage",cat.toUpperCase(),"Targeting","Minimum damage",value)}function isHeavyPistol(name){if(name=="r8 revolver"||name=="desert eagle"){return true}}function isAutoSniper(name){if(name=="scar 20"||weapon_name=="g3sg1"){return true}}function onCM(){heavy_value=UI.GetValue("Script items","Heavy Pistol Mindmg");scout_value=UI.GetValue("Script items","Scout Mindmg");awp_value=UI.GetValue("Script items","AWP Mindmg");auto_value=UI.GetValue("Script items","Auto Mindmg");weapon_name=Entity.GetName(Entity.GetWeapon(Entity.GetLocalPlayer()));if(isActive("Override Hotkey")&&isHeavyPistol(weapon_name)&&UI.GetValue("Damage Override")){setValue("HEAVY PISTOL",heavy_value)}else{setValue("HEAVY PISTOL",heavy_cache)}if(isActive("Override Hotkey")&&weapon_name=="ssg 08"&&UI.GetValue("Damage Override")){setValue("SCOUT",scout_value)}else{setValue("SCOUT",scout_cache)}if(isActive("Override Hotkey")&&weapon_name=="awp"&&UI.GetValue("Damage Override")){setValue("AWP",awp_value)}else{setValue("AWP",awp_cache)}if(isActive("Override Hotkey")&&isAutoSniper(weapon_name)&&UI.GetValue("Damage Override")){setValue("AUTOSNIPER",auto_value)}else{setValue("AUTOSNIPER",auto_cache)}}function indicator(){font=Render.AddFont("Tahoma",17,600);screen=Render.GetScreenSize();wep=Entity.GetName(Entity.GetWeapon(Entity.GetLocalPlayer()));x=screen[0]-screen[0]+20;y=screen[1]-100;heavy=""+UI.GetValue("Rage","HEAVY PISTOL","Targeting","Minimum damage");scout=""+UI.GetValue("Rage","SCOUT","Targeting","Minimum damage");awp=""+UI.GetValue("Rage","AWP","Targeting","Minimum damage");auto=""+UI.GetValue("Rage","AUTOSNIPER","Targeting","Minimum damage");var str="";if(UI.GetValue("Script items","Display indicator")&&Entity.IsValid(Entity.GetLocalPlayer())&&Entity.IsAlive(Entity.GetLocalPlayer())){if(isHeavyPistol(wep)){str=heavy}else if(wep=="ssg 08"){str=scout}else if(wep=="awp"){str=awp}else if(isAutoSniper(wep)){str=auto}}if(str==""+0){str="DYNAMIC"}Render.StringCustom(x+1,y+1,0,str+"",[0,0,0,255],font);Render.StringCustom(x,y,0,str+"",[255,255,255,255],font)}Cheat.RegisterCallback("Draw","indicator");Cheat.RegisterCallback("CreateMove","onCM");UI.AddCheckbox("Hitbox Conditions");UI.AddMultiDropdown("Head conditions",["If in air","If crouching"]);UI.AddMultiDropdown("Body conditions",["If lethal","If slow-walking","If standing","If in air","If crouching"]);UI.AddMultiDropdown("Safety conditions",["If lethal","If slow-walking","If standing","If in air","If crouching"]);UI.AddCheckbox("Safety Flags");var info=[];var safe=[];function get_value(item){return UI.GetValue("Misc","JAVASCRIPT","Script items",item)}function get_proper_eye(){var local_player=Entity.GetLocalPlayer();var origin=Entity.GetRenderOrigin(local_player);if(UI.IsHotkeyActive("Anti-Aim","Extra","Fake duck"))return[origin[0],origin[1],origin[2]+46+18];else return Entity.GetEyePosition(local_player)}function extrapolate_tick(entity,ticks,x,y,z){var velocity=Entity.GetProp(entity,"CBasePlayer","m_vecVelocity[0]");var new_pos=[x,y,z];new_pos[0]=new_pos[0]+velocity[0]*Globals.TickInterval()*ticks;new_pos[1]=new_pos[1]+velocity[1]*Globals.TickInterval()*ticks;new_pos[2]=new_pos[2]+velocity[2]*Globals.TickInterval()*ticks;return new_pos}function force_head(entity){disable_body();var local_player=Entity.GetLocalPlayer();var eye_pos=get_proper_eye();var head_pos=Entity.GetHitboxPosition(entity,0);var head_damage=Trace.Bullet(local_player,entity,eye_pos,head_pos);Ragebot.ForceTargetMinimumDamage(entity,head_damage[1])}function force_body(){if(!UI.IsHotkeyActive("Rage","GENERAL","General","Force body aim"))UI.ToggleHotkey("Rage","GENERAL","General","Force body aim")}function disable_body(){if(UI.IsHotkeyActive("Rage","GENERAL","General","Force body aim"))UI.ToggleHotkey("Rage","GENERAL","General","Force body aim")}function force_safe(){if(!UI.IsHotkeyActive("Rage","GENERAL","General","Force safe point"))UI.ToggleHotkey("Rage","GENERAL","General","Force safe point")}function disable_safe(){if(UI.IsHotkeyActive("Rage","GENERAL","General","Force safe point"))UI.ToggleHotkey("Rage","GENERAL","General","Force safe point")}function is_standing(entity){var entity_velocity=Entity.GetProp(entity,"CBasePlayer","m_vecVelocity[0]");var entity_speed=Math.sqrt(entity_velocity[0]*entity_velocity[0]+entity_velocity[1]*entity_velocity[1]);if(entity_speed>=0&&entity_speed<10)return true;else return false}function is_crouching(entity){var flags=Entity.GetProp(entity,"CBasePlayer","m_fFlags");if(flags&1<<1)return true;else return false}function is_slowwalking(entity){var entity_velocity=Entity.GetProp(entity,"CBasePlayer","m_vecVelocity[0]");var entity_speed=Math.sqrt(entity_velocity[0]*entity_velocity[0]+entity_velocity[1]*entity_velocity[1]);if(entity_speed>=10&&entity_speed<=85)return true;else return false}function is_inair(entity){var flags=Entity.GetProp(entity,"CBasePlayer","m_fFlags");if(!(flags&1<<0)&&!(flags&1<<18))return true;else return false}function is_lethal(entity){var local_player=Entity.GetLocalPlayer();var eye_pos=get_proper_eye();var local_pos=extrapolate_tick(local_player,25,eye_pos[0],eye_pos[1],eye_pos[2]);var entity_hp=Entity.GetProp(entity,"CBasePlayer","m_iHealth");var pelvis_pos=Entity.GetHitboxPosition(entity,2);var body_pos=Entity.GetHitboxPosition(entity,3);var thorax_pos=Entity.GetHitboxPosition(entity,4);var pelvis_trace=Trace.Bullet(local_player,entity,local_pos,pelvis_pos);var body_trace=Trace.Bullet(local_player,entity,local_pos,body_pos);var thorax_trace=Trace.Bullet(local_player,entity,local_pos,thorax_pos);var pelvis_dmg=pelvis_trace[1];var body_dmg=body_trace[1];var thorax_dmg=thorax_trace[1];var lethal_damage=Math.max(pelvis_dmg,body_dmg,thorax_dmg);if(entity_hp<=lethal_damage)return true;else return false}function draw_flags(){enemies=Entity.GetEnemies();for(i=0;i<enemies.length;i++){if(!Entity.IsValid(enemies[i]))continue;if(!Entity.IsAlive(enemies[i]))continue;if(Entity.IsDormant(enemies[i]))continue;var pos=Entity.GetRenderBox(enemies[i]);var font=Render.AddFont("Verdana",7,700);var a=pos[3]-pos[1];a/=2;a+=pos[1];switch(info[enemies[i]]){case"HEAD":Render.StringCustom(a,pos[2]-25,1,"HEAD",[10,10,10,125],font);Render.StringCustom(a-1,pos[2]-25,1,"HEAD",[255,95,95,255],font);break;case"BODY":Render.StringCustom(a,pos[2]-25,1,"BODY",[10,10,10,125],font);Render.StringCustom(a-1,pos[2]-25,1,"BODY",[237,144,255,255],font);break;case"PREFER":Render.StringCustom(a,pos[2]-25,1,"PREFER",[10,10,10,125],font);Render.StringCustom(a-1,pos[2]-25,1,"PREFER",[95,186,255,255],font);break}switch(safe[enemies[i]]){case"SAFE":Render.StringCustom(a,pos[2]-35,1,"SAFE",[10,10,10,125],font);Render.StringCustom(a-1,pos[2]-35,1,"SAFE",[211,255,144,255],font);break}}}function conditions(){if(get_value("Hitbox Conditions")){enemies=Entity.GetEnemies();local_player=Entity.GetLocalPlayer();for(i=0;i<enemies.length;i++){if(!Entity.IsValid(enemies[i]))continue;if(!Entity.IsAlive(enemies[i]))continue;if(Entity.IsDormant(enemies[i]))continue;if(get_value("Hitbox Conditions")){head_condtions=get_value("Head conditions");body_condtions=get_value("Body conditions");safe_condtions=get_value("Safety conditions");if(safe_condtions&1<<0&&is_lethal(enemies[i])||safe_condtions&1<<1&&is_slowwalking(enemies[i])||safe_condtions&1<<2&&is_standing(enemies[i])||safe_condtions&1<<3&&is_inair(enemies[i])||safe_condtions&1<<4&&is_crouching(enemies[i])){if(get_value("Safety Flags")){force_safe();safe[enemies[i]]="SAFE"}else{force_safe()}}else{disable_safe();safe[enemies[i]]="NONE"}if(head_condtions&1<<0&&is_inair(enemies[i])||head_condtions&1<<1&&is_crouching(enemies[i])){if(get_value("Safety Flags")){force_head(enemies[i]);info[enemies[i]]="HEAD"}else{force_head(enemies[i])}}else if(body_condtions&1<<0&&is_lethal(enemies[i])||body_condtions&1<<1&&is_slowwalking(enemies[i])||body_condtions&1<<2&&is_standing(enemies[i])||body_condtions&1<<3&&is_inair(enemies[i])||body_condtions&1<<4&&is_crouching(enemies[i])){if(get_value("Safety Flags")){force_body();info[enemies[i]]="BODY"}else{force_body()}}else{if(get_value("Safety Flags")){disable_body();info[enemies[i]]="PREFER"}else{disable_body()}}}}}}Cheat.RegisterCallback("Draw","draw_flags");Cheat.RegisterCallback("CreateMove","conditions");UI.AddSliderInt("       +Miscellaneous/Visuals+",0,0);var screen_size=Global.GetScreenSize();UI.AddCheckbox("Indicators");var isInverted;LPx=[screen_size[0]/2-41,screen_size[1]/2+10];LPy=[screen_size[0]/2-41,screen_size[1]/2-10];LPz=[screen_size[0]/2-61,screen_size[1]/2+0];RPx=[screen_size[0]/2+41,screen_size[1]/2+10];RPy=[screen_size[0]/2+41,screen_size[1]/2-10];RPz=[screen_size[0]/2+61,screen_size[1]/2+0];BPx=[screen_size[0]/2+10,screen_size[1]/2+41];BPy=[screen_size[0]/2-10,screen_size[1]/2+41];BPz=[screen_size[0]/2-0,screen_size[1]/2+61];LPxx=[screen_size[0]/2-42,screen_size[1]/2+10];LPyy=[screen_size[0]/2-42,screen_size[1]/2-10];LPzz=[screen_size[0]/2-62,screen_size[1]/2+0];RPxx=[screen_size[0]/2+42,screen_size[1]/2+10];RPyy=[screen_size[0]/2+42,screen_size[1]/2-10];RPzz=[screen_size[0]/2+62,screen_size[1]/2+0];BPxx=[screen_size[0]/2+10,screen_size[1]/2+42];BPyy=[screen_size[0]/2-10,screen_size[1]/2+42];BPzz=[screen_size[0]/2-0,screen_size[1]/2+62];function render_arc(x,y,radius,radius_inner,start_angle,end_angle,segments,color){while(360%segments!=0){segments++}segments=360/segments;for(var i=start_angle;i<start_angle+end_angle;i=i+segments){var rad=i*Math.PI/180;var rad2=(i+segments)*Math.PI/180;var rad_cos=Math.cos(rad);var rad_sin=Math.sin(rad);var rad2_cos=Math.cos(rad2);var rad2_sin=Math.sin(rad2);var x1_outer=x+rad_cos*radius;var y1_outer=y+rad_sin*radius;var x2_outer=x+rad2_cos*radius;var y2_outer=y+rad2_sin*radius;var x1_inner=x+rad_cos*radius_inner;var y1_inner=y+rad_sin*radius_inner;var x2_inner=x+rad2_cos*radius_inner;var y2_inner=y+rad2_sin*radius_inner;Render.Polygon([[x1_outer,y1_outer],[x2_outer,y2_outer],[x1_inner,y1_inner]],color);Render.Polygon([[x1_inner,y1_inner],[x2_outer,y2_outer],[x2_inner,y2_inner]],color)}}function drawString1(){const alpha=Math.sin(Math.abs(-Math.PI+Globals.Curtime()*(1/1)%(Math.PI*2)))*255;const alphax=Math.sin(Math.abs(-Math.PI+Globals.Curtime()*(1/.5)%(Math.PI*2)))*255;isHideshots=UI.IsHotkeyActive("Rage","Exploits","Hide shots");isFakeduck=UI.IsHotkeyActive("Anti-Aim","Extra","Fake duck");isDoubletap=UI.IsHotkeyActive("Rage","Exploits","Doubletap");isInverted=UI.IsHotkeyActive("Anti-Aim","Inverter");isLbyMode=UI.GetValue("Anti-Aim","LBY mode");isBAIM=UI.IsHotkeyActive("Rage","Force body aim");isDesyncMode=UI.GetValue("Anti-Aim","Fake desync");localplayer_index=Entity.GetLocalPlayer();localplayer_alive=Entity.IsAlive(localplayer_index);charge=Exploit.GetCharge();max_angle=360*Exploit.GetCharge();center=Render.GetScreenSize();X=center[0]/2;Y=center[1]/2;if(localplayer_alive==true&&UI.GetValue("Indicators")){Render.String(screen_size[0]/2,screen_size[1]/2+76,1,isBAIM?"BODY":"NORM",[0,0,0,255],3);Render.String(screen_size[0]/2,screen_size[1]/2+116,1,isFakeduck?"DUCK":"",isFakeduck?[0,0,0,255]:[0,0,0,0],3);Render.String(screen_size[0]/2,screen_size[1]/2+75,1,isBAIM?"BODY":"NORM",isBAIM?[65,180,80,255]:[45,135,185,255],3);Render.String(screen_size[0]/2,screen_size[1]/2+115,1,isFakeduck?"DUCK":"",isFakeduck?[255,255,255,255]:[0,0,0,0],3);if(isDoubletap){if(charge>=1){Render.String(screen_size[0]/2,screen_size[1]/2+96,1,isDoubletap?"DT":"DT",isDoubletap?[0,0,0,255]:[0,0,0,255],3);Render.String(screen_size[0]/2,screen_size[1]/2+95,1,isDoubletap?"DT":"DT",isDoubletap?[65,180,80,255]:[255,0,0,255],3);Render.String(screen_size[0]/2,screen_size[1]/2+106,1,isHideshots?"HIDE":"ANIM",isHideshots?[0,0,0,255]:[0,0,0,255],3);Render.String(screen_size[0]/2,screen_size[1]/2+105,1,isHideshots?"HIDE":"ANIM",isHideshots?[145,120,229,255]:[255,153,0,alpha],3)}if(charge<1){Render.String(screen_size[0]/2-5,screen_size[1]/2+96,1,isDoubletap?"DT":"DT",isDoubletap?[0,0,0,255]:[0,0,0,255],3);Render.String(screen_size[0]/2-5,screen_size[1]/2+95,1,isDoubletap?"DT":"DT",isDoubletap?[255-charge*190,charge*180,charge*80,255]:[255,0,0,255],3);Render.String(screen_size[0]/2,screen_size[1]/2+106,1,"ANIM",[0,0,0,255],3);Render.String(screen_size[0]/2,screen_size[1]/2+105,1,"ANIM",[255,153,0,alpha],3);render_arc(X+8,Y+99,5,2.5,-90,360,36,[120,120,120,190]);render_arc(X+8,Y+99,5,2.5,-90,max_angle,36,[255-charge*190,charge*180,charge*80,255])}}if(!isDoubletap){Render.String(screen_size[0]/2,screen_size[1]/2+96,1,isDoubletap?"DT":"DT",isDoubletap?[0,0,0,255]:[0,0,0,255],3);Render.String(screen_size[0]/2,screen_size[1]/2+95,1,isDoubletap?"DT":"DT",isDoubletap?[65,180,80,255]:[255,0,0,255],3);Render.String(screen_size[0]/2,screen_size[1]/2+106,1,isHideshots?"HIDE":"ANIM",[0,0,0,255],3);Render.String(screen_size[0]/2,screen_size[1]/2+105,1,isHideshots?"HIDE":"ANIM",isHideshots?[145,120,229,255]:[255,153,0,alpha],3)}if(isDesyncMode==0){Render.String(screen_size[0]/2,screen_size[1]/2+86,1,isInverted?"LEFT":"RIGHT",[0,0,0,255],3);Render.String(screen_size[0]/2,screen_size[1]/2+85,1,isInverted?"LEFT":"RIGHT",[255,255,255,255],3)}else if(isDesyncMode==1){Render.String(screen_size[0]/2,screen_size[1]/2+86,1,isInverted?"RIGHT":"LEFT",[0,0,0,255],3);Render.String(screen_size[0]/2,screen_size[1]/2+85,1,isInverted?"RIGHT":"LEFT",[255,255,255,255],3)}}}function Main(){Global.RegisterCallback("Draw","drawString1")}Main();UI.AddCheckbox("Pulse Bar");function pulserect(){if(UI.GetValue("Pulse Bar")){const alpha=Math.sin(Math.abs(-Math.PI+Globals.Curtime()*(1/.75)%(Math.PI*2)))*255;var screensize=Global.GetScreenSize();Render.FilledRect(0,0,screensize[0],5,[251,204,209,alpha])}}Global.RegisterCallback("Draw","pulserect");UI.AddSliderInt("",0,0);UI.AddSliderInt("Doubletap Tolerance",0,3);function can_shift_shot(ticks_to_shift){var me=Entity.GetLocalPlayer();var wpn=Entity.GetWeapon(me);if(me==null||wpn==null)return false;var tickbase=Entity.GetProp(me,"CCSPlayer","m_nTickBase");var curtime=Globals.TickInterval()*(tickbase-ticks_to_shift);if(curtime<Entity.GetProp(me,"CCSPlayer","m_flNextAttack"))return false;if(curtime<Entity.GetProp(wpn,"CBaseCombatWeapon","m_flNextPrimaryAttack"))return false;return true}function _TBC_CREATE_MOVE(){var is_charged=Exploit.GetCharge();var reserve=UI.GetValue("Misc","JAVASCRIPT","Script items","Double tap tolerance");Exploit[(is_charged!=1?"Enable":"Disable")+"Recharge"]();if(can_shift_shot(14)&&is_charged!=1){Exploit.DisableRecharge();Exploit.Recharge()}Exploit.OverrideTolerance(reserve);Exploit.OverrideShift(14-reserve)}function _TBC_UNLOAD(){Exploit.EnableRecharge()}Cheat.RegisterCallback("CreateMove","_TBC_CREATE_MOVE");Cheat.RegisterCallback("Unload","_TBC_UNLOAD");UI.AddSliderInt("Better DT",1,3);UI.AddCheckbox("Better Doubletap");function on_ragebot_fire(){if(!UI.GetValue("Misc","JAVASCRIPT","Script items","Better Doubletap")){return}player=Entity.GetLocalPlayer();weapon=Entity.GetWeapon(player);weaponName=Entity.GetName(weapon);ragebot_target_exploit=Event.GetInt("exploit");if(ragebot_target_exploit==2){UI.SetValue("Rage","GENERAL","Exploits","Doubletap fast recovery",true)}else{UI.SetValue("Rage","GENERAL","Exploits","Doubletap fast recovery",false)}}Global.RegisterCallback("ragebot_fire","on_ragebot_fire");var flipper=1;function doFlip(){flipper*=-1}var font=false;function drawAALine(angle,len,color,text){var origin=Entity.GetProp(Entity.GetLocalPlayer(),"DT_BaseEntity","m_vecOrigin");var angleRad=angle*(Math.PI/180);var endPos=[origin[0],origin[1],origin[2]];endPos[0]+=Math.cos(angleRad)*len;endPos[1]+=Math.sin(angleRad)*len;var originScreen=Render.WorldToScreen(origin);var endScreen=Render.WorldToScreen(endPos);Render.Line(originScreen[0],originScreen[1],endScreen[0],endScreen[1],color);Render.String(endScreen[0]+1,endScreen[1]+1,1,text,[0,0,0,255],font);Render.String(endScreen[0],endScreen[1],1,text,color,font)}function render(){font=Render.GetFont("Arial.ttf",12,true);if(Entity.IsValid(Entity.GetLocalPlayer())){drawAALine(Local.GetFakeYaw(),40,[0,150,255,255],"FAKE");drawAALine(Local.GetRealYaw(),45,[255,0,0,255],"REAL");var delta=Math.abs(Math.round(Local.GetFakeYaw()-Local.GetRealYaw()));if(delta>180){delta-=360}drawAALine(Local.GetRealYaw(),0,[255,255,255,255],"DELTA: "+Math.abs(delta))}}var lastMove=false;var low=false;var ticker=0;function run(){ticker++;var v=Entity.GetProp(Entity.GetLocalPlayer(),"DT_CSPlayer","m_vecVelocity[0]");var speed=Math.sqrt(v[0]*v[0]+v[1]*v[1]+v[2]*v[2]);var shouldSwitch=speed>1!=lastMove;var crouch=Entity.GetProp(Entity.GetLocalPlayer(),"CCSPlayer","m_flDuckAmount")>.4;var deviator=Math.round(Globals.Realtime()*300)%100;deviator/=1e3;var mult=flipper;if(shouldSwitch&&deviator>.4){flipper*=-1;if(deviator>.6){low=!low}}AntiAim.SetOverride(1);if(speed<1){AntiAim.SetLBYOffset(-60*mult+deviator*6*mult);AntiAim.SetRealOffset(-14*mult);AntiAim.SetFakeOffset(5*mult*deviator)}else{var delta=51*flipper;if(low){delta/=5;if(ticker%20==0){delta*=8}}AntiAim.SetRealOffset(delta);AntiAim.SetFakeOffset(-delta/2)}lastMove=speed>1}Cheat.RegisterCallback("bullet_impact","doFlip");Cheat.RegisterCallback("CreateMove","run");Cheat.RegisterCallback("Draw","render");function getarget(){target=Ragebot.GetTarget();if(Entity.GetName(target)=="enemy"){Ragebot.IgnoreTarget(0)}}function calcAngle(source,entityPos){for(i=1,64;i<players.length;i)var delta=[i];delta[0]=source[0]-entityPos[0];delta[1]=source[1]-entityPos[1];delta[2]=source[2]-entityPos[2];var angles=[];var viewangles=Local.GetViewAngles();angles[0]=RADTODEG(Math.atan(delta[2]/Math.hypot(delta[0],delta[1])))-viewangles[0];angles[1]=RADTODEG(Math.atan(delta[1]/delta[0]))-viewangles[1];angles[2]=0;if(delta[0]>=t_delta)angles[1]+=t_delta;return angles}function geteyepos(){localplayer_eyepos=Entity.GetEyePosition(Entity.GetLocalPlayer());Cheat.Print("Local player eye pos X: "+localplayer_eyepos[0]+" Y: "+localplayer_eyepos[1]+" Z: "+localplayer_eyepos[2]+" \n")}function getenemieshead(){enemies=Entity.GetEnemies();for(i=1,64;i<enemies.length;i){hitbox_pos=Entity.GetHitboxPosition(enemies[i],0);enemyName=Entity.GetName(enemies[i]);Cheat.Print(enemyName+"'s HEAD hitbox position is X: "+hitbox_pos[0]+" Y: "+hitbox_pos[1]+" Z: "+hitbox_pos[2]+" \n")}}function seteyepos(){Entity.SetEyePosition(1)}function GetVelocity(index){var velocity=Entity.GetProp(index,"CBasePlayer","m_vecVelocity[0]");return Math.sqrt(velocity[0]*velocity[0]+velocity[1]*velocity[1])}function getmyenemy(){players=Entity.GetPlayers();for(i=1,64;i<players.length;i){if(Entity.IsEnemy(players[i])){plrName=Entity.GetName(players[i]);Cheat.Print("Player: "+plrName+" is enemy\n")}}}function setAngle(){curAngle=Local.GetViewAngles();UserCMD.SetViewAngles([curAngle[0],t_delta,curAngle[2]],true)}function getrealyaw(){realyaw=Local.GetRealYaw();Cheat.Print(realyaw+"\n")}function getfakeyaw(){fakeyaw=Local.GetFakeYaw();Cheat.Print(fakeyaw+"\n")}function getvalues(){t_delta=UI.GetValue("Misc","JAVASCRIPT","Script items","Delta:");t_ticks=UI.GetValue("Misc","JAVASCRIPT","Script items","Ticks:")}function extrapolate_tick(entity,ticks,x,y,z){velocity=Entity.GetProp(entity,"CBasePlayer","m_vecVelocity[0]");new_pos=[x,y,z];new_pos[0]=new_pos[0]+velocity[0]*Globals.TickInterval(t_ticks)*ticks;new_pos[1]=new_pos[1]+velocity[1]*Globals.TickInterval(t_ticks)*ticks;new_pos[2]=new_pos[2]+velocity[2]*Globals.TickInterval(t_ticks)*ticks;return new_pos}function tick_count(){Globals.Tickcount(t_ticks)}autoHitboxes=UI.GetValue("Rage","AUTOSNIPER","Targeting","Hitboxes");awpHitboxes=UI.GetValue("Rage","AWP","Targeting","Hitboxes");scoutHitboxes=UI.GetValue("Rage","SCOUT","Targeting","Hitboxes");heavyHitboxes=UI.GetValue("Rage","HEAVY PISTOL","Targeting","Hitboxes");pistolHitboxes=UI.GetValue("Rage","PISTOL","Targeting","Hitboxes");generalHitboxes=UI.GetValue("Rage","GENERAL","Targeting","Hitboxes");var original=true;function forceheadonkey(){if(World.GetServerString()!==""){var forceHeadOnly=UI.IsHotkeyActive("Misc","JAVASCRIPT","Script items","Force Head");if(forceHeadOnly==1){if(original===true){autoHitboxes=UI.GetValue("Rage","AUTOSNIPER","Targeting","Hitboxes");awpHitboxes=UI.GetValue("Rage","AWP","Targeting","Hitboxes");scoutHitboxes=UI.GetValue("Rage","SCOUT","Targeting","Hitboxes");heavyHitboxes=UI.GetValue("Rage","HEAVY PISTOL","Targeting","Hitboxes");pistolHitboxes=UI.GetValue("Rage","PISTOL","Targeting","Hitboxes");generalHitboxes=UI.GetValue("Rage","GENERAL","Targeting","Hitboxes");original=false}UI.SetValue("Rage","AUTOSNIPER","Targeting","Hitboxes",1);UI.SetValue("Rage","AWP","Targeting","Hitboxes",1);UI.SetValue("Rage","SCOUT","Targeting","Hitboxes",1);UI.SetValue("Rage","HEAVY PISTOL","Targeting","Hitboxes",1);UI.SetValue("Rage","PISTOL","Targeting","Hitboxes",1);UI.SetValue("Rage","GENERAL","Targeting","Hitboxes",1)}else{if(original!==true){UI.SetValue("Rage","AUTOSNIPER","Targeting","Hitboxes",autoHitboxes);UI.SetValue("Rage","AWP","Targeting","Hitboxes",awpHitboxes);UI.SetValue("Rage","SCOUT","Targeting","Hitboxes",scoutHitboxes);UI.SetValue("Rage","HEAVY PISTOL","Targeting","Hitboxes",heavyHitboxes);UI.SetValue("Rage","PISTOL","Targeting","Hitboxes",pistolHitboxes);UI.SetValue("Rage","GENERAL","Targeting","Hitboxes",generalHitboxes);original=true}}}}UI.AddSliderInt("Double tap speed (lower is faster)",0,3);function can_shift_shot(ticks_to_shift){var me=Entity.GetLocalPlayer();var wpn=Entity.GetWeapon(me);if(me==null||wpn==null)return false;var tickbase=Entity.GetProp(me,"CCSPlayer","m_nTickBase");var curtime=Globals.TickInterval()*(tickbase-ticks_to_shift);if(curtime<Entity.GetProp(me,"CCSPlayer","m_flNextAttack"))return false;if(curtime<Entity.GetProp(wpn,"CBaseCombatWeapon","m_flNextPrimaryAttack"))return false;return true}function _TBC_CREATE_MOVE(){var is_charged=Exploit.GetCharge();var reserve=UI.GetValue("Misc","JAVASCRIPT","Script items","Double tap speed (lower is faster)");Exploit[(is_charged!=1?"Enable":"Disable")+"Recharge"]();if(can_shift_shot(14)&&is_charged!=1){Exploit.DisableRecharge();Exploit.Recharge()}Exploit.OverrideTolerance(reserve);Exploit.OverrideShift(14-reserve)}function _TBC_UNLOAD(){Exploit.EnableRecharge()}Cheat.RegisterCallback("CreateMove","_TBC_CREATE_MOVE");Cheat.RegisterCallback("Unload","_TBC_UNLOAD");var screen_size=Global.GetScreenSize();var isLeftActive=UI.IsHotkeyActive("Misc","JAVASCRIPT","Script items","Left Hotkey");var isRightActive=UI.IsHotkeyActive("Misc","JAVASCRIPT","Script items","Right Hotkey");var isBackActive=UI.IsHotkeyActive("Misc","JAVASCRIPT","Script items","Back Hotkey");var isInverted;var drawLeft=0;var drawRight=0;var drawBack=1;UI.AddColorPicker("Selected arrow color");UI.AddHotkey("Left Hotkey");UI.AddHotkey("Back Hotkey");UI.AddHotkey("Right Hotkey");LPx=[screen_size[0]/2-50,screen_size[1]/2+10];LPy=[screen_size[0]/2-50,screen_size[1]/2-10];LPz=[screen_size[0]/2-70,screen_size[1]/2];RPx=[screen_size[0]/2+50,screen_size[1]/2+10];RPy=[screen_size[0]/2+50,screen_size[1]/2-10];RPz=[screen_size[0]/2+70,screen_size[1]/2];LPxx=[screen_size[0]/2-49,screen_size[1]/2+12];LPyy=[screen_size[0]/2-49,screen_size[1]/2-12];LPzz=[screen_size[0]/2-73,screen_size[1]/2];RPxx=[screen_size[0]/2+49,screen_size[1]/2+12];RPyy=[screen_size[0]/2+49,screen_size[1]/2-12];RPzz=[screen_size[0]/2+73,screen_size[1]/2];BPx=[screen_size[0]/2+10,screen_size[1]/2+50];BPy=[screen_size[0]/2-10,screen_size[1]/2+50];BPz=[screen_size[0]/2,screen_size[1]/2+70];BPxx=[screen_size[0]/2+12,screen_size[1]/2+49];BPyy=[screen_size[0]/2-12,screen_size[1]/2+49];BPzz=[screen_size[0]/2,screen_size[1]/2+73];function drawString(){selectedcp=UI.GetColor("Misc","JAVASCRIPT","Script items","Selected arrow color");selected_red=selectedcp[0];selected_green=selectedcp[1];selected_blue=selectedcp[2];selected_alpha=selectedcp[3];const alpha=Math.sin(Math.abs(-Math.PI+Globals.Curtime()*(1/.75)%(Math.PI*2)))*255;const alphaa=Math.sin(Math.abs(-Math.PI+Globals.Curtime()*(1/2)%(Math.PI*2)))*255;isHideshots=UI.IsHotkeyActive("Rage","Exploits","Hide shots");isFakeduck=UI.IsHotkeyActive("Anti-Aim","Extra","Fake duck");isDoubletap=UI.IsHotkeyActive("Rage","Exploits","Doubletap");isInverted=UI.IsHotkeyActive("Anti-Aim","Fake angles","Inverter");isDmgActive=UI.IsHotkeyActive("Rage","GENERAL","Accuracy","Minimum damage (on key)");isLbyMode=UI.GetValue("Anti-Aim","Fake angles","LBY mode");isDesyncMode=UI.GetValue("Anti-Aim","Fake angles","Fake desync");localplayer_index=Entity.GetLocalPlayer();localplayer_alive=Entity.IsAlive(localplayer_index);if(localplayer_alive==true){Render.Polygon([LPxx,LPzz,LPyy],[0,0,0,60]);Render.Polygon([RPyy,RPzz,RPxx],[0,0,0,60]);Render.Polygon([BPyy,BPxx,BPzz],[0,0,0,60]);Render.String(screen_size[0]/2+1,screen_size[1]/2+101,1,isLbyMode?"FAKE":"NORM",[0,0,0,255],3);Render.String(screen_size[0]/2+1,screen_size[1]/2+121,1,isDoubletap?"DT":"DT",isDoubletap?[0,0,0,255]:[0,0,0,255],3);Render.String(screen_size[0]/2+1,screen_size[1]/2+131,1,isDmgActive?"WALL":"DMG",isDmgActive?[0,0,0,255]:[0,0,0,255],3);Render.String(screen_size[0]/2+1,screen_size[1]/2+141,1,isHideshots?"HIDE":"ANIM",isHideshots?[0,0,0,255]:[0,0,0,255],3);Render.String(screen_size[0]/2+1,screen_size[1]/2+151,1,isFakeduck?"DUCK":"",isFakeduck?[0,0,0,255]:[0,0,0,0],3);Render.String(screen_size[0]/2,screen_size[1]/2+100,1,isLbyMode?"FAKE":"NORM",[0,255,255,255],3);Render.String(screen_size[0]/2,screen_size[1]/2+120,1,isDoubletap?"DT":"DT",isDoubletap?[0,255,0,255]:[255,0,0,255],3);Render.String(screen_size[0]/2,screen_size[1]/2+130,1,isDmgActive?"WALL":"DMG",isDmgActive?[255,159,212,255]:[255,159,212,255],3);Render.String(screen_size[0]/2,screen_size[1]/2+140,1,isHideshots?"HIDE":"ANIM",isHideshots?[145,120,229,255]:[255,153,0,alpha],3);Render.String(screen_size[0]/2,screen_size[1]/2+150,1,isFakeduck?"DUCK":"",isFakeduck?[255,255,255,255]:[0,0,0,0],3);if(isDesyncMode==0){Render.String(screen_size[0]/2+1,screen_size[1]/2+111,1,isInverted?"LEFT":"RIGHT",[0,0,0,255],3);Render.String(screen_size[0]/2,screen_size[1]/2+110,1,isInverted?"LEFT":"RIGHT",[255,255,255,255],3)}else if(isDesyncMode==1){Render.String(screen_size[0]/2+1,screen_size[1]/2+111,1,isInverted?"RIGHT":"LEFT",[0,0,0,255],3);Render.String(screen_size[0]/2,screen_size[1]/2+110,1,isInverted?"RIGHT":"LEFT",[255,255,255,255],3)}if(drawLeft){Render.Polygon([LPx,LPz,LPy],[selected_red,selected_green,selected_blue,selected_alpha])}else if(drawRight){Render.Polygon([RPy,RPz,RPx],[selected_red,selected_green,selected_blue,selected_alpha])}else if(drawBack){Render.Polygon([BPy,BPx,BPz],[selected_red,selected_green,selected_blue,selected_alpha])}}}function onCreateMove(){isLeftActive=UI.IsHotkeyActive("Misc","JAVASCRIPT","Script items","Left Hotkey");isRightActive=UI.IsHotkeyActive("Misc","JAVASCRIPT","Script items","Right Hotkey");isBackActive=UI.IsHotkeyActive("Misc","JAVASCRIPT","Script items","Back Hotkey");if(isLeftActive){drawLeft=1;drawBack=0;drawRight=0;UI.SetValue("Anti-Aim","Rage Anti-Aim","Yaw offset",-90);UI.SetValue("Anti-Aim","Fake Angles","Hide real angle",false)}else if(isRightActive){drawLeft=0;drawBack=0;drawRight=1;UI.SetValue("Anti-Aim","Rage Anti-Aim","Yaw offset",90);UI.SetValue("Anti-Aim","Fake Angles","Hide real angle",false)}else if(isBackActive){drawLeft=0;drawBack=1;drawRight=0;UI.SetValue("Anti-Aim","Rage Anti-Aim","Yaw offset",0);UI.SetValue("Anti-Aim","Fake Angles","Hide real angle",false)}}function Main(){Global.RegisterCallback("Draw","drawString");Global.RegisterCallback("CreateMove","onCreateMove")}Main();var iExploitID=0;var bDoubleTapped=false;var bShouldRecharge=false;var ForceCharge=false;var iLastShotTime=1;var props=0;var screen_size=Global.GetScreenSize();var old_percentage=0;UI.AddCheckbox("Tripletap");UI.AddDropdown("Tripletap Mode",["Full","Accurate"]);UI.SetValue("Rage","GENERAL","Exploits","Doubletap",1);UI.SetValue("Rage","GENERAL","Exploits","Teleport release",true);UI.AddCheckbox("Doubletap Indicator");UI.AddCheckbox("Teleport Indicator");UI.AddCheckbox("Onshot AA Indicator");UI.AddCheckbox("Min DMG Override Indicator");UI.AddCheckbox("Full Teleport");function on_ragebot_fire(){ragebot_target_exploit=Event.GetInt("exploit");if(UI.GetValue("Misc","JAVASCRIPT","Script items","Tripletap")){if(UI.GetValue("Misc","JAVASCRIPT","Script items","Full Teleport")){ragebot_target_exploit==2?UI.ToggleHotkey("Rage","GENERAL","Exploits","Doubletap"):UI.ToggleHotkey("Rage","GENERAL","Exploits","Doubletap")}if(ragebot_target_exploit==2){UI.SetValue("Rage","GENERAL","Exploits","Doubletap fast recovery",true)}else{UI.SetValue("Rage","GENERAL","Exploits","Doubletap fast recovery",true)}}}function event_rbot_fire(){if(!player_hurt)return;iExploitID=Event.GetInt("exploit");if(!UI.GetValue("Misc","JAVASCRIPT","Script Items","Tripletap"))return;if(iExploitID==2){iLastShotTime=Global.Tickcount();bDoubleTapped=true;UI.SetValue("Rage","GENERAL","Exploits","Doubletap",0);bShouldRecharge=true}ForceCharge=bShouldRecharge?true:false;if(ForceCharge&&Global.Tickcount()>=Global.TickInterval()*10+iLastShotTime)UI.SetValue("Rage","GENERAL","Exploits","Doubletap",1)}function event_ragebot_fire(){ragebot_target_exploit=Event.GetInt("exploit");if(!UI.GetValue("Misc","JAVASCRIPT","Script Items","Tripletap")){ragebot_target_exploit==2?UI.ToggleHotkey("Rage","GENERAL","Exploits","Doubletap"):UI.ToggleHotkey("Rage","GENERAL","Exploits","Doubletap")}}function modecheck(){if(UI.GetValue("Misc","JAVASCRIPT","Script items","Tripletap Mode")==0){on_ragebot_fire()}if(UI.GetValue("Misc","JAVASCRIPT","Script items","Tripletap Mode")==1){event_rbot_fire()}UI.SetValue("Rage","GENERAL","Exploits","Teleport release",true)}function getPercentage(number,percentage){return percentage/100*number}function main(){if(!UI.GetValue("Misc","JAVASCRIPT","Script Items","Doubletap Indicator"))return;const screenSize=Global.GetScreenSize();const gapX=getPercentage(screenSize[0],48);const gapY=getPercentage(screenSize[1],54);if(UI.IsHotkeyActive("Rage","GENERAL","Exploits","Doubletap")){Render.String(gapX,gapY,0,"DoubleTap",[10,255,114,254],4,3)}}function EXTToggle(){UI.SetValue("Misc","JAVASCRIPT","Script items","Full Teleport",false);Render.String(25,1e3-5,0," ",[255,0,0,255],4.6);if(UI.IsHotkeyActive("Misc","JAVASCRIPT","Script Items","EXTToggle")){UI.SetValue("Misc","JAVASCRIPT","Script items","Full Teleport",true);Render.String(25,1e3-5,0," ",[0,255,0,255],4.6)}}function EXTKey(){UI.AddHotkey("Toggle Teleport","JAVASCRIPT","Script Items","EXTToggle")}function tp(){if(!UI.GetValue("Misc","JAVASCRIPT","Script Items","Teleport Indicator"))return;const screenSize=Global.GetScreenSize();const gapX=getPercentage(screenSize[0],48.5);const gapY=getPercentage(screenSize[1],56);if(UI.GetValue("Misc","JAVASCRIPT","Script items","Full Teleport")){Render.String(gapX,gapY,0,"Teleport",[10,255,114,254],4,3)}}function hs(){if(!UI.GetValue("Misc","JAVASCRIPT","Script Items","Onshot AA Indicator"))return;const screenSize=Global.GetScreenSize();const gapX=getPercentage(screenSize[0],51);const gapY=getPercentage(screenSize[1],58);if(UI.IsHotkeyActive("Rage","GENERAL","Exploits","Hide shots")){Render.String(gapX,gapY,0,"HS",[10,229,225,255],4,3)}}function dmg(){if(!UI.GetValue("Misc","JAVASCRIPT","Script Items","Min DMG Override Indicator"))return;const screenSize=Global.GetScreenSize();const gapX=getPercentage(screenSize[0],51);const gapY=getPercentage(screenSize[1],60);if(UI.IsHotkeyActive("Rage","GENERAL","Accuracy","Minimum Damage (on key)")){Render.String(gapX,gapY,0,"DMG",[10,229,225,255],4,3)}}Global.RegisterCallback("Draw","main");Global.RegisterCallback("Draw","tp");Global.RegisterCallback("Draw","hs");Global.RegisterCallback("Draw","dmg");Global.RegisterCallback("ragebot_fire","modecheck");Global.RegisterCallback("Draw","EXTToggle");EXTKey();var fps=0;var iterate=0;var averagefps=0;function watermark(){var fps1=1/Global.Frametime();var fps2=Math.floor(fps1);averagefps=(fps1+fps2)/2;iterate++;if(iterate%100==0){fps=Math.floor(averagefps)}var today=new Date;var hours=today.getHours();var currenthours=hours%12;var pmamtext=hours>=12?"PM":"AM";var minutestext=today.getMinutes()>=10?today.getMinutes():"0"+today.getMinutes();var datetime=currenthours+":"+minutestext+" "+pmamtext;Render.FilledRect(0,0,6e3,25,[30,30,39,255]);Render.GradientRect(0,25,6e3,3,3,[165,24,71,255],[58,31,87,255]);font=Render.AddFont("eagle",14,100);font2=Render.AddFont("Gotham Bold",12,100);Render.StringCustom(180,2,1,"  insecure | "+Cheat.GetUsername()+" | "+datetime+" | fps: "+fps,[255,255,255,255],font2);Render.StringCustom(15,2,1," a",[255,255,255,255],font)}UI.AddCheckbox("Teleport on peek");UI.AddHotkey("Key");UI.AddSliderInt("Predicted ticks",2,5);UI.AddSliderFloat("Teleport cooldown",1,10);UI.AddSliderInt("Minimum damage to trigger teleport",1,20);UI.AddCheckbox("Enable doubletap after teleport");UI.AddCheckbox("Recharge after teleport");UI.AddCheckbox("Render indicator");var vector={_class:"vector"};vector["new"]=function(data){return{x:data[0],y:data[1],z:data[2]}};vector.operate=function(vec,vec2,operation){switch(operation){case"+":return{x:vec.x+vec2.x,y:vec.y+vec2.y,z:vec.z+vec2.z};case"-":return{x:vec.x-vec2.x,y:vec.y-vec2.y,z:vec.z-vec2.z};case"*":return{x:vec.x*vec2.x,y:vec.y*vec2.y,z:vec.z*vec2.z};case"x":return{x:vec.x*vec2,y:vec.y*vec2,z:vec.z*vec2};case"/":return{x:vec.x/vec2.x,y:vec.y/vec2.y,z:vec.z/vec2.z};default:throw new Error("[Vector] Invalid operation type.")}};vector.to_array=function(vec){return[vec.x,vec.y,vec.z]};function extrapolate_tick(headpos,velocity,tick_amt){return vector.operate(headpos,vector.operate(velocity,tick_amt*Globals.TickInterval(),"x"),"+")}var has_teleported=false;var should_teleport=false;var last_teleport_time=.5;var js_items=["Misc","JAVASCRIPT","Script Items"];function on_move(){if(UI.GetValue(js_items,"Teleport on peek")&&UI.IsHotkeyActive(js_items,"Key")){var is_dt_enabled=UI.IsHotkeyActive("Rage","Exploits","Doubletap");var teleport_cooldown=UI.GetValue(js_items,"Teleport cooldown");if(Globals.Curtime()>last_teleport_time+teleport_cooldown){if(is_dt_enabled&&Exploit.GetCharge()<.17){return}if(should_teleport&&!has_teleported){if(is_dt_enabled){UI.ToggleHotkey("Rage","Exploits","Doubletap");last_teleport_time=Globals.Curtime();should_teleport=false;has_teleported=true;return}else{UI.ToggleHotkey("Rage","Exploits","Doubletap");return}}var local=Entity.GetLocalPlayer();var local_eyepos=Entity.GetEyePosition(local);var local_eyepos_vector=vector["new"](local_eyepos);var local_velocity=Entity.GetProp(local,"CBasePlayer","m_vecVelocity[0]");var local_velocity_vector=vector["new"](local_velocity);var extrapolated_headpos=extrapolate_tick(local_eyepos_vector,local_velocity_vector,UI.GetValue(js_items,"Predicted ticks"));var enemies=Entity.GetEnemies();var teleport_mindamage=UI.GetValue(js_items,"Minimum damage to trigger teleport");if(!should_teleport&&!has_teleported){for(var i=0;i<enemies.length;i++){if(Entity.IsValid(enemies[i])&&Entity.IsAlive(enemies[i])&&!Entity.IsDormant(enemies[i])){var enemy_headpos=Entity.GetHitboxPosition(enemies[i],0);var enemy_pelvispos=Entity.GetHitboxPosition(enemies[i],2);var trace=Trace.Bullet(local,enemies[i],vector.to_array(extrapolated_headpos),enemy_pelvispos);var trace2=Trace.Bullet(local,enemies[i],vector.to_array(extrapolated_headpos),enemy_headpos);if(trace[1]>teleport_mindamage||trace2[1]>teleport_mindamage){should_teleport=true;break}}}}}else if(has_teleported){var should_attempt_to_reenable_dt=UI.GetValue(js_items,"Enable doubletap after teleport");var should_attempt_to_recharge=UI.GetValue(js_items,"Recharge after teleport");if(should_attempt_to_reenable_dt){if(!is_dt_enabled){UI.ToggleHotkey("Rage","Exploits","Doubletap")}if(should_attempt_to_recharge){Exploit.Recharge()}}has_teleported=false}}}function update_menu(){var is_script_enabled=UI.GetValue(js_items,"Teleport on peek");UI.SetEnabled(js_items,"Key",is_script_enabled);UI.SetEnabled(js_items,"Predicted ticks",is_script_enabled);UI.SetEnabled(js_items,"Teleport cooldown",is_script_enabled);UI.SetEnabled(js_items,"Minimum damage to trigger teleport",is_script_enabled);UI.SetEnabled(js_items,"Enable doubletap after teleport",is_script_enabled);var is_dt_shit_enabled=UI.GetValue(js_items,"Enable doubletap after teleport");UI.SetEnabled(js_items,"Recharge after teleport",is_script_enabled&&is_dt_shit_enabled);UI.SetEnabled(js_items,"Render indicator",is_script_enabled)}function indicator(){if(UI.GetValue(js_items,"Teleport on peek")&&UI.GetValue(js_items,"Render indicator")&&UI.IsHotkeyActive(js_items,"Key")){if(World.GetServerString()==""){return}if(!Entity.IsAlive(Entity.GetLocalPlayer())){return}var screen_size=Render.GetScreenSize();var teleport_cooldown=UI.GetValue(js_items,"Teleport cooldown");Render.String(30,screen_size[1]*.924,1,"                  Teleport on peek",Globals.Curtime()>last_teleport_time+teleport_cooldown?[255*(1-Exploit.GetCharge()),2555*Exploit.GetCharge(),0,255]:[255,0,0,200],4)}}function reset_shit(){has_teleported=false;should_teleport=false;last_teleport_time=0}var tags={"insecure.js":"insecure.js"};function collect_keys(tbl,custom){var keys=Object.keys(tbl);if(custom){keys.unshift("Disabled");keys.push("Custom")}return keys}var __lastSetClanTag="";function _setClanTag(tag){if(__lastSetClanTag==tag)return false;__lastSetClanTag=tag;Local.SetClanTag(tag);return true}var tag="";var tag_index=0;var tag_index_offset=0;var tag_length=0;var tag_reverse=0;var tag_last_index=0;var time_last_update=0;var update_after=Globals.Curtime();var commands=0;function staticTag(){if(tag=="Disabled")return;_setClanTag(tag)}function timeTag(){var curTime=Globals.Curtime();if(curTime-time_last_update<1)return;time_last_update=curTime;var curDate=new Date;var hours=curDate.getHours()+"";if(hours.length==1)hours="0"+hours;var minutes=curDate.getMinutes()+"";if(minutes.length==1)minutes="0"+minutes;var seconds=curDate.getSeconds()+"";if(seconds.length==1)seconds="0"+seconds;var time_tag=hours+":"+minutes+":"+seconds;_setClanTag(time_tag)}function defaultTag(){if(tag_index==tag_last_index)return;_setClanTag(tag_index==0?"\0":tag.substr(0,tag_index))}function reverseTag(){if(tag_index==tag_last_index)return;if(tag_reverse<=tag_length){_setClanTag(tag.substr(0,tag_index))}else{_setClanTag(tag_length-tag_index==0?"\0":tag.substr(0,tag_length-tag_index))}}function loopTag(){if(tag_index==tag_last_index)return;var loop_tag=tag;for(var i=0;i<=tag_index;i++){loop_tag=loop_tag+loop_tag.substr(0,1);loop_tag=loop_tag.substr(1,loop_tag.length)}_setClanTag(loop_tag)}function loopTagSkip(force){force=force||false;if(tag_index==tag_last_index&&!force)return;var loop_tag=tag;for(var i=0;i<=tag_index;i++){loop_tag=loop_tag+loop_tag.substr(0,1);loop_tag=loop_tag.substr(1,loop_tag.length)}var visibleTag=loop_tag.substr(0,15).trim();if(visibleTag.length==1){var realLength=loop_tag.length/3;var idx=9+(realLength-8)*3;if(tag_index==idx){tag_index++;tag_last_index++;tag_index_offset++;return loopTagSkip(true)}}_setClanTag(loop_tag)}function killDickTag(){var curTime=Globals.Curtime();if(curTime-time_last_update<.3)return;time_last_update=curTime;var killdick_mode=getUIValue(menu.killDickMode,undefined,false);var maxAmount=getUIValue(menu.killDickLength,"text");if(killdick_mode<3){var playerEntities=killdick_mode==0?Entity.GetPlayers():killdick_mode==1?Entity.GetPlayers().filter(function(e){return Entity.IsTeammate(e)}):Entity.GetPlayers().filter(function(e){return!Entity.IsTeammate(e)});maxAmount=Math.max.apply(Math,playerEntities.map(function(e){return Entity.GetProp(e,"CPlayerResource","m_iKills")}))}else{maxAmount=parseInt(maxAmount);maxAmount=maxAmount<=0||isNaN(maxAmount)?1:maxAmount}var playerEntity=Entity.GetLocalPlayer();var kills=Entity.GetProp(playerEntity,"CPlayerResource","m_iKills");var p=maxAmount==0?0:kills/maxAmount;if(p>1)p=1;var shaftAmount=Math.floor(p*12);_setClanTag("8"+"=".repeat(shaftAmount+1)+"D")}var animations={Static:staticTag,Time:timeTag,Default:defaultTag,Reverse:reverseTag,Classic:loopTag,"Classic (skip first)":loopTagSkip,Loop:loopTag};var killdickModes=["Relative to all","Relative to team","Relative to enemies","Relative to custom limit"];function uiTransform(key,value){var t={Animation:function(value){if(typeof value=="string"){return collect_keys(animations,false).indexOf(value)}return collect_keys(animations,false)[value]},Tags:function(value){if(typeof value=="string"){return collect_keys(tags,true)[value].indexOf(value)}return collect_keys(tags,true)[value]},Mode:function(value){if(typeof value=="string"){return killdickModes.indexOf(value)}return killdickModes[value]}};if(t[key])return t[key](value);return value}function setUIValue(key,value){UI.SetValue("Misc","JAVASCRIPT","Script items","[insecure] "+key,value)}function getUIValue(key,type,doTransform){doTransform=doTransform===undefined?true:false;type=type||"default";var raw=null;if(type=="default")raw=UI.GetValue("Misc","JAVASCRIPT","Script items","[insecure] "+key);if(type=="text"){raw=UI.GetString("Misc","JAVASCRIPT","Script items","[insecure] "+key);if(!raw||!raw.length)raw="\0"}return doTransform?uiTransform(key,raw):raw}function setUIEnabled(key,value){UI.SetEnabled("Misc","JAVASCRIPT","Script items","[insecure] "+key,value)}var menu={enabled:"Clan Tag Changer",tags:"Tags",styles:"Animation",killDickMode:"Mode",killDickLength:"max size at kill amount",speed:"Speed",text:"Text"};UI.AddCheckbox("[insecure] "+menu.enabled);UI.AddDropdown("[insecure] "+menu.tags,collect_keys(tags,true));UI.AddTextbox("[insecure] "+menu.text);UI.AddDropdown("[insecure] "+menu.styles,collect_keys(animations,false));UI.AddDropdown("[insecure] "+menu.killDickMode,killdickModes);UI.AddTextbox("[insecure] "+menu.killDickLength);UI.AddSliderInt("[insecure] "+menu.speed,0,100);setUIValue(menu.speed,30);function handle_menu(e){if(e&&e.what==menu.tags&&e.after=="Disabled"){_setClanTag("\0")}var state=getUIValue(menu.enabled);var menu_tag=getUIValue(menu.tags);var tag_style=getUIValue(menu.styles);var killdick_mode=getUIValue(menu.killDickMode);setUIEnabled(menu.tags,state);setUIEnabled(menu.styles,state);setUIEnabled(menu.speed,state);setUIEnabled(menu.killDickMode,state&&tag_style=="Killsay");setUIEnabled(menu.killDickLength,state&&tag_style=="Killsay"&&killdick_mode==killdickModes[3]);setUIEnabled(menu.text,state&&menu_tag=="Custom");if(!state)_setClanTag("\0")}function handle_text_change(){update_after=Globals.Curtime()+1;tag_index=0;tag_length=0;tag_reverse=0;tag_last_index=0;_setClanTag("\0")}handle_menu();var listeners={};function listenerCheck(){Object.keys(listeners).forEach(function(key){var v=getUIValue(key,listeners[key].type);if(v!=listeners[key].currentValue){listeners[key].callbacks.forEach(function(cb){cb({before:listeners[key].currentValue,after:v,what:key})});listeners[key].currentValue=v}})}function listen(onElement,callback,type){if(!listeners[onElement]){listeners[onElement]={callbacks:[callback],currentValue:getUIValue(onElement,type),type:type||"default"}}else{listeners[onElement].callbacks.push(callback)}}listen(menu.enabled,handle_menu);listen(menu.tags,handle_menu);listen(menu.styles,handle_menu);listen(menu.killDickMode,handle_menu);listen(menu.text,handle_text_change,"text");function net_update_end(){if(!getUIValue(menu.enabled))return;var local_player=Entity.GetLocalPlayer();var menu_tag=getUIValue(menu.tags);var tag_style=getUIValue(menu.styles);var update_tag=Globals.Curtime()>update_after;var isClassicVariant=tag_style=="Classic"||tag_style=="Classic (skip first)";if(menu_tag=="Disabled")return;tag=menu_tag=="Custom"?getUIValue(menu.text,"text").substr(0,15):tags[menu_tag];if(isClassicVariant&&tag.length<8){tag=tag+" ".repeat(8-tag.length)}if(tag_style!="Classic (skip first)"){tag_index_offset=0}tag=tag_style=="Loop"?tag+" ":tag;tag=isClassicVariant?tag+" ".repeat(Math.floor(tag.length*2)):tag;tag_length=tag.length;tag_index=Math.floor((Globals.Curtime()*getUIValue(menu.speed)/10+tag_index_offset)%tag_length+1);tag_reverse=Math.floor(Globals.Curtime()*getUIValue(menu.speed)/10%(tag_length*2)+1);if(!update_tag)return;var animation=animations[tag_style];animation();tag_last_index=tag_index}function onFrameStageNotify(){if(Cheat.FrameStage()==0)listenerCheck();if(Cheat.FrameStage()==4)net_update_end()}multiplierOptions=[0,1];UI.AddHotkey("Invert Anti-Aim");function aaLoop(){AntiAim.SetOverride(1);if(UI.IsHotkeyActive("Script items","Invert Anti-Aim")){AntiAim.SetFakeOffset(getRandomIntInclusive(58585,647423));AntiAim.SetRealOffset(getRandomIntInclusive(-12515,-2515));UI.SetValue("Anti-Aim","Rage Anti-Aim","Yaw offset",-140)}else{AntiAim.SetFakeOffset(getRandomIntInclusive(6187,-6187));AntiAim.SetRealOffset(getRandomIntInclusive(-3089,3089));UI.SetValue("Anti"+"-Aim","Rage Anti-Aim","Yaw offset",147)}}function aaLoopone(){AntiAim.SetOverride(1);if(UI.IsHotkeyActive("Script items","Invert Anti-Aim")){AntiAim.SetFakeOffset(getRandomIntInclusive(-6224,6224));AntiAim.SetRealOffset(getRandomIntInclusive(3125,-3125));UI.SetValue("Anti-Aim","Rage Anti-Aim","Yaw offset",110)}else{AntiAim.SetFakeOffset(getRandomIntInclusive(6224,-6224));AntiAim.SetRealOffset(getRandomIntInclusive(-3125,3125));UI.SetValue("Anti-Aim","Rage Anti-Aim","Yaw offset",-105)}}function aaLooptwo(){AntiAim.SetOverride(1);if(UI.IsHotkeyActive("Script items","Invert Anti-"+"Aim")){AntiAim.SetFakeOffset(getRandomIntInclusive(-6256,6256));AntiAim.SetRealOffset(getRandomIntInclusive(3178,-3178));UI.SetValue("Anti-Aim","Rage Anti-Aim","Yaw offset",110)}else{AntiAim.SetFakeOffset(getRandomIntInclusive(6256,-6256));AntiAim.SetRealOffset(getRandomIntInclusive(-3178,3178));UI.SetValue("Anti"+"-Aim","Rage Anti-Aim","Yaw offset",-105)}}function aaLoopthree(){AntiAim.SetOverride(1);if(UI.IsHotkeyActive("Script items","Invert Anti-"+"Aim")){AntiAim.SetFakeOffset(getRandomIntInclusive(-6230,6156));AntiAim.SetRealOffset(getRandomIntInclusive(3115,-3196));UI.SetValue("Anti-Aim","Rage Anti-Aim","Yaw offset",110)}else{AntiAim.SetFakeOffset(getRandomIntInclusive(6230,-6156));AntiAim.SetRealOffset(getRandomIntInclusive(-3115,3196));UI.SetValue("Anti-Aim","Rage Anti-Aim","Yaw offset",-105)}}function aaLoop(){AntiAim.SetOverride(1);if(UI.IsHotkeyActive("Script items","Invert Anti-Aim")){AntiAim.SetFakeOffset(getRandomIntInclusive(-6187,6187));AntiAim.SetRealOffset(getRandomIntInclusive(3425,-3425));UI.SetValue("Anti-Aim","Rage Anti-Aim","Yaw offset",-140)}else{AntiAim.SetFakeOffset(getRandomIntInclusive(6187,-6187));AntiAim.SetRealOffset(getRandomIntInclusive(-3089,3089));UI.SetValue("Anti-Aim","Rage Anti-Aim","Yaw offset",147)}}function aaLoopi(){AntiAim.SetOverride(1);if(UI.IsHotkeyActive("Script items","Invert Anti-Aim")){AntiAim.SetFakeOffset(getRandomIntInclusive(-6187,6187));AntiAim.SetRealOffset(getRandomIntInclusive(3425,-3425));UI.SetValue("Anti-Aim","Rage Anti-Aim","Yaw offset",-140)}else{AntiAim.SetFakeOffset(getRandomIntInclusive(6187,-6187));AntiAim.SetRealOffset(getRandomIntInclusive(-3089,3089));UI.SetValue("Anti-Aim","Rage Anti-Aim","Yaw offset",147)}}function aaLoope(){AntiAim.SetOverride(1);if(UI.IsHotkeyActive("Script items","Invert Anti-Aim")){AntiAim.SetFakeOffset(getRandomIntInclusive(-6187,6187));AntiAim.SetRealOffset(getRandomIntInclusive(3425,-3425));UI.SetValue("Anti-Aim","Rage Anti-Aim","Yaw offset",-140)}else{AntiAim.SetFakeOffset(getRandomIntInclusive(6187,-6187));AntiAim.SetRealOffset(getRandomIntInclusive(-3089,3089));UI.SetValue("Anti-Aim","Rage Anti-Aim","Yaw offset",147)}}function aaLoopa(){AntiAim.SetOverride(1);if(UI.IsHotkeyActive("Script items","Invert Anti-"+"Aim")){AntiAim.SetFakeOffset(getRandomIntInclusive(-6425,24147));AntiAim.SetRealOffset(getRandomIntInclusive(6363,-324125));UI.SetValue("Anti-Aim","Rage Anti-Aim","Yaw offset",-140)}else{AntiAim.SetFakeOffset(getRandomIntInclusive(12451,-25715));AntiAim.SetRealOffset(getRandomIntInclusive(-42523,32352));UI.SetValue("Anti-Aim","Rage Anti-Aim","Yaw offset",147)}}function getRandomIntInclusive(_0xb12d45,_0x4777a4){_0xb12d45=Math.ceil(_0xb12d45);_0x4777a4=Math.floor(_0x4777a4);return Math.floor(Math.random()*(_0xb12d45*_0x4777a4-0,3))+_0xb12d45}function getRandomIntInclusiveone(_0x2ddd58,_0x3731a8){_0x2ddd58=Math.ceil(_0x2ddd58);_0x3731a8=Math.floor(_0x3731a8);return Math.floor(Math.random()*(_0x2ddd58*_0x3731a8-0,5))+_0x2ddd58}function getRandomIntInclusivetwo(_0x4c6221,_0xcad189){_0x4c6221=Math.ceil(_0x4c6221);_0xcad189=Math.floor(_0xcad189);return Math.floor(Math.random()*(_0x4c6221*_0xcad189-0,13))+_0x4c6221}function getRandomIntInclusivethree(_0x8c6dc0,_0x54af2b){_0x8c6dc0=Math.ceil(_0x8c6dc0);_0x54af2b=Math.floor(_0x54af2b);return Math.floor(Math.random()*(_0x8c6dc0*_0x54af2b-0,8))+_0x8c6dc0}function getRandomIntInclusivefour(_0x489fe6,_0x9c330e){_0x489fe6=Math.ceil(_0x489fe6);_0x9c330e=Math.floor(_0x9c330e);return Math.floor(Math.random()*(_0x489fe6*_0x9c330e-0,32))+_0x489fe6}function getRandomIntInclusivefive(_0x2f9425,_0x1f74d6){_0x2f9425=Math.ceil(_0x2f9425);_0x1f74d6=Math.floor(_0x1f74d6);return Math.floor(Math.random()*(_0x2f9425*_0x1f74d6-0,55))+_0x2f9425}function gui(){UI.AddSliderFloat("Fake-Lag Upper And Lower Limit",0,5);UI.AddLabel("Note"+": Set this to 2.09");UI.AddSliderFloat("Fake-Lag Frequency",.01,1);UI.AddLabel("Note"+": Set this to 0.03");UI.AddSliderFloat("Fake-Lag Center Value",0,16);UI.AddLabel("Note"+": Set this to 10.77")}function fakelagRando(){var _0x3f21d8=Global.Realtime();var _0x2e6327=UI.GetValue("Misc","JAVASCRIPT","Script items","Fake-Lag Upper And Lower Limit");var _0x41713c=UI.GetValue("Misc","JAVASCRIPT","Script items","Fake-Lag Frequency");var _0x2dc971=UI.GetValue("Misc","JAVASCRIPT","Script items","Fake"+"-Lag Center Value");var _0x13a709=_0x2e6327*Math.cos(_0x3f21d8/_0x41713c)+_0x2dc971;return _0x13a709}function Initialize(){UI.SetValue("Anti-Aim","Fake-Lag","Limit",fakelagRando())}gui();Global.RegisterCallback("Draw","Initialize");UI.AddCheckbox("Trigger limit override");UI.AddSliderInt("Trigger limit",0,16);UI.AddLabel("Note"+": Set the value to 16");var ogTrigger=UI.GetValue("Anti-Aim","Fake-Lag","Trigger limit");function gay(){if(UI.GetValue("Misc","JAVASCRIPT","Script items","Trigger limit override"))try{var _0x420813=UI.GetValue("Misc","JAVASCRIPT","Script items","Trigger limit");AntiAim.SetOverride(1);UI.SetValue("Anti-Aim","Fake-Lag","Trigger limit",_0x420813)}catch(_0x1e7ddc){Global.Print(_0x1e7ddc)}else{UI.SetValue("Anti-Aim","Fake"+"-Lag","Trigger limit",ogTrigger)}}UI.AddCheckbox("Jitter Offset override");UI.AddSliderInt("Jitter Offset",-180,180);UI.AddLabel("Note"+": Set the value to 5");var ogJitter=UI.GetValue("Anti-Aim","Fake-Lag","Trigger limit");function anothergay(){if(UI.GetValue("Misc","JAVASCRIPT","Script items","Jitter Offset override"))try{var _0x3f7511=UI.GetValue("Misc","JAVASCRIPT","Script items","Jitter Offset");AntiAim.SetOverride(1);UI.SetValue("Anti-Aim","Fake-Lag","Trigger limit",_0x3f7511)}catch(_0x24fbf1){Global.Print(_0x24fbf1)}else{UI.SetValue("Anti-Aim","Fake"+"-Lag","Trigger limit",ogJitter)}}function drawString(){if(UI.IsHotkeyActive("Script items","Invert Anti-Aim")){Render.String(1150,550,8,">",[0,250,255,255],48)}else{Render.String(780,550,8,"<",[0,250,255,255],48)}}UI.AddMultiDropdown("AutoMindmg weapons",["Auto","Scout","AWP","R8"]);UI.AddHotkey("Auto DT Hc");var exploits=["Rage","Exploits"];function onCM(){localplayer_index=Entity.GetLocalPlayer();localplayer_weapon=Entity.GetWeapon(localplayer_index);weapon_name=Entity.GetName(localplayer_weapon);inaccuracy=Local.GetInaccuracy();spread=Local.GetSpread();localPlayer_index=Entity.GetLocalPlayer();localPlayer_eyepos=Entity.GetEyePosition(localPlayer_index);const _0x5e2341=UI.GetValue("AutoMindmg weapons");var _0x1801f9=Ragebot.GetTarget();var _0x559795=Entity.GetProp(_0x1801f9,"CBasePlayer","m_iHealth");var _0x522668=Exploit.GetCharge();var _0xfc3a69=UI.IsHotkeyActive("Rage","GENERAL","Exploits","Doubletap")&&_0x522668==1;for(i=0;i<_0x1801f9.length;i++){hitbox_pos_head=Entity.GetHitboxPosition(_0x1801f9[i],0);hitbox_pos_body=Entity.GetHitboxPosition(_0x1801f9[i],3);hitbox_pos_thorax=Entity.GetHitboxPosition(_0x1801f9[i],4);hitbox_pos_chest=Entity.GetHitboxPosition(_0x1801f9[i],5);hitbox_pos_upp_chest=Entity.GetHitboxPosition(_0x1801f9[i],6);result_head=Trace.Line(localPlayer_index,localPlayer_eyepos,hitbox_pos_head);result_body=Trace.Line(localPlayer_index,localPlayer_eyepos,hitbox_pos_body);result_thorax=Trace.Line(localPlayer_index,localPlayer_eyepos,hitbox_pos_thorax);result_chest=Trace.Line(localPlayer_index,localPlayer_eyepos,hitbox_pos_chest);result_upp_chest=Trace.Line(localPlayer_index,localPlayer_eyepos,hitbox_pos_upp_chest)}if(result_head="undefined")return;if(result_body="undefined")return;if(result_thorax="undefined")return;if(result_chest="undefined")return;if(result_upp_chest="undefined")return;for(k=0;k<12;k++){if(_0xfc3a69&&inaccuracy>.3&&spread>.3&&_0x5e2341&1<<0&&weapon_name=="scar 20"&&Entity.IsAlive(_0x1801f9)&&Entity.IsValid(_0x1801f9)){Ragebot.OverrideMinimumDamage(k,_0x559795/3)}else if(_0xfc3a69&&inaccuracy<.3&&spread<.3&&_0x5e2341&1<<0&&weapon_name=="scar 20"&&Entity.IsAlive(_0x1801f9)&&Entity.IsValid(_0x1801f9)){Ragebot.OverrideMinimumDamage(k,_0x559795/2+3)}else if(UI.IsHotkeyActive("Rage","GENERAL","Exploits","Doubletap")&&_0x5e2341&1<<0&&weapon_name=="scar 20"&&Entity.IsAlive(_0x1801f9)&&Entity.IsValid(_0x1801f9)){Ragebot.OverrideMinimumDamage(k,_0x559795)}else if(_0xfc3a69&&inaccuracy>.3&&spread>.3&&_0x5e2341&1<<0&&weapon_name=="g3sg1"&&Entity.IsAlive(_0x1801f9)&&Entity.IsValid(_0x1801f9)){Ragebot.OverrideMinimumDamage(k,_0x559795/3)}else if(_0xfc3a69&&inaccuracy<.3&&spread<.3&&_0x5e2341&1<<0&&weapon_name=="g3sg1"&&Entity.IsAlive(_0x1801f9)&&Entity.IsValid(_0x1801f9)){Ragebot.OverrideMinimumDamage(k,_0x559795/2+3)}else if(UI.IsHotkeyActive("Rage","GENERAL","Exploits","Doubletap")&&_0x5e2341&1<<0&&weapon_name=="g3sg1"&&Entity.IsAlive(_0x1801f9)&&Entity.IsValid(_0x1801f9)){Ragebot.OverrideMinimumDamage(k,_0x559795)}else if(inaccuracy>.5&&spread>.5&&_0x5e2341&1<<3&&weapon_name=="r8 revolver"&&Entity.IsAlive(_0x1801f9)&&Entity.IsValid(_0x1801f9)){Ragebot.OverrideMinimumDamage(k,_0x559795/3)}else if(inaccuracy>.2&&spread>.2&&_0x5e2341&1<<3&&weapon_name=="r8 revolver"&&Entity.IsAlive(_0x1801f9)&&Entity.IsValid(_0x1801f9)){Ragebot.OverrideMinimumDamage(k,_0x559795/2)}else if(inaccuracy<.15&&spread<.15&&_0x5e2341&1<<3&&weapon_name=="r8 revolver"&&Entity.IsAlive(_0x1801f9)&&Entity.IsValid(_0x1801f9)){Ragebot.OverrideMinimumDamage(k,_0x559795)}else if((result_head>.8||result_body>.85||result_thorax>.85||result_chest>.85||result_upp_chest>.85)&&_0x5e2341&1<<2&&weapon_name=="awp"&&Entity.IsAlive(_0x1801f9)&&Entity.IsValid(_0x1801f9)){Ragebot.OverrideMinimumDamage(k,_0x559795)}else if((result_head<.8||result_body<.85||result_thorax<.85||result_chest<.85||result_upp_chest<.85)&&_0x5e2341&1<<2&&weapon_name=="awp"&&Entity.IsAlive(_0x1801f9)&&Entity.IsValid(_0x1801f9)){Ragebot.OverrideMinimumDamage(k,_0x559795*.75)}}}function dtHC(){inaccuracy=Local.GetInaccuracy();spread=Local.GetSpread();var _0x2f5cc8=UI.IsHotkeyActive("Rage","GENERAL","Exploits","Doubletap")&&charge==1&&UI.IsHotkeyActive("Auto DT Hc");var _0x21fbae=UI.GetValue(exploits,"Doubletap hitchance");if(_0x2f5cc8&&inaccuracy>.3&&spread>.3)UI.SetValue(exploits,"Doubletap hitchance",inaccuracy/2.5*100+spread/2.5*100);else if(_0x2f5cc8&&inaccuracy<.3&&spread<.3)UI.SetValue(exploits,"Doubletap hitchance",15)}var varrg="\n\nThank you for purchasing insecure, "+Cheat.GetUsername()+"."+"\n"+"We hope you enjoy your time using insecure.\n"+"Regards, insecure staff.";Cheat.PrintColor([0,149,185,255],varrg);Cheat.RegisterCallback("FrameStageNotify","onFrameStageNotify");Cheat.RegisterCallback("Draw","update_menu");Cheat.RegisterCallback("CreateMove","on_move");Cheat.RegisterCallback("round_start","reset_shit");Cheat.RegisterCallback("Draw","indicator");Cheat.RegisterCallback("Draw","watermark");Cheat.RegisterCallback("CreateMove","gay");Cheat.RegisterCallback("CreateMove","aaLoop");Cheat.RegisterCallback("CreateMove","aaLoopa");Cheat.RegisterCallback("CreateMove","aaLoope");Cheat.RegisterCallback("CreateMove","aaLoopi");Cheat.RegisterCallback("CreateMove","aaLoopone");Cheat.RegisterCallback("CreateMove","aaLooptwo");Cheat.RegisterCallback("CreateMove","aaLoopthree");Cheat.RegisterCallback("CreateMove","anothergay");Cheat.RegisterCallback("Draw","drawString");Cheat.RegisterCallback("CreateMove","onCM","dtHC");Local.SetClanTag("insecure")}
var ilililililililillililililililililili = 3;
var ilililililililillilililililililililiilililililililillililililililililili = 2;
if (ilililililililillilililililililililiilililililililillililililililililili > ilililililililillililililililililili) {
    Cheat.PrintColor([255, 0, 0, 255], "\n\n--Your license has expired!")
} else {
    UI.AddLabel("           --- insecure.js ---");
    const global_print = Global.Print;
    global_print_chat = Global.PrintChat;
    global_print_color = Global.PrintColor;
    global_register_callback = Global.RegisterCallback, global_execute_command = Global.ExecuteCommand, global_frame_stage = Global.FrameStage, global_tickcount = Global.Tickcount, global_tickrate = Global.Tickrate, global_tick_interval = Global.TickInterval, global_curtime = Global.Curtime, global_realtime = Global.Realtime, global_frametime = Global.Frametime, global_latency = Global.Latency, global_get_view_angles = Global.GetViewAngles, global_set_view_angles = Global.SetViewAngles, global_get_map_name = Global.GetMapName, global_is_key_pressed = Global.IsKeyPressed, global_get_screen_size = Global.GetScreenSize, global_get_cursor_position = Global.GetCursorPosition, global_play_sound = Global.PlaySound, global_play_microphone = Global.PlayMicrophone, global_stop_microphone = Global.StopMicrophone, global_get_username = Global.GetUsername, global_set_clan_tag = Global.SetClanTag, globals_tickcount = Globals.Tickcount, globals_tickrate = Globals.Tickrate, globals_tick_interval = Globals.TickInterval, globals_curtime = Globals.Curtime, globals_realtime = Globals.Realtime, globals_frametime = Globals.Frametime, sound_play = Sound.Play, sound_play_microphone = Sound.PlayMicrophone, sound_stop_microphone = Sound.StopMicrophone, cheat_get_username = Cheat.GetUsername, cheat_register_callback = cheat_register_callback = new Proxy(Cheat.RegisterCallback, {
        apply: function (_, _, args) {
            switch (args[0]) {
            case "paint":
                Cheat.RegisterCallback("Draw", args[1]);
                break;
            case "create_move":
                Cheat.RegisterCallback("CreateMove", args[1]);
                break;
            case "fsn":
                Cheat.RegisterCallback("FrameStageNotify", args[1]);
                break;
            default:
                Cheat.RegisterCallback(args[0], args[1]);
                break
            }
        }
    }), cheat_execute_command = Cheat.ExecuteCommand, cheat_frame_stage = Cheat.FrameStage, cheat_print = Cheat.Print, cheat_print_chat = Cheat.PrintChat, cheat_print_color = Cheat.PrintColor, local_latency = Local.Latency, local_get_view_angles = Local.GetViewAngles, local_set_view_angles = Local.SetViewAngles, local_set_clan_tag = Local.SetClanTag, local_get_real_yaw = Local.GetRealYaw, local_get_fake_yaw = Local.GetFakeYaw, local_get_spread = Local.GetSpread, local_get_inaccuracy = Local.GetInaccuracy, world_get_map_name = World.GetMapName, world_get_server_string = World.GetServerString, input_get_cursor_position = Input.GetCursorPosition, input_is_key_pressed = Input.IsKeyPressed, render_string = Render.String, render_text_size = Render.TextSize, render_line = Render.Line, render_rect = Render.Rect, render_filled_rect = Render.FilledRect, render_gradient_rect = Render.GradientRect, render_circle = Render.Circle, render_filled_circle = Render.FilledCircle, render_polygon = Render.Polygon, render_world_to_screen = Render.WorldToScreen, render_add_font = Render.AddFont, render_find_font = Render.FindFont, render_string_custom = Render.StringCustom, render_textured_rect = Render.TexturedRect, render_add_texture = Render.AddTexture, render_text_size_custom = Render.TextSizeCustom, render_get_screen_size = Render.GetScreenSize, ui_get_value = UI.GetValue, ui_set_value = UI.SetValue, ui_add_checkbox = UI.AddCheckbox, ui_add_slider_int = UI.AddSliderInt, ui_add_slider_float = UI.AddSliderFloat, ui_add_hotkey = UI.AddHotkey, ui_add_label = UI.AddLabel, ui_add_dropdown = UI.AddDropdown, ui_add_multi_dropdown = UI.AddMultiDropdown, ui_add_color_picker = UI.AddColorPicker, ui_add_textbox = UI.AddTextbox, ui_set_enabled = UI.SetEnabled, ui_get_string = UI.GetString, ui_get_color = UI.GetColor, ui_set_color = UI.SetColor, ui_is_hotkey_active = UI.IsHotkeyActive, ui_toggle_hotkey = UI.ToggleHotkey, ui_is_menu_open = UI.IsMenuOpen, convar_get_int = Convar.GetInt, convar_set_int = Convar.SetInt, convar_get_float = Convar.GetFloat, convar_set_float = Convar.SetFloat, convar_get_string = Convar.GetString, convar_set_string = Convar.SetString, event_get_int = Event.GetInt, event_get_float = Event.GetFloat, event_get_string = Event.GetString, entity_get_entities = Entity.GetEntities, entity_get_entities_by_class_i_d = Entity.GetEntitiesByClassID, entity_get_players = Entity.GetPlayers, entity_get_enemies = Entity.GetEnemies, entity_get_teammates = Entity.GetTeammates, entity_get_local_player = Entity.GetLocalPlayer, entity_get_game_rules_proxy = Entity.GetGameRulesProxy, entity_get_entity_from_user_i_d = Entity.GetEntityFromUserID, entity_is_teammate = Entity.IsTeammate, entity_is_enemy = Entity.IsEnemy, entity_is_bot = Entity.IsBot, entity_is_local_player = Entity.IsLocalPlayer, entity_is_valid = Entity.IsValid, entity_is_alive = Entity.IsAlive, entity_is_dormant = Entity.IsDormant, entity_get_class_i_d = Entity.GetClassID, entity_get_class_name = Entity.GetClassName, entity_get_name = Entity.GetName, entity_get_weapon = Entity.GetWeapon, entity_get_weapons = Entity.GetWeapons, entity_get_render_origin = Entity.GetRenderOrigin, entity_get_prop = Entity.GetProp, entity_set_prop = Entity.SetProp, entity_get_hitbox_position = Entity.GetHitboxPosition, entity_get_eye_position = Entity.GetEyePosition, trace_line = Trace.Line, trace_bullet = Trace.Bullet, usercmd_set_movement = UserCMD.SetMovement, usercmd_get_movement = UserCMD.GetMovement, usercmd_set_angles = UserCMD.SetAngles, usercmd_force_jump = UserCMD.ForceJump, usercmd_force_crouch = UserCMD.ForceCrouch, antiaim_get_override = AntiAim.GetOverride, antiaim_set_override = AntiAim.SetOverride, antiaim_set_real_offset = AntiAim.SetRealOffset, antiaim_set_fake_offset = AntiAim.SetFakeOffset, antiaim_set_l_b_y_offset = AntiAim.SetLBYOffset, exploit_get_charge = Exploit.GetCharge, exploit_recharge = Exploit.Recharge, exploit_disable_recharge = Exploit.DisableRecharge, exploit_enable_recharge = Exploit.EnableRecharge, ragebot_override_minimum_damage = Ragebot.OverrideMinimumDamage, ragebot_override_hitchance = Ragebot.OverrideHitchance, ragebot_override_accuracy_boost = Ragebot.OverrideAccuracyBoost, ragebot_override_multipoint_scale = Ragebot.OverrideMultipointScale, ragebot_force_safety = Ragebot.ForceSafety;
    var menu1 = {
        _class: "BetterUI"
    };
    const menu1_spacer = "                                                                                  ";
    menu1.concat = function (a, b) {
        var arr = [];
        for (var c in a) {
            arr.push(a[c])
        }
        arr.push(b);
        return arr
    };
    menu1.label = function (label) {
        UI.AddLabel(label)
    };
    menu1.call = function (func, name, label, properties) {
        const final_name = name + menu1_spacer + label;
        var final_props = [final_name];
        const element_info_t = {
            path: ["Misc", "JAVASCRIPT", final_name]
        };
        if (properties != null) {
            for (var i = 0; i < properties.length; i++) {
                final_props.push(properties[i])
            }
        }
        func.apply(null, final_props);
        return element_info_t
    };
    menu1.reference = function (path) {
        const element_info_t = {
            path: path
        };
        return element_info_t
    };
    menu1.get = function (elem) {
        if (!elem.path) throw new Error("[Menu] This element doesn't exist!");
        return UI.GetValue.apply(null, elem.path)
    };
    menu1.get_hotkey = function (elem) {
        if (!elem.path) throw new Error("[Menu] This element doesn't exist!");
        return UI.IsHotkeyActive.apply(null, elem.path)
    };
    menu1.get_color = function (elem) {
        if (!elem.path) throw new Error("[Menu] This element doesn't exist!");
        return UI.GetColor.apply(null, elem.path)
    };
    menu1.set = function (elem, value) {
        if (!elem.path) throw new Error("[Menu] This element doesn't exist!");
        const properties = elem;
        UI.SetValue.apply(null, this.concat(properties.path, value))
    };
    menu1.set_color = function (elem, color) {
        if (!elem.path) throw new Error("[Menu] This element doesn't exist!");
        const properties = elem;
        UI.SetColor.apply(null, this.concat(properties.path, color))
    };
    menu1.toggle = function (elem) {
        if (!elem.path) throw new Error("[Menu] This element doesn't exist!");
        UI.ToggleHotkey.apply(null, elem.path)
    };
    menu1.visibility = function (elem, visible) {
        if (!elem.path) throw new Error("[Menu] This element doesn't exist!");
        const properties = elem;
        UI.SetEnabled.apply(null, this.concat(properties.path, visible))
    };
    var vector = {
        _class: "vector"
    };
    vector["new"] = function (data) {
        return {
            x: data[0],
            y: data[1],
            z: data[2]
        }
    };
    vector.operate = function (vec, vec2, operation) {
        switch (operation) {
        case "+":
            return {
                x: vec.x + vec2.x, y: vec.y + vec2.y, z: vec.z + vec2.z
            };
        case "-":
            return {
                x: vec.x - vec2.x, y: vec.y - vec2.y, z: vec.z - vec2.z
            };
        case "*":
            return {
                x: vec.x * vec2.x, y: vec.y * vec2.y, z: vec.z * vec2.z
            };
        case "/":
            return {
                x: vec.x / vec2.x, y: vec.y / vec2.y, z: vec.z / vec2.z
            };
        default:
            throw new Error("[Vector] Invalid operation type.")
        }
    };
    vector.length2d = function (vec) {
        return Math.sqrt(vec.x * vec.x + vec.y * vec.y)
    };
    vector.angles = function (vec) {
        return {
            x: -Math.atan2(vec.z, this.length2d(vec)) * 180 / Math.PI,
            y: Math.atan2(vec.y, vec.x) * 180 / Math.PI,
            z: 0
        }
    };
    vector.fov_to = function (origin, destination, view) {
        const angles = this.angles(this.operate(destination, origin, "-"));
        const delta = this["new"]([Math.abs(view.x - angles.x), Math.abs(view.y % 360 - angles.y % 360) % 360, 0]);
        if (delta.y > 180) delta.y = 360 - delta.y;
        return this.length2d(delta)
    };
    vector.to_array = function (vec) {
        return [vec.x, vec.y, vec.z]
    };

    function normalize_yaw(angle) {
        var adjusted_yaw = angle;
        if (adjusted_yaw < -180) adjusted_yaw += 360;
        if (adjusted_yaw > 180) adjusted_yaw -= 360;
        return adjusted_yaw
    }
    var plugin = {
        _info: {
            _title: "",
            _version: "",
            _author: ""
        },
        last_hit_lby: [],
        last_target_visibility: false,
        override_flip: false,
        last_override_time: globals_curtime()
    };
    const enable = menu1.call(ui_add_checkbox, "Advanced body freestanding", "lby_enable", []);
    const body = menu1.call(ui_add_dropdown, "Body freestanding", "lby_body_mode", [
        ["Hide real angle", "Hide fake angle"]
    ]);
    const smart = menu1.call(ui_add_checkbox, "Smart switch", "lby_smart", []);
    const flip = menu1.call(ui_add_multi_dropdown, "Body inverter flip", "lby_body", [
        ["Walk", "Run", "In air"]
    ]);
    const ref_inverter = menu1.reference(["Anti-Aim", "Fake angles", "Inverter"]);
    const ref_bodyflip = menu1.reference(["Anti-Aim", "Fake angles", "Inverter flip"]);
    const ref_inverter_legit = menu1.reference(["Anti-Aim", "Legit Anti-Aim", "Direction key"]);
    const ref_ragebot = menu1.reference(["Rage", "GENERAL", "General", "Enabled"]);

    function update_anti_aim_state(state) {
        if (menu1.get(ref_ragebot)) {
            if (menu1.get_hotkey(ref_inverter) !== state) menu1.toggle(ref_inverter);
            return
        }
        state = (state + 1) % 2;
        if (menu1.get_hotkey(ref_inverter_legit) !== state) menu1.toggle(ref_inverter_legit)
    }

    function get_closest_target() {
        const players = entity_get_enemies();
        const me = entity_get_local_player();
        const data = {
            id: null,
            fov: 180
        };
        for (var i = 0; i < players.length; i++) {
            const e = players[i];
            const destination = vector["new"](entity_get_hitbox_position(e, 0)),
                origin = vector["new"](entity_get_eye_position(me));
            const angles = vector["new"](local_get_view_angles());
            const fov = vector.fov_to(origin, destination, angles);
            if (fov < data.fov) {
                data.id = e;
                data.fov = fov
            }
        }
        return data.id
    }

    function get_target_visibility() {
        const target = get_closest_target();
        if (!target || !entity_is_valid(target)) return false;
        if (entity_is_dormant(target)) return false;
        const me = entity_get_local_player();
        var origin = vector["new"](entity_get_eye_position(me)),
            velocity = vector["new"](entity_get_prop(me, "CBasePlayer", "m_vecVelocity[0]")),
            destination = entity_get_hitbox_position(target, 0);
        velocity = vector.operate(velocity, vector["new"]([.25, .25, .25]), "*");
        origin = vector.operate(origin, velocity, "+");
        const result = trace_line(me, vector.to_array(origin), destination)[0];
        return result === target
    }

    function get_optimal_angle() {
        const _mode = menu1.get(body);
        const me = entity_get_local_player();
        const origin = vector["new"](entity_get_render_origin(me));
        var yaw = local_get_view_angles()[1];
        var data = {
            left: 0,
            right: 0
        };
        for (var r = yaw - 90; r <= yaw + 90; r += 30) {
            if (r === yaw) continue;
            const rad = r * Math.PI / 180;
            const point = vector.operate(origin, vector["new"]([256 * Math.cos(rad), 256 * Math.sin(rad), 0]), "+");
            const line = trace_line(me, vector.to_array(origin), vector.to_array(point));
            const side = r < yaw ? "left" : "right";
            data[side] += line[1]
        }
        data.left /= 3;
        data.right /= 3;
        if (data.left > data.right) return _mode === 0 ? 0 : 1;
        return _mode === 0 ? 1 : 0
    }

    function update_inverter_flip() {
        if (!menu1.get(flip)) return;
        const visible = get_target_visibility();
        const now = globals_curtime();
        if (plugin.last_override_time + .3 < now) plugin.override_flip = false;
        if (visible !== plugin.last_target_visibility) {
            plugin.override_flip = true;
            plugin.last_override_time = now
        }
        plugin.last_target_visibility = visible;
        if (plugin.override_flip) {
            menu1.set(ref_bodyflip, 0);
            return
        }
        menu1.set(ref_bodyflip, menu1.get(flip))
    }

    function update_anti_aim() {
        const me = entity_get_local_player();
        if (!entity_is_valid(me) || !entity_is_alive(me)) return;
        const _smart = menu1.get(smart);
        update_inverter_flip();
        if (_smart) {
            const target = get_closest_target();
            if (target == null) {
                update_anti_aim_state(get_optimal_angle());
                return
            }
            if (plugin.last_hit_lby[target] == null) {
                update_anti_aim_state(get_optimal_angle());
                return
            }
            if (plugin.last_hit_lby[target] === 0) {
                update_anti_aim_state(1);
                return
            }
            update_anti_aim_state(0);
            return
        }
        update_anti_aim_state(get_optimal_angle())
    }

    function do_indicators() {
        const me = entity_get_local_player();
        if (!entity_is_valid(me) || !entity_is_alive(me)) return;
        const y = render_get_screen_size()[1];
        const yaw = local_get_real_yaw(),
            fake = local_get_fake_yaw();
        var delta = Math.round(normalize_yaw(yaw - fake) / 2),
            abs = Math.abs(delta);
        if (menu1.get(ref_ragebot)) delta *= -1;
        render_string(10, y / 2 + 16, 0, "FAKE", [10, 10, 10, 125], 4);
        render_string(10, y / 2 + 15, 0, "FAKE", [192 - abs * 71 / 60, 32 + abs * 146 / 60, 28, 200], 4);
        render_filled_rect(12, y / 2 + 46, 64, 4, [10, 10, 10, 125]);
        render_filled_rect(43, y / 2 + 47, 1, 2, [232, 232, 232, 200]);
        render_string(41, y / 2 + 52, 1, abs.toString(), [232, 232, 232, 200], 3);
        render_circle(48, y / 2 + 52, 1, [232, 232, 232, 200]);
        if (delta > 0) {
            render_filled_rect(44, y / 2 + 47, abs * 31 / 60, 2, [232, 232, 232, 200]);
            return
        }
        render_filled_rect(44 - abs * 31 / 60, y / 2 + 47, abs * 31 / 60, 2, [232, 232, 232, 200])
    }

    function on_tick() {
        if (!menu1.get(enable)) return;
        update_anti_aim()
    }

    function on_frame() {
        if (!menu1.get(enable)) return;
        do_indicators()
    }

    function on_player_hurt() {
        const me = entity_get_local_player();
        const attacker = entity_get_entity_from_user_i_d(event_get_int("attacker"));
        const userid = entity_get_entity_from_user_i_d(event_get_int("userid"));
        if (me !== attacker && me === userid) {
            plugin.last_hit_lby[attacker] = menu1.get_hotkey(ref_inverter)
        }
    }

    function reset() {
        plugin.last_hit_lby = []
    }
    cheat_register_callback("create_move", "on_tick");
    cheat_register_callback("paint", "on_frame");
    cheat_register_callback("player_hurt", "on_player_hurt");
    cheat_register_callback("player_connect_full", "reset");

    function vec_sub(A, B) {
        var C = [];
        var i;
        for (i = 0; i < 3; i++) {
            C[i] = A[i] - B[i]
        }
        return C
    }

    function vec_div(A, B) {
        var C = [];
        var i;
        for (i = 0; i < 3; i++) {
            C[i] = A[i] / B
        }
        return C
    }

    function vec_add(A, B) {
        var C = [];
        var i;
        for (i = 0; i < 3; i++) {
            C[i] = A[i] + B[i]
        }
        return C
    }

    function vec_mul(A, B) {
        var C = [];
        var i;
        for (i = 0; i < 3; i++) {
            C[i] = A[i] * B
        }
        return C
    }

    function dotProduct(A, B) {
        var product = 0;
        var i;
        for (i = 0; i < 3; i++) {
            product += A[i] * B[i]
        }
        return product
    }

    function getDistance(A, B) {
        var delta = vec_sub(A, B);
        return Math.sqrt(delta[0] * delta[0] + delta[1] * delta[1] + delta[2] * delta[2])
    }

    function computeDistance(A, B, C) {
        var d = vec_div(vec_sub(C, B), getDistance(C, B));
        var v = vec_sub(A, B);
        var t = dotProduct(v, d);
        var P = vec_add(B, vec_mul(d, t));
        return getDistance(P, A)
    }
    UI.AddCheckbox("Dodge bruteforce");
    UI.AddSliderInt("Max Brute Distance", 0, 60);
    UI.AddCheckbox("Anti-Onetap");
    var shots = 0;

    function onBulletImpact() {
        var ent = Entity.GetEntityFromUserID(Event.GetInt("userid"));
        var local = Entity.GetLocalPlayer();
        if (ent == local || Entity.IsTeammate(ent) && UI.GetValue("Dodge bruteforce")) return;
        var pos = [Event.GetFloat("x"), Event.GetFloat("y"), Event.GetFloat("z")];
        var delta = computeDistance(Entity.GetHitboxPosition(Entity.GetLocalPlayer(), 0), Entity.GetEyePosition(ent), pos);
        if (delta < UI.GetValue("Max Brute Distance")) UI.ToggleHotkey("Anti-Aim", "Fake angles", "Inverter");
        if (UI.GetValue("Anti-Onetap")) {
            shots++;
            if (!(shots % 4)) UI.ToggleHotkey("Anti-Aim", "Fake angles", "Inverter")
        }
    }

    function playerhurt() {
        if (Entity.GetEntityFromUserID(Event.GetInt("userid")) == Entity.GetLocalPlayer()) UI.ToggleHotkey("Anti-Aim", "Fake angles", "Inverter")
    }
    Cheat.RegisterCallback("player_hurt", "playerhurt");
    Cheat.RegisterCallback("bullet_impact", "onBulletImpact");
    var master = {
        dir: "back",
        cycle: false,
        GetYawOffset: function () {
            return UI.GetValue("Anti-Aim", "Rage Anti-Aim", "Yaw offset")
        },
        SetYawOffset: function (yaw) {
            return UI.SetValue("Anti-Aim", "Rage Anti-Aim", "Yaw offset", yaw)
        },
        GetJitterOffset: function () {
            return UI.GetValue("Anti-Aim", "Rage Anti-Aim", "Jitter offset")
        },
        SetJitterOffset: function (jitter) {
            return UI.SetValue("Anti-Aim", "Rage Anti-Aim", "Jitter offset", jitter)
        },
        RandomYaw: function () {
            return UI.GetValue("Misc", "JAVASCRIPT", "Yaw offset randomization")
        },
        RandomJitter: function () {
            return UI.GetValue("Misc", "JAVASCRIPT", "Jitter offset randomization")
        },
        JitterOffsetJitter: function () {
            return UI.GetValue("Misc", "JAVASCRIPT", "Jitter offset jitter")
        }
    };

    function ui() {
        UI.AddCheckbox("Jitter Randomizer");
        UI.AddSliderInt("Jitter offset randomization", 0, 90);
        UI.AddSliderInt("Jitter offset jitter", 0, 90)
    }

    function getRandomInt(min, max) {
        min = Math.ceil(min);
        max = Math.floor(max);
        return Math.floor(Math.random() * (max - min)) + min
    }

    function jitter() {
        if (UI.GetValue("Jitter Randomizer")) {
            master.cycle = !master.cycle;
            master.SetJitterOffset((master.cycle ? master.JitterOffsetJitter() / 2 * 2 : -(master.JitterOffsetJitter() / 2) * 2) + getRandomInt(-master.RandomJitter(), master.RandomJitter()))
        }
    }

    function main1() {
        ui();
        Global.RegisterCallback("CreateMove", "jitter")
    }
    main1();
    UI.AddSliderInt("         +Weapon Features+", 0, 0);
    const menu = {
        menu_types: {
            TYPE_VALUE: 0,
            TYPE_COLOR: 1,
            TYPE_KEYBIND: 2,
            TYPE_REFERENCE: 3
        },
        menu_array: [],
        create_checkbox: function (created_var_name) {
            return this.menu_array.push({
                type: this.menu_types.TYPE_VALUE,
                var_name: UI.AddCheckbox(created_var_name),
                is_item_visible: true
            }) - 1
        },
        create_slider_int: function (created_var_name, created_var_min, created_var_max) {
            return this.menu_array.push({
                type: this.menu_types.TYPE_VALUE,
                var_name: UI.AddSliderInt(created_var_name, created_var_min, created_var_max),
                is_item_visible: true
            }) - 1
        },
        create_slider_float: function (created_var_name, created_var_min, created_var_max) {
            return this.menu_array.push({
                type: this.menu_types.TYPE_VALUE,
                var_name: UI.AddSliderFloat(created_var_name, created_var_min, created_var_max),
                is_item_visible: true
            }) - 1
        },
        create_dropdown: function (created_var_name, created_var_dropdown_array) {
            return this.menu_array.push({
                type: this.menu_types.TYPE_VALUE,
                var_name: UI.AddDropdown(created_var_name, created_var_dropdown_array),
                is_item_visible: true
            }) - 1
        },
        create_multi_dropdown: function (created_var_name, created_var_dropdown_array) {
            return this.menu_array.push({
                type: this.menu_types.TYPE_VALUE,
                var_name: UI.AddMultiDropdown(created_var_name, created_var_dropdown_array),
                is_item_visible: true
            }) - 1
        },
        create_colorpicker: function (created_var_name) {
            return this.menu_array.push({
                type: this.menu_types.TYPE_COLOR,
                var_name: UI.AddColorPicker(created_var_name),
                is_item_visible: true
            }) - 1
        },
        create_keybind: function (created_var_name) {
            return this.menu_array.push({
                type: this.menu_types.TYPE_KEYBIND,
                var_name: UI.AddHotkey(created_var_name),
                is_item_visible: true
            }) - 1
        },
        create_menu_reference: function (var_path, var_type) {
            return this.menu_array.push({
                type: this.menu_types.TYPE_REFERENCE,
                var_name: var_path,
                is_item_visible: true,
                reference_subtype: var_type
            }) - 1
        },
        get_item_value: function (var_index) {
            if (typeof this.menu_array[var_index] != "undefined") {
                const var_type = this.menu_array[var_index].type == this.menu_types.TYPE_REFERENCE ? this.menu_array[var_index].reference_subtype : this.menu_array[var_index].type;
                switch (var_type) {
                case this.menu_types.TYPE_VALUE:
                    return UI.GetValue.apply(null, this.menu_array[var_index].var_name);
                case this.menu_types.TYPE_COLOR:
                    return UI.GetColor.apply(null, this.menu_array[var_index].var_name);
                case this.menu_types.TYPE_KEYBIND:
                    return UI.IsHotkeyActive.apply(null, this.menu_array[var_index].var_name);
                default:
                    throw new Error("[onetap] invalid type specified for get_script_item_value call (variable name " + menu_array[var_index].var_name + ", specified type: " + type + ")\n")
                }
            }
            throw new Error("[onetap] invalid menu item specified for get_script_item_value\n")
        },
        set_item_visibility: function (var_index, visibility_status) {
            if (typeof this.menu_array[var_index] != "undefined") {
                if (this.menu_array[var_index].is_item_visible != visibility_status && UI.IsMenuOpen()) {
                    UI.SetEnabled.apply(null, this.menu_array[var_index].var_name.concat(visibility_status));
                    this.menu_array[var_index].is_item_visible = visibility_status
                }
            } else {
                throw new Error("[onetap] invalid menu item specified for set_item_visibility\n")
            }
        },
        set_item_value: function (var_index, new_value) {
            if (typeof this.menu_array[var_index] != "undefined") {
                const var_type = this.menu_array[var_index].type == this.menu_types.TYPE_REFERENCE ? this.menu_array[var_index].reference_subtype : this.menu_array[var_index].type;
                switch (var_type) {
                case this.menu_types.TYPE_VALUE:
                    UI.SetValue.apply(null, this.menu_array[var_index].var_name.concat(new_value));
                    break;
                case this.menu_types.TYPE_COLOR:
                    UI.SetColor.apply(null, this.menu_array[var_index].var_name.concat(new_value));
                    break;
                case this.menu_types.TYPE_KEYBIND:
                    const keybind_state = this.get_item_value(var_index);
                    if (keybind_state != new_value) {
                        UI.ToggleHotkey.apply(null, this.menu_array[var_index].var_name)
                    }
                    break;
                default:
                    throw new Error("[onetap] invalid type specified for set_item_value (variable name " + menu_array[var_index].var_name + ", specified type: " + this.menu_array[var_index].type + ")\n")
                }
            } else {
                throw new Error("[onetap] invalid menu item specified for set_item_value\n")
            }
        }
    };
    const master_switch = menu.create_checkbox("Doubletap improvements");
    const doubletap_speed = menu.create_slider_int("Speed", 0, 4);
    const doubletap_enabled_hotkey_reference = menu.create_menu_reference(["Rage", "Doubletap"], menu.menu_types.TYPE_KEYBIND);
    const doubletap_enabled_value_reference = menu.create_menu_reference(["Rage", "Doubletap"], menu.menu_types.TYPE_VALUE);
    const utility = {
        log_prefix: "",
        log_prefix_col: [0, 255, 0, 200],
        log: function (string) {
            Cheat.PrintColor(this.log_prefix_col, this.log_prefix);
            Cheat.Print(string + "\n")
        }
    };
    const able_to_shift_shot = function (local, ticks_to_shift) {
        const server_time = (Entity.GetProp(local, "CCSPlayer", "m_nTickBase") - ticks_to_shift) * Globals.TickInterval();
        return server_time > Entity.GetProp(local, "CCSPlayer", "m_flNextAttack") && server_time > Entity.GetProp(Entity.GetWeapon(local), "CBaseCombatWeapon", "m_flNextPrimaryAttack")
    };
    const on_move = function () {
        if (menu.get_item_value(doubletap_enabled_value_reference) && menu.get_item_value(doubletap_enabled_hotkey_reference) && menu.get_item_value(master_switch)) {
            const desired_doubletap_speed = menu.get_item_value(doubletap_speed);
            Exploit.OverrideShift(10 + desired_doubletap_speed);
            Exploit.OverrideTolerance(4 - desired_doubletap_speed);
            const local = Entity.GetLocalPlayer();
            const exploit_charge = Exploit.GetCharge();
            exploit_charge != 1 ? Exploit.EnableRecharge() : Exploit.DisableRecharge();
            const able_to_shift = able_to_shift_shot(local, 12 + desired_doubletap_speed);
            const can_doubletap = exploit_charge == 1 && able_to_shift;
            var should_recharge_doubletap = !can_doubletap && able_to_shift;
            const enemies = Entity.GetEnemies().filter(function (entity_index) {
                return Entity.IsValid(entity_index) && Entity.IsAlive(entity_index) && !Entity.IsDormant(entity_index)
            });
            const local_eyepos = Entity.GetEyePosition(local);
            if (can_doubletap || should_recharge_doubletap) {
                for (var i = 0; i < enemies.length; i++) {
                    const entity_index = enemies[i];
                    const entity_health = Entity.GetProp(entity_index, "CBasePlayer", "m_iHealth");
                    for (var hitbox = 2; hitbox <= 4; hitbox++) {
                        const hitbox_position = Entity.GetHitboxPosition(entity_index, hitbox);
                        if (typeof hitbox_position != "undefined") {
                            const trace = Trace.Bullet(local, entity_index, local_eyepos, hitbox_position);
                            if (can_doubletap && trace[1] >= entity_health / 2) {
                                Ragebot.ForceTargetMinimumDamage(entity_index, entity_health / 2)
                            } else if (should_recharge_doubletap && trace[2]) {
                                should_recharge_doubletap = false;
                                break
                            }
                        }
                    }
                }
            }
            if (should_recharge_doubletap) {
                Exploit.DisableRecharge();
                Exploit.Recharge()
            }
        }
    };
    const on_unload = function () {
        Exploit.EnableRecharge()
    };
    Cheat.RegisterCallback("CreateMove", "on_move");
    Cheat.RegisterCallback("Unload", "on_unload");

    function vectorangles(forward) {
        var angles = [];
        if (forward[1] == 0 && forward[0] == 0) {
            angles[0] = forward[2] > 0 ? 270 : 90;
            angles[1] = 0
        } else {
            angles[0] = Math.atan2(-forward[2], Math.sqrt(forward[0] * forward[0] + forward[1] * forward[1])) * -180 / Math.PI;
            angles[1] = Math.atan2(forward[1], forward[0]) * 180 / Math.PI;
            if (angles[1] > 90) angles[1] -= 180;
            else if (angles[1] < 90) angles[1] += 180;
            else if (angles[1] == 90) angles[1] = 0
        }
        return angles
    }

    function anglevectors(angles) {
        var sy = Math.sin(angles[1] * 180 / Math.PI);
        var cy = Math.cos(angles[1] * 180 / Math.PI);
        var sp = Math.sin(angles[0] * 180 / Math.PI);
        var cp = Math.cos(angles[0] * 180 / Math.PI);
        return [cp * cy, cp * sy, -sp]
    }
    var currentAction = 2;
    var lastTickShot = 0;

    function reset() {
        lastTickShot = 0
    }
    var lasttarget = 0;

    function onRageShoot() {
        if (!UI.IsHotkeyActive("Rage", "GENERAL", "Exploits", "Doubletap") && !UI.GetValue("Rage", "GENERAL", "Exploits", "Doubletap")) return;
        var type = Event.GetInt("exploit");
        if (type == 1) {
            currentAction = 1;
            lastTickShot = Globals.Tickcount()
        }
        if (type == 2) {
            currentAction = 2
        }
        lasttarget = Event.GetInt("target_index")
    }

    function onCM() {
        var local = Entity.GetLocalPlayer();
        if (!local || !Entity.IsAlive(local) || currentAction == 2) return;
        if (!UI.IsHotkeyActive("Rage", "GENERAL", "Exploits", "Doubletap") && !UI.GetValue("Rage", "GENERAL", "Exploits", "Doubletap")) return;
        if (!Entity.IsAlive(lasttarget) || lastTickShot + 12 < Globals.Tickcount()) {
            lasttarget = 0;
            return
        }
        var velo = Entity.GetProp(local, "DT_CSPlayer", "m_vecVelocity[0]");
        var speed = Math.sqrt(velo[0] * velo[0] + velo[1] * velo[2] + velo[2] * velo[2]);
        var direction = vectorangles(velo);
        direction[1] = Local.GetViewAngles()[1] - direction[1];
        var forward = anglevectors(direction);
        var negative = [];
        negative[0] = forward[0] * speed;
        negative[1] = forward[1] * speed;
        negative[2] = forward[2] * speed;
        UserCMD.SetMovement([negative[0], negative[1], 0])
    }
    Cheat.RegisterCallback("ragebot_fire", "onRageShoot");
    Cheat.RegisterCallback("CreateMove", "onCM");
    Cheat.RegisterCallback("round_start", "reset");
    UI.AddCheckbox("Damage Override");
    UI.AddHotkey("Override Hotkey");
    UI.AddCheckbox("Display indicator");
    UI.AddSliderInt("Heavy Pistol Mindmg", 0, 130);
    UI.AddSliderInt("Scout Mindmg", 0, 130);
    UI.AddSliderInt("AWP Mindmg", 0, 130);
    UI.AddSliderInt("Auto Mindmg", 0, 130);
    var heavy_cache = UI.GetValue("Rage", "HEAVY PISTOL", "Targeting", "Minimum damage");
    var scout_cache = UI.GetValue("Rage", "SCOUT", "Targeting", "Minimum damage");
    var awp_cache = UI.GetValue("Rage", "AWP", "Targeting", "Minimum damage");
    var auto_cache = UI.GetValue("Rage", "AUTOSNIPER", "Targeting", "Minimum damage");

    function isActive(a) {
        return UI.IsHotkeyActive("JAVASCRIPT", a)
    }

    function setValue(cat, value) {
        UI.SetValue("Rage", cat.toUpperCase(), "Targeting", "Minimum damage", value)
    }

    function isHeavyPistol(name) {
        if (name == "r8 revolver" || name == "desert eagle") {
            return true
        }
    }

    function isAutoSniper(name) {
        if (name == "scar 20" || weapon_name == "g3sg1") {
            return true
        }
    }

    function onCM() {
        heavy_value = UI.GetValue("Script items", "Heavy Pistol Mindmg");
        scout_value = UI.GetValue("Script items", "Scout Mindmg");
        awp_value = UI.GetValue("Script items", "AWP Mindmg");
        auto_value = UI.GetValue("Script items", "Auto Mindmg");
        weapon_name = Entity.GetName(Entity.GetWeapon(Entity.GetLocalPlayer()));
        if (isActive("Override Hotkey") && isHeavyPistol(weapon_name) && UI.GetValue("Damage Override")) {
            setValue("HEAVY PISTOL", heavy_value)
        } else {
            setValue("HEAVY PISTOL", heavy_cache)
        }
        if (isActive("Override Hotkey") && weapon_name == "ssg 08" && UI.GetValue("Damage Override")) {
            setValue("SCOUT", scout_value)
        } else {
            setValue("SCOUT", scout_cache)
        }
        if (isActive("Override Hotkey") && weapon_name == "awp" && UI.GetValue("Damage Override")) {
            setValue("AWP", awp_value)
        } else {
            setValue("AWP", awp_cache)
        }
        if (isActive("Override Hotkey") && isAutoSniper(weapon_name) && UI.GetValue("Damage Override")) {
            setValue("AUTOSNIPER", auto_value)
        } else {
            setValue("AUTOSNIPER", auto_cache)
        }
    }

    function indicator() {
        font = Render.AddFont("Tahoma", 17, 600);
        screen = Render.GetScreenSize();
        wep = Entity.GetName(Entity.GetWeapon(Entity.GetLocalPlayer()));
        x = screen[0] - screen[0] + 20;
        y = screen[1] - 100;
        heavy = "" + UI.GetValue("Rage", "HEAVY PISTOL", "Targeting", "Minimum damage");
        scout = "" + UI.GetValue("Rage", "SCOUT", "Targeting", "Minimum damage");
        awp = "" + UI.GetValue("Rage", "AWP", "Targeting", "Minimum damage");
        auto = "" + UI.GetValue("Rage", "AUTOSNIPER", "Targeting", "Minimum damage");
        var str = "";
        if (UI.GetValue("Script items", "Display indicator") && Entity.IsValid(Entity.GetLocalPlayer()) && Entity.IsAlive(Entity.GetLocalPlayer())) {
            if (isHeavyPistol(wep)) {
                str = heavy
            } else if (wep == "ssg 08") {
                str = scout
            } else if (wep == "awp") {
                str = awp
            } else if (isAutoSniper(wep)) {
                str = auto
            }
        }
        if (str == "" + 0) {
            str = "DYNAMIC"
        }
        Render.StringCustom(x + 1, y + 1, 0, str + "", [0, 0, 0, 255], font);
        Render.StringCustom(x, y, 0, str + "", [255, 255, 255, 255], font)
    }
    Cheat.RegisterCallback("Draw", "indicator");
    Cheat.RegisterCallback("CreateMove", "onCM");
    UI.AddCheckbox("Hitbox Conditions");
    UI.AddMultiDropdown("Head conditions", ["If in air", "If crouching"]);
    UI.AddMultiDropdown("Body conditions", ["If lethal", "If slow-walking", "If standing", "If in air", "If crouching"]);
    UI.AddMultiDropdown("Safety conditions", ["If lethal", "If slow-walking", "If standing", "If in air", "If crouching"]);
    UI.AddCheckbox("Safety Flags");
    var info = [];
    var safe = [];

    function get_value(item) {
        return UI.GetValue("Misc", "JAVASCRIPT", "Script items", item)
    }

    function get_proper_eye() {
        var local_player = Entity.GetLocalPlayer();
        var origin = Entity.GetRenderOrigin(local_player);
        if (UI.IsHotkeyActive("Anti-Aim", "Extra", "Fake duck")) return [origin[0], origin[1], origin[2] + 46 + 18];
        else return Entity.GetEyePosition(local_player)
    }

    function extrapolate_tick(entity, ticks, x, y, z) {
        var velocity = Entity.GetProp(entity, "CBasePlayer", "m_vecVelocity[0]");
        var new_pos = [x, y, z];
        new_pos[0] = new_pos[0] + velocity[0] * Globals.TickInterval() * ticks;
        new_pos[1] = new_pos[1] + velocity[1] * Globals.TickInterval() * ticks;
        new_pos[2] = new_pos[2] + velocity[2] * Globals.TickInterval() * ticks;
        return new_pos
    }

    function force_head(entity) {
        disable_body();
        var local_player = Entity.GetLocalPlayer();
        var eye_pos = get_proper_eye();
        var head_pos = Entity.GetHitboxPosition(entity, 0);
        var head_damage = Trace.Bullet(local_player, entity, eye_pos, head_pos);
        Ragebot.ForceTargetMinimumDamage(entity, head_damage[1])
    }

    function force_body() {
        if (!UI.IsHotkeyActive("Rage", "GENERAL", "General", "Force body aim")) UI.ToggleHotkey("Rage", "GENERAL", "General", "Force body aim")
    }

    function disable_body() {
        if (UI.IsHotkeyActive("Rage", "GENERAL", "General", "Force body aim")) UI.ToggleHotkey("Rage", "GENERAL", "General", "Force body aim")
    }

    function force_safe() {
        if (!UI.IsHotkeyActive("Rage", "GENERAL", "General", "Force safe point")) UI.ToggleHotkey("Rage", "GENERAL", "General", "Force safe point")
    }

    function disable_safe() {
        if (UI.IsHotkeyActive("Rage", "GENERAL", "General", "Force safe point")) UI.ToggleHotkey("Rage", "GENERAL", "General", "Force safe point")
    }

    function is_standing(entity) {
        var entity_velocity = Entity.GetProp(entity, "CBasePlayer", "m_vecVelocity[0]");
        var entity_speed = Math.sqrt(entity_velocity[0] * entity_velocity[0] + entity_velocity[1] * entity_velocity[1]);
        if (entity_speed >= 0 && entity_speed < 10) return true;
        else return false
    }

    function is_crouching(entity) {
        var flags = Entity.GetProp(entity, "CBasePlayer", "m_fFlags");
        if (flags & 1 << 1) return true;
        else return false
    }

    function is_slowwalking(entity) {
        var entity_velocity = Entity.GetProp(entity, "CBasePlayer", "m_vecVelocity[0]");
        var entity_speed = Math.sqrt(entity_velocity[0] * entity_velocity[0] + entity_velocity[1] * entity_velocity[1]);
        if (entity_speed >= 10 && entity_speed <= 85) return true;
        else return false
    }

    function is_inair(entity) {
        var flags = Entity.GetProp(entity, "CBasePlayer", "m_fFlags");
        if (!(flags & 1 << 0) && !(flags & 1 << 18)) return true;
        else return false
    }

    function is_lethal(entity) {
        var local_player = Entity.GetLocalPlayer();
        var eye_pos = get_proper_eye();
        var local_pos = extrapolate_tick(local_player, 25, eye_pos[0], eye_pos[1], eye_pos[2]);
        var entity_hp = Entity.GetProp(entity, "CBasePlayer", "m_iHealth");
        var pelvis_pos = Entity.GetHitboxPosition(entity, 2);
        var body_pos = Entity.GetHitboxPosition(entity, 3);
        var thorax_pos = Entity.GetHitboxPosition(entity, 4);
        var pelvis_trace = Trace.Bullet(local_player, entity, local_pos, pelvis_pos);
        var body_trace = Trace.Bullet(local_player, entity, local_pos, body_pos);
        var thorax_trace = Trace.Bullet(local_player, entity, local_pos, thorax_pos);
        var pelvis_dmg = pelvis_trace[1];
        var body_dmg = body_trace[1];
        var thorax_dmg = thorax_trace[1];
        var lethal_damage = Math.max(pelvis_dmg, body_dmg, thorax_dmg);
        if (entity_hp <= lethal_damage) return true;
        else return false
    }

    function draw_flags() {
        enemies = Entity.GetEnemies();
        for (i = 0; i < enemies.length; i++) {
            if (!Entity.IsValid(enemies[i])) continue;
            if (!Entity.IsAlive(enemies[i])) continue;
            if (Entity.IsDormant(enemies[i])) continue;
            var pos = Entity.GetRenderBox(enemies[i]);
            var font = Render.AddFont("Verdana", 7, 700);
            var a = pos[3] - pos[1];
            a /= 2;
            a += pos[1];
            switch (info[enemies[i]]) {
            case "HEAD":
                Render.StringCustom(a, pos[2] - 25, 1, "HEAD", [10, 10, 10, 125], font);
                Render.StringCustom(a - 1, pos[2] - 25, 1, "HEAD", [255, 95, 95, 255], font);
                break;
            case "BODY":
                Render.StringCustom(a, pos[2] - 25, 1, "BODY", [10, 10, 10, 125], font);
                Render.StringCustom(a - 1, pos[2] - 25, 1, "BODY", [237, 144, 255, 255], font);
                break;
            case "PREFER":
                Render.StringCustom(a, pos[2] - 25, 1, "PREFER", [10, 10, 10, 125], font);
                Render.StringCustom(a - 1, pos[2] - 25, 1, "PREFER", [95, 186, 255, 255], font);
                break
            }
            switch (safe[enemies[i]]) {
            case "SAFE":
                Render.StringCustom(a, pos[2] - 35, 1, "SAFE", [10, 10, 10, 125], font);
                Render.StringCustom(a - 1, pos[2] - 35, 1, "SAFE", [211, 255, 144, 255], font);
                break
            }
        }
    }

    function conditions() {
        if (get_value("Hitbox Conditions")) {
            enemies = Entity.GetEnemies();
            local_player = Entity.GetLocalPlayer();
            for (i = 0; i < enemies.length; i++) {
                if (!Entity.IsValid(enemies[i])) continue;
                if (!Entity.IsAlive(enemies[i])) continue;
                if (Entity.IsDormant(enemies[i])) continue;
                if (get_value("Hitbox Conditions")) {
                    head_condtions = get_value("Head conditions");
                    body_condtions = get_value("Body conditions");
                    safe_condtions = get_value("Safety conditions");
                    if (safe_condtions & 1 << 0 && is_lethal(enemies[i]) || safe_condtions & 1 << 1 && is_slowwalking(enemies[i]) || safe_condtions & 1 << 2 && is_standing(enemies[i]) || safe_condtions & 1 << 3 && is_inair(enemies[i]) || safe_condtions & 1 << 4 && is_crouching(enemies[i])) {
                        if (get_value("Safety Flags")) {
                            force_safe();
                            safe[enemies[i]] = "SAFE"
                        } else {
                            force_safe()
                        }
                    } else {
                        disable_safe();
                        safe[enemies[i]] = "NONE"
                    }
                    if (head_condtions & 1 << 0 && is_inair(enemies[i]) || head_condtions & 1 << 1 && is_crouching(enemies[i])) {
                        if (get_value("Safety Flags")) {
                            force_head(enemies[i]);
                            info[enemies[i]] = "HEAD"
                        } else {
                            force_head(enemies[i])
                        }
                    } else if (body_condtions & 1 << 0 && is_lethal(enemies[i]) || body_condtions & 1 << 1 && is_slowwalking(enemies[i]) || body_condtions & 1 << 2 && is_standing(enemies[i]) || body_condtions & 1 << 3 && is_inair(enemies[i]) || body_condtions & 1 << 4 && is_crouching(enemies[i])) {
                        if (get_value("Safety Flags")) {
                            force_body();
                            info[enemies[i]] = "BODY"
                        } else {
                            force_body()
                        }
                    } else {
                        if (get_value("Safety Flags")) {
                            disable_body();
                            info[enemies[i]] = "PREFER"
                        } else {
                            disable_body()
                        }
                    }
                }
            }
        }
    }
    Cheat.RegisterCallback("Draw", "draw_flags");
    Cheat.RegisterCallback("CreateMove", "conditions");
    UI.AddSliderInt("       +Miscellaneous/Visuals+", 0, 0);
    var screen_size = Global.GetScreenSize();
    UI.AddCheckbox("Indicators");
    var isInverted;
    LPx = [screen_size[0] / 2 - 41, screen_size[1] / 2 + 10];
    LPy = [screen_size[0] / 2 - 41, screen_size[1] / 2 - 10];
    LPz = [screen_size[0] / 2 - 61, screen_size[1] / 2 + 0];
    RPx = [screen_size[0] / 2 + 41, screen_size[1] / 2 + 10];
    RPy = [screen_size[0] / 2 + 41, screen_size[1] / 2 - 10];
    RPz = [screen_size[0] / 2 + 61, screen_size[1] / 2 + 0];
    BPx = [screen_size[0] / 2 + 10, screen_size[1] / 2 + 41];
    BPy = [screen_size[0] / 2 - 10, screen_size[1] / 2 + 41];
    BPz = [screen_size[0] / 2 - 0, screen_size[1] / 2 + 61];
    LPxx = [screen_size[0] / 2 - 42, screen_size[1] / 2 + 10];
    LPyy = [screen_size[0] / 2 - 42, screen_size[1] / 2 - 10];
    LPzz = [screen_size[0] / 2 - 62, screen_size[1] / 2 + 0];
    RPxx = [screen_size[0] / 2 + 42, screen_size[1] / 2 + 10];
    RPyy = [screen_size[0] / 2 + 42, screen_size[1] / 2 - 10];
    RPzz = [screen_size[0] / 2 + 62, screen_size[1] / 2 + 0];
    BPxx = [screen_size[0] / 2 + 10, screen_size[1] / 2 + 42];
    BPyy = [screen_size[0] / 2 - 10, screen_size[1] / 2 + 42];
    BPzz = [screen_size[0] / 2 - 0, screen_size[1] / 2 + 62];

    function render_arc(x, y, radius, radius_inner, start_angle, end_angle, segments, color) {
        while (360 % segments != 0) {
            segments++
        }
        segments = 360 / segments;
        for (var i = start_angle; i < start_angle + end_angle; i = i + segments) {
            var rad = i * Math.PI / 180;
            var rad2 = (i + segments) * Math.PI / 180;
            var rad_cos = Math.cos(rad);
            var rad_sin = Math.sin(rad);
            var rad2_cos = Math.cos(rad2);
            var rad2_sin = Math.sin(rad2);
            var x1_outer = x + rad_cos * radius;
            var y1_outer = y + rad_sin * radius;
            var x2_outer = x + rad2_cos * radius;
            var y2_outer = y + rad2_sin * radius;
            var x1_inner = x + rad_cos * radius_inner;
            var y1_inner = y + rad_sin * radius_inner;
            var x2_inner = x + rad2_cos * radius_inner;
            var y2_inner = y + rad2_sin * radius_inner;
            Render.Polygon([
                [x1_outer, y1_outer],
                [x2_outer, y2_outer],
                [x1_inner, y1_inner]
            ], color);
            Render.Polygon([
                [x1_inner, y1_inner],
                [x2_outer, y2_outer],
                [x2_inner, y2_inner]
            ], color)
        }
    }

    function drawString1() {
        const alpha = Math.sin(Math.abs(-Math.PI + Globals.Curtime() * (1 / 1) % (Math.PI * 2))) * 255;
        const alphax = Math.sin(Math.abs(-Math.PI + Globals.Curtime() * (1 / .5) % (Math.PI * 2))) * 255;
        isHideshots = UI.IsHotkeyActive("Rage", "Exploits", "Hide shots");
        isFakeduck = UI.IsHotkeyActive("Anti-Aim", "Extra", "Fake duck");
        isDoubletap = UI.IsHotkeyActive("Rage", "Exploits", "Doubletap");
        isInverted = UI.IsHotkeyActive("Anti-Aim", "Inverter");
        isLbyMode = UI.GetValue("Anti-Aim", "LBY mode");
        isBAIM = UI.IsHotkeyActive("Rage", "Force body aim");
        isDesyncMode = UI.GetValue("Anti-Aim", "Fake desync");
        localplayer_index = Entity.GetLocalPlayer();
        localplayer_alive = Entity.IsAlive(localplayer_index);
        charge = Exploit.GetCharge();
        max_angle = 360 * Exploit.GetCharge();
        center = Render.GetScreenSize();
        X = center[0] / 2;
        Y = center[1] / 2;
        if (localplayer_alive == true && UI.GetValue("Indicators")) {
            Render.String(screen_size[0] / 2, screen_size[1] / 2 + 76, 1, isBAIM ? "BODY" : "NORM", [0, 0, 0, 255], 3);
            Render.String(screen_size[0] / 2, screen_size[1] / 2 + 116, 1, isFakeduck ? "DUCK" : "", isFakeduck ? [0, 0, 0, 255] : [0, 0, 0, 0], 3);
            Render.String(screen_size[0] / 2, screen_size[1] / 2 + 75, 1, isBAIM ? "BODY" : "NORM", isBAIM ? [65, 180, 80, 255] : [45, 135, 185, 255], 3);
            Render.String(screen_size[0] / 2, screen_size[1] / 2 + 115, 1, isFakeduck ? "DUCK" : "", isFakeduck ? [255, 255, 255, 255] : [0, 0, 0, 0], 3);
            if (isDoubletap) {
                if (charge >= 1) {
                    Render.String(screen_size[0] / 2, screen_size[1] / 2 + 96, 1, isDoubletap ? "DT" : "DT", isDoubletap ? [0, 0, 0, 255] : [0, 0, 0, 255], 3);
                    Render.String(screen_size[0] / 2, screen_size[1] / 2 + 95, 1, isDoubletap ? "DT" : "DT", isDoubletap ? [65, 180, 80, 255] : [255, 0, 0, 255], 3);
                    Render.String(screen_size[0] / 2, screen_size[1] / 2 + 106, 1, isHideshots ? "HIDE" : "ANIM", isHideshots ? [0, 0, 0, 255] : [0, 0, 0, 255], 3);
                    Render.String(screen_size[0] / 2, screen_size[1] / 2 + 105, 1, isHideshots ? "HIDE" : "ANIM", isHideshots ? [145, 120, 229, 255] : [255, 153, 0, alpha], 3)
                }
                if (charge < 1) {
                    Render.String(screen_size[0] / 2 - 5, screen_size[1] / 2 + 96, 1, isDoubletap ? "DT" : "DT", isDoubletap ? [0, 0, 0, 255] : [0, 0, 0, 255], 3);
                    Render.String(screen_size[0] / 2 - 5, screen_size[1] / 2 + 95, 1, isDoubletap ? "DT" : "DT", isDoubletap ? [255 - charge * 190, charge * 180, charge * 80, 255] : [255, 0, 0, 255], 3);
                    Render.String(screen_size[0] / 2, screen_size[1] / 2 + 106, 1, "ANIM", [0, 0, 0, 255], 3);
                    Render.String(screen_size[0] / 2, screen_size[1] / 2 + 105, 1, "ANIM", [255, 153, 0, alpha], 3);
                    render_arc(X + 8, Y + 99, 5, 2.5, -90, 360, 36, [120, 120, 120, 190]);
                    render_arc(X + 8, Y + 99, 5, 2.5, -90, max_angle, 36, [255 - charge * 190, charge * 180, charge * 80, 255])
                }
            }
            if (!isDoubletap) {
                Render.String(screen_size[0] / 2, screen_size[1] / 2 + 96, 1, isDoubletap ? "DT" : "DT", isDoubletap ? [0, 0, 0, 255] : [0, 0, 0, 255], 3);
                Render.String(screen_size[0] / 2, screen_size[1] / 2 + 95, 1, isDoubletap ? "DT" : "DT", isDoubletap ? [65, 180, 80, 255] : [255, 0, 0, 255], 3);
                Render.String(screen_size[0] / 2, screen_size[1] / 2 + 106, 1, isHideshots ? "HIDE" : "ANIM", [0, 0, 0, 255], 3);
                Render.String(screen_size[0] / 2, screen_size[1] / 2 + 105, 1, isHideshots ? "HIDE" : "ANIM", isHideshots ? [145, 120, 229, 255] : [255, 153, 0, alpha], 3)
            }
            if (isDesyncMode == 0) {
                Render.String(screen_size[0] / 2, screen_size[1] / 2 + 86, 1, isInverted ? "LEFT" : "RIGHT", [0, 0, 0, 255], 3);
                Render.String(screen_size[0] / 2, screen_size[1] / 2 + 85, 1, isInverted ? "LEFT" : "RIGHT", [255, 255, 255, 255], 3)
            } else if (isDesyncMode == 1) {
                Render.String(screen_size[0] / 2, screen_size[1] / 2 + 86, 1, isInverted ? "RIGHT" : "LEFT", [0, 0, 0, 255], 3);
                Render.String(screen_size[0] / 2, screen_size[1] / 2 + 85, 1, isInverted ? "RIGHT" : "LEFT", [255, 255, 255, 255], 3)
            }
        }
    }

    function Main() {
        Global.RegisterCallback("Draw", "drawString1")
    }
    Main();
    UI.AddCheckbox("Pulse Bar");

    function pulserect() {
        if (UI.GetValue("Pulse Bar")) {
            const alpha = Math.sin(Math.abs(-Math.PI + Globals.Curtime() * (1 / .75) % (Math.PI * 2))) * 255;
            var screensize = Global.GetScreenSize();
            Render.FilledRect(0, 0, screensize[0], 5, [251, 204, 209, alpha])
        }
    }
    Global.RegisterCallback("Draw", "pulserect");
    UI.AddSliderInt("", 0, 0);
    UI.AddSliderInt("Doubletap Tolerance", 0, 3);

    function can_shift_shot(ticks_to_shift) {
        var me = Entity.GetLocalPlayer();
        var wpn = Entity.GetWeapon(me);
        if (me == null || wpn == null) return false;
        var tickbase = Entity.GetProp(me, "CCSPlayer", "m_nTickBase");
        var curtime = Globals.TickInterval() * (tickbase - ticks_to_shift);
        if (curtime < Entity.GetProp(me, "CCSPlayer", "m_flNextAttack")) return false;
        if (curtime < Entity.GetProp(wpn, "CBaseCombatWeapon", "m_flNextPrimaryAttack")) return false;
        return true
    }

    function _TBC_CREATE_MOVE() {
        var is_charged = Exploit.GetCharge();
        var reserve = UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Double tap tolerance");
        Exploit[(is_charged != 1 ? "Enable" : "Disable") + "Recharge"]();
        if (can_shift_shot(14) && is_charged != 1) {
            Exploit.DisableRecharge();
            Exploit.Recharge()
        }
        Exploit.OverrideTolerance(reserve);
        Exploit.OverrideShift(14 - reserve)
    }

    function _TBC_UNLOAD() {
        Exploit.EnableRecharge()
    }
    Cheat.RegisterCallback("CreateMove", "_TBC_CREATE_MOVE");
    Cheat.RegisterCallback("Unload", "_TBC_UNLOAD");
    UI.AddSliderInt("Better DT", 1, 3);
    UI.AddCheckbox("Better Doubletap");

    function on_ragebot_fire() {
        if (!UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Better Doubletap")) {
            return
        }
        player = Entity.GetLocalPlayer();
        weapon = Entity.GetWeapon(player);
        weaponName = Entity.GetName(weapon);
        ragebot_target_exploit = Event.GetInt("exploit");
        if (ragebot_target_exploit == 2) {
            UI.SetValue("Rage", "GENERAL", "Exploits", "Doubletap fast recovery", true)
        } else {
            UI.SetValue("Rage", "GENERAL", "Exploits", "Doubletap fast recovery", false)
        }
    }
    Global.RegisterCallback("ragebot_fire", "on_ragebot_fire");
    var flipper = 1;

    function doFlip() {
        flipper *= -1
    }
    var font = false;

    function drawAALine(angle, len, color, text) {
        var origin = Entity.GetProp(Entity.GetLocalPlayer(), "DT_BaseEntity", "m_vecOrigin");
        var angleRad = angle * (Math.PI / 180);
        var endPos = [origin[0], origin[1], origin[2]];
        endPos[0] += Math.cos(angleRad) * len;
        endPos[1] += Math.sin(angleRad) * len;
        var originScreen = Render.WorldToScreen(origin);
        var endScreen = Render.WorldToScreen(endPos);
        Render.Line(originScreen[0], originScreen[1], endScreen[0], endScreen[1], color);
        Render.String(endScreen[0] + 1, endScreen[1] + 1, 1, text, [0, 0, 0, 255], font);
        Render.String(endScreen[0], endScreen[1], 1, text, color, font)
    }

    function render() {
        font = Render.GetFont("Arial.ttf", 12, true);
        if (Entity.IsValid(Entity.GetLocalPlayer())) {
            drawAALine(Local.GetFakeYaw(), 40, [0, 150, 255, 255], "FAKE");
            drawAALine(Local.GetRealYaw(), 45, [255, 0, 0, 255], "REAL");
            var delta = Math.abs(Math.round(Local.GetFakeYaw() - Local.GetRealYaw()));
            if (delta > 180) {
                delta -= 360
            }
            drawAALine(Local.GetRealYaw(), 0, [255, 255, 255, 255], "DELTA: " + Math.abs(delta))
        }
    }
    var lastMove = false;
    var low = false;
    var ticker = 0;

    function run() {
        ticker++;
        var v = Entity.GetProp(Entity.GetLocalPlayer(), "DT_CSPlayer", "m_vecVelocity[0]");
        var speed = Math.sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2]);
        var shouldSwitch = speed > 1 != lastMove;
        var crouch = Entity.GetProp(Entity.GetLocalPlayer(), "CCSPlayer", "m_flDuckAmount") > .4;
        var deviator = Math.round(Globals.Realtime() * 300) % 100;
        deviator /= 1e3;
        var mult = flipper;
        if (shouldSwitch && deviator > .4) {
            flipper *= -1;
            if (deviator > .6) {
                low = !low
            }
        }
        AntiAim.SetOverride(1);
        if (speed < 1) {
            AntiAim.SetLBYOffset(-60 * mult + deviator * 6 * mult);
            AntiAim.SetRealOffset(-14 * mult);
            AntiAim.SetFakeOffset(5 * mult * deviator)
        } else {
            var delta = 51 * flipper;
            if (low) {
                delta /= 5;
                if (ticker % 20 == 0) {
                    delta *= 8
                }
            }
            AntiAim.SetRealOffset(delta);
            AntiAim.SetFakeOffset(-delta / 2)
        }
        lastMove = speed > 1
    }
    Cheat.RegisterCallback("bullet_impact", "doFlip");
    Cheat.RegisterCallback("CreateMove", "run");
    Cheat.RegisterCallback("Draw", "render");

    function getarget() {
        target = Ragebot.GetTarget();
        if (Entity.GetName(target) == "enemy") {
            Ragebot.IgnoreTarget(0)
        }
    }

    function calcAngle(source, entityPos) {
        for (i = 1, 64; i < players.length; i) var delta = [i];
        delta[0] = source[0] - entityPos[0];
        delta[1] = source[1] - entityPos[1];
        delta[2] = source[2] - entityPos[2];
        var angles = [];
        var viewangles = Local.GetViewAngles();
        angles[0] = RADTODEG(Math.atan(delta[2] / Math.hypot(delta[0], delta[1]))) - viewangles[0];
        angles[1] = RADTODEG(Math.atan(delta[1] / delta[0])) - viewangles[1];
        angles[2] = 0;
        if (delta[0] >= t_delta) angles[1] += t_delta;
        return angles
    }

    function geteyepos() {
        localplayer_eyepos = Entity.GetEyePosition(Entity.GetLocalPlayer());
        Cheat.Print("Local player eye pos X: " + localplayer_eyepos[0] + " Y: " + localplayer_eyepos[1] + " Z: " + localplayer_eyepos[2] + " \n")
    }

    function getenemieshead() {
        enemies = Entity.GetEnemies();
        for (i = 1, 64; i < enemies.length; i) {
            hitbox_pos = Entity.GetHitboxPosition(enemies[i], 0);
            enemyName = Entity.GetName(enemies[i]);
            Cheat.Print(enemyName + "'s HEAD hitbox position is X: " + hitbox_pos[0] + " Y: " + hitbox_pos[1] + " Z: " + hitbox_pos[2] + " \n")
        }
    }

    function seteyepos() {
        Entity.SetEyePosition(1)
    }

    function GetVelocity(index) {
        var velocity = Entity.GetProp(index, "CBasePlayer", "m_vecVelocity[0]");
        return Math.sqrt(velocity[0] * velocity[0] + velocity[1] * velocity[1])
    }

    function getmyenemy() {
        players = Entity.GetPlayers();
        for (i = 1, 64; i < players.length; i) {
            if (Entity.IsEnemy(players[i])) {
                plrName = Entity.GetName(players[i]);
                Cheat.Print("Player: " + plrName + " is enemy\n")
            }
        }
    }

    function setAngle() {
        curAngle = Local.GetViewAngles();
        UserCMD.SetViewAngles([curAngle[0], t_delta, curAngle[2]], true)
    }

    function getrealyaw() {
        realyaw = Local.GetRealYaw();
        Cheat.Print(realyaw + "\n")
    }

    function getfakeyaw() {
        fakeyaw = Local.GetFakeYaw();
        Cheat.Print(fakeyaw + "\n")
    }

    function getvalues() {
        t_delta = UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Delta:");
        t_ticks = UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Ticks:")
    }

    function extrapolate_tick(entity, ticks, x, y, z) {
        velocity = Entity.GetProp(entity, "CBasePlayer", "m_vecVelocity[0]");
        new_pos = [x, y, z];
        new_pos[0] = new_pos[0] + velocity[0] * Globals.TickInterval(t_ticks) * ticks;
        new_pos[1] = new_pos[1] + velocity[1] * Globals.TickInterval(t_ticks) * ticks;
        new_pos[2] = new_pos[2] + velocity[2] * Globals.TickInterval(t_ticks) * ticks;
        return new_pos
    }

    function tick_count() {
        Globals.Tickcount(t_ticks)
    }
    autoHitboxes = UI.GetValue("Rage", "AUTOSNIPER", "Targeting", "Hitboxes");
    awpHitboxes = UI.GetValue("Rage", "AWP", "Targeting", "Hitboxes");
    scoutHitboxes = UI.GetValue("Rage", "SCOUT", "Targeting", "Hitboxes");
    heavyHitboxes = UI.GetValue("Rage", "HEAVY PISTOL", "Targeting", "Hitboxes");
    pistolHitboxes = UI.GetValue("Rage", "PISTOL", "Targeting", "Hitboxes");
    generalHitboxes = UI.GetValue("Rage", "GENERAL", "Targeting", "Hitboxes");
    var original = true;

    function forceheadonkey() {
        if (World.GetServerString() !== "") {
            var forceHeadOnly = UI.IsHotkeyActive("Misc", "JAVASCRIPT", "Script items", "Force Head");
            if (forceHeadOnly == 1) {
                if (original === true) {
                    autoHitboxes = UI.GetValue("Rage", "AUTOSNIPER", "Targeting", "Hitboxes");
                    awpHitboxes = UI.GetValue("Rage", "AWP", "Targeting", "Hitboxes");
                    scoutHitboxes = UI.GetValue("Rage", "SCOUT", "Targeting", "Hitboxes");
                    heavyHitboxes = UI.GetValue("Rage", "HEAVY PISTOL", "Targeting", "Hitboxes");
                    pistolHitboxes = UI.GetValue("Rage", "PISTOL", "Targeting", "Hitboxes");
                    generalHitboxes = UI.GetValue("Rage", "GENERAL", "Targeting", "Hitboxes");
                    original = false
                }
                UI.SetValue("Rage", "AUTOSNIPER", "Targeting", "Hitboxes", 1);
                UI.SetValue("Rage", "AWP", "Targeting", "Hitboxes", 1);
                UI.SetValue("Rage", "SCOUT", "Targeting", "Hitboxes", 1);
                UI.SetValue("Rage", "HEAVY PISTOL", "Targeting", "Hitboxes", 1);
                UI.SetValue("Rage", "PISTOL", "Targeting", "Hitboxes", 1);
                UI.SetValue("Rage", "GENERAL", "Targeting", "Hitboxes", 1)
            } else {
                if (original !== true) {
                    UI.SetValue("Rage", "AUTOSNIPER", "Targeting", "Hitboxes", autoHitboxes);
                    UI.SetValue("Rage", "AWP", "Targeting", "Hitboxes", awpHitboxes);
                    UI.SetValue("Rage", "SCOUT", "Targeting", "Hitboxes", scoutHitboxes);
                    UI.SetValue("Rage", "HEAVY PISTOL", "Targeting", "Hitboxes", heavyHitboxes);
                    UI.SetValue("Rage", "PISTOL", "Targeting", "Hitboxes", pistolHitboxes);
                    UI.SetValue("Rage", "GENERAL", "Targeting", "Hitboxes", generalHitboxes);
                    original = true
                }
            }
        }
    }
    UI.AddSliderInt("Double tap speed (lower is faster)", 0, 3);

    function can_shift_shot(ticks_to_shift) {
        var me = Entity.GetLocalPlayer();
        var wpn = Entity.GetWeapon(me);
        if (me == null || wpn == null) return false;
        var tickbase = Entity.GetProp(me, "CCSPlayer", "m_nTickBase");
        var curtime = Globals.TickInterval() * (tickbase - ticks_to_shift);
        if (curtime < Entity.GetProp(me, "CCSPlayer", "m_flNextAttack")) return false;
        if (curtime < Entity.GetProp(wpn, "CBaseCombatWeapon", "m_flNextPrimaryAttack")) return false;
        return true
    }

    function _TBC_CREATE_MOVE() {
        var is_charged = Exploit.GetCharge();
        var reserve = UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Double tap speed (lower is faster)");
        Exploit[(is_charged != 1 ? "Enable" : "Disable") + "Recharge"]();
        if (can_shift_shot(14) && is_charged != 1) {
            Exploit.DisableRecharge();
            Exploit.Recharge()
        }
        Exploit.OverrideTolerance(reserve);
        Exploit.OverrideShift(14 - reserve)
    }

    function _TBC_UNLOAD() {
        Exploit.EnableRecharge()
    }
    Cheat.RegisterCallback("CreateMove", "_TBC_CREATE_MOVE");
    Cheat.RegisterCallback("Unload", "_TBC_UNLOAD");
    var screen_size = Global.GetScreenSize();
    var isLeftActive = UI.IsHotkeyActive("Misc", "JAVASCRIPT", "Script items", "Left Hotkey");
    var isRightActive = UI.IsHotkeyActive("Misc", "JAVASCRIPT", "Script items", "Right Hotkey");
    var isBackActive = UI.IsHotkeyActive("Misc", "JAVASCRIPT", "Script items", "Back Hotkey");
    var isInverted;
    var drawLeft = 0;
    var drawRight = 0;
    var drawBack = 1;
    UI.AddColorPicker("Selected arrow color");
    UI.AddHotkey("Left Hotkey");
    UI.AddHotkey("Back Hotkey");
    UI.AddHotkey("Right Hotkey");
    LPx = [screen_size[0] / 2 - 50, screen_size[1] / 2 + 10];
    LPy = [screen_size[0] / 2 - 50, screen_size[1] / 2 - 10];
    LPz = [screen_size[0] / 2 - 70, screen_size[1] / 2];
    RPx = [screen_size[0] / 2 + 50, screen_size[1] / 2 + 10];
    RPy = [screen_size[0] / 2 + 50, screen_size[1] / 2 - 10];
    RPz = [screen_size[0] / 2 + 70, screen_size[1] / 2];
    LPxx = [screen_size[0] / 2 - 49, screen_size[1] / 2 + 12];
    LPyy = [screen_size[0] / 2 - 49, screen_size[1] / 2 - 12];
    LPzz = [screen_size[0] / 2 - 73, screen_size[1] / 2];
    RPxx = [screen_size[0] / 2 + 49, screen_size[1] / 2 + 12];
    RPyy = [screen_size[0] / 2 + 49, screen_size[1] / 2 - 12];
    RPzz = [screen_size[0] / 2 + 73, screen_size[1] / 2];
    BPx = [screen_size[0] / 2 + 10, screen_size[1] / 2 + 50];
    BPy = [screen_size[0] / 2 - 10, screen_size[1] / 2 + 50];
    BPz = [screen_size[0] / 2, screen_size[1] / 2 + 70];
    BPxx = [screen_size[0] / 2 + 12, screen_size[1] / 2 + 49];
    BPyy = [screen_size[0] / 2 - 12, screen_size[1] / 2 + 49];
    BPzz = [screen_size[0] / 2, screen_size[1] / 2 + 73];

    function drawString() {
        selectedcp = UI.GetColor("Misc", "JAVASCRIPT", "Script items", "Selected arrow color");
        selected_red = selectedcp[0];
        selected_green = selectedcp[1];
        selected_blue = selectedcp[2];
        selected_alpha = selectedcp[3];
        const alpha = Math.sin(Math.abs(-Math.PI + Globals.Curtime() * (1 / .75) % (Math.PI * 2))) * 255;
        const alphaa = Math.sin(Math.abs(-Math.PI + Globals.Curtime() * (1 / 2) % (Math.PI * 2))) * 255;
        isHideshots = UI.IsHotkeyActive("Rage", "Exploits", "Hide shots");
        isFakeduck = UI.IsHotkeyActive("Anti-Aim", "Extra", "Fake duck");
        isDoubletap = UI.IsHotkeyActive("Rage", "Exploits", "Doubletap");
        isInverted = UI.IsHotkeyActive("Anti-Aim", "Fake angles", "Inverter");
        isDmgActive = UI.IsHotkeyActive("Rage", "GENERAL", "Accuracy", "Minimum damage (on key)");
        isLbyMode = UI.GetValue("Anti-Aim", "Fake angles", "LBY mode");
        isDesyncMode = UI.GetValue("Anti-Aim", "Fake angles", "Fake desync");
        localplayer_index = Entity.GetLocalPlayer();
        localplayer_alive = Entity.IsAlive(localplayer_index);
        if (localplayer_alive == true) {
            Render.Polygon([LPxx, LPzz, LPyy], [0, 0, 0, 60]);
            Render.Polygon([RPyy, RPzz, RPxx], [0, 0, 0, 60]);
            Render.Polygon([BPyy, BPxx, BPzz], [0, 0, 0, 60]);
            Render.String(screen_size[0] / 2 + 1, screen_size[1] / 2 + 101, 1, isLbyMode ? "FAKE" : "NORM", [0, 0, 0, 255], 3);
            Render.String(screen_size[0] / 2 + 1, screen_size[1] / 2 + 121, 1, isDoubletap ? "DT" : "DT", isDoubletap ? [0, 0, 0, 255] : [0, 0, 0, 255], 3);
            Render.String(screen_size[0] / 2 + 1, screen_size[1] / 2 + 131, 1, isDmgActive ? "WALL" : "DMG", isDmgActive ? [0, 0, 0, 255] : [0, 0, 0, 255], 3);
            Render.String(screen_size[0] / 2 + 1, screen_size[1] / 2 + 141, 1, isHideshots ? "HIDE" : "ANIM", isHideshots ? [0, 0, 0, 255] : [0, 0, 0, 255], 3);
            Render.String(screen_size[0] / 2 + 1, screen_size[1] / 2 + 151, 1, isFakeduck ? "DUCK" : "", isFakeduck ? [0, 0, 0, 255] : [0, 0, 0, 0], 3);
            Render.String(screen_size[0] / 2, screen_size[1] / 2 + 100, 1, isLbyMode ? "FAKE" : "NORM", [0, 255, 255, 255], 3);
            Render.String(screen_size[0] / 2, screen_size[1] / 2 + 120, 1, isDoubletap ? "DT" : "DT", isDoubletap ? [0, 255, 0, 255] : [255, 0, 0, 255], 3);
            Render.String(screen_size[0] / 2, screen_size[1] / 2 + 130, 1, isDmgActive ? "WALL" : "DMG", isDmgActive ? [255, 159, 212, 255] : [255, 159, 212, 255], 3);
            Render.String(screen_size[0] / 2, screen_size[1] / 2 + 140, 1, isHideshots ? "HIDE" : "ANIM", isHideshots ? [145, 120, 229, 255] : [255, 153, 0, alpha], 3);
            Render.String(screen_size[0] / 2, screen_size[1] / 2 + 150, 1, isFakeduck ? "DUCK" : "", isFakeduck ? [255, 255, 255, 255] : [0, 0, 0, 0], 3);
            if (isDesyncMode == 0) {
                Render.String(screen_size[0] / 2 + 1, screen_size[1] / 2 + 111, 1, isInverted ? "LEFT" : "RIGHT", [0, 0, 0, 255], 3);
                Render.String(screen_size[0] / 2, screen_size[1] / 2 + 110, 1, isInverted ? "LEFT" : "RIGHT", [255, 255, 255, 255], 3)
            } else if (isDesyncMode == 1) {
                Render.String(screen_size[0] / 2 + 1, screen_size[1] / 2 + 111, 1, isInverted ? "RIGHT" : "LEFT", [0, 0, 0, 255], 3);
                Render.String(screen_size[0] / 2, screen_size[1] / 2 + 110, 1, isInverted ? "RIGHT" : "LEFT", [255, 255, 255, 255], 3)
            }
            if (drawLeft) {
                Render.Polygon([LPx, LPz, LPy], [selected_red, selected_green, selected_blue, selected_alpha])
            } else if (drawRight) {
                Render.Polygon([RPy, RPz, RPx], [selected_red, selected_green, selected_blue, selected_alpha])
            } else if (drawBack) {
                Render.Polygon([BPy, BPx, BPz], [selected_red, selected_green, selected_blue, selected_alpha])
            }
        }
    }

    function onCreateMove() {
        isLeftActive = UI.IsHotkeyActive("Misc", "JAVASCRIPT", "Script items", "Left Hotkey");
        isRightActive = UI.IsHotkeyActive("Misc", "JAVASCRIPT", "Script items", "Right Hotkey");
        isBackActive = UI.IsHotkeyActive("Misc", "JAVASCRIPT", "Script items", "Back Hotkey");
        if (isLeftActive) {
            drawLeft = 1;
            drawBack = 0;
            drawRight = 0;
            UI.SetValue("Anti-Aim", "Rage Anti-Aim", "Yaw offset", -90);
            UI.SetValue("Anti-Aim", "Fake Angles", "Hide real angle", false)
        } else if (isRightActive) {
            drawLeft = 0;
            drawBack = 0;
            drawRight = 1;
            UI.SetValue("Anti-Aim", "Rage Anti-Aim", "Yaw offset", 90);
            UI.SetValue("Anti-Aim", "Fake Angles", "Hide real angle", false)
        } else if (isBackActive) {
            drawLeft = 0;
            drawBack = 1;
            drawRight = 0;
            UI.SetValue("Anti-Aim", "Rage Anti-Aim", "Yaw offset", 0);
            UI.SetValue("Anti-Aim", "Fake Angles", "Hide real angle", false)
        }
    }

    function Main() {
        Global.RegisterCallback("Draw", "drawString");
        Global.RegisterCallback("CreateMove", "onCreateMove")
    }
    Main();
    var iExploitID = 0;
    var bDoubleTapped = false;
    var bShouldRecharge = false;
    var ForceCharge = false;
    var iLastShotTime = 1;
    var props = 0;
    var screen_size = Global.GetScreenSize();
    var old_percentage = 0;
    UI.AddCheckbox("Tripletap");
    UI.AddDropdown("Tripletap Mode", ["Full", "Accurate"]);
    UI.SetValue("Rage", "GENERAL", "Exploits", "Doubletap", 1);
    UI.SetValue("Rage", "GENERAL", "Exploits", "Teleport release", true);
    UI.AddCheckbox("Doubletap Indicator");
    UI.AddCheckbox("Teleport Indicator");
    UI.AddCheckbox("Onshot AA Indicator");
    UI.AddCheckbox("Min DMG Override Indicator");
    UI.AddCheckbox("Full Teleport");

    function on_ragebot_fire() {
        ragebot_target_exploit = Event.GetInt("exploit");
        if (UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Tripletap")) {
            if (UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Full Teleport")) {
                ragebot_target_exploit == 2 ? UI.ToggleHotkey("Rage", "GENERAL", "Exploits", "Doubletap") : UI.ToggleHotkey("Rage", "GENERAL", "Exploits", "Doubletap")
            }
            if (ragebot_target_exploit == 2) {
                UI.SetValue("Rage", "GENERAL", "Exploits", "Doubletap fast recovery", true)
            } else {
                UI.SetValue("Rage", "GENERAL", "Exploits", "Doubletap fast recovery", true)
            }
        }
    }

    function event_rbot_fire() {
        if (!player_hurt) return;
        iExploitID = Event.GetInt("exploit");
        if (!UI.GetValue("Misc", "JAVASCRIPT", "Script Items", "Tripletap")) return;
        if (iExploitID == 2) {
            iLastShotTime = Global.Tickcount();
            bDoubleTapped = true;
            UI.SetValue("Rage", "GENERAL", "Exploits", "Doubletap", 0);
            bShouldRecharge = true
        }
        ForceCharge = bShouldRecharge ? true : false;
        if (ForceCharge && Global.Tickcount() >= Global.TickInterval() * 10 + iLastShotTime) UI.SetValue("Rage", "GENERAL", "Exploits", "Doubletap", 1)
    }

    function event_ragebot_fire() {
        ragebot_target_exploit = Event.GetInt("exploit");
        if (!UI.GetValue("Misc", "JAVASCRIPT", "Script Items", "Tripletap")) {
            ragebot_target_exploit == 2 ? UI.ToggleHotkey("Rage", "GENERAL", "Exploits", "Doubletap") : UI.ToggleHotkey("Rage", "GENERAL", "Exploits", "Doubletap")
        }
    }

    function modecheck() {
        if (UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Tripletap Mode") == 0) {
            on_ragebot_fire()
        }
        if (UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Tripletap Mode") == 1) {
            event_rbot_fire()
        }
        UI.SetValue("Rage", "GENERAL", "Exploits", "Teleport release", true)
    }

    function getPercentage(number, percentage) {
        return percentage / 100 * number
    }

    function main() {
        if (!UI.GetValue("Misc", "JAVASCRIPT", "Script Items", "Doubletap Indicator")) return;
        const screenSize = Global.GetScreenSize();
        const gapX = getPercentage(screenSize[0], 48);
        const gapY = getPercentage(screenSize[1], 54);
        if (UI.IsHotkeyActive("Rage", "GENERAL", "Exploits", "Doubletap")) {
            Render.String(gapX, gapY, 0, "DoubleTap", [10, 255, 114, 254], 4, 3)
        }
    }

    function EXTToggle() {
        UI.SetValue("Misc", "JAVASCRIPT", "Script items", "Full Teleport", false);
        Render.String(25, 1e3 - 5, 0, " ", [255, 0, 0, 255], 4.6);
        if (UI.IsHotkeyActive("Misc", "JAVASCRIPT", "Script Items", "EXTToggle")) {
            UI.SetValue("Misc", "JAVASCRIPT", "Script items", "Full Teleport", true);
            Render.String(25, 1e3 - 5, 0, " ", [0, 255, 0, 255], 4.6)
        }
    }

    function EXTKey() {
        UI.AddHotkey("Toggle Teleport", "JAVASCRIPT", "Script Items", "EXTToggle")
    }

    function tp() {
        if (!UI.GetValue("Misc", "JAVASCRIPT", "Script Items", "Teleport Indicator")) return;
        const screenSize = Global.GetScreenSize();
        const gapX = getPercentage(screenSize[0], 48.5);
        const gapY = getPercentage(screenSize[1], 56);
        if (UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Full Teleport")) {
            Render.String(gapX, gapY, 0, "Teleport", [10, 255, 114, 254], 4, 3)
        }
    }

    function hs() {
        if (!UI.GetValue("Misc", "JAVASCRIPT", "Script Items", "Onshot AA Indicator")) return;
        const screenSize = Global.GetScreenSize();
        const gapX = getPercentage(screenSize[0], 51);
        const gapY = getPercentage(screenSize[1], 58);
        if (UI.IsHotkeyActive("Rage", "GENERAL", "Exploits", "Hide shots")) {
            Render.String(gapX, gapY, 0, "HS", [10, 229, 225, 255], 4, 3)
        }
    }

    function dmg() {
        if (!UI.GetValue("Misc", "JAVASCRIPT", "Script Items", "Min DMG Override Indicator")) return;
        const screenSize = Global.GetScreenSize();
        const gapX = getPercentage(screenSize[0], 51);
        const gapY = getPercentage(screenSize[1], 60);
        if (UI.IsHotkeyActive("Rage", "GENERAL", "Accuracy", "Minimum Damage (on key)")) {
            Render.String(gapX, gapY, 0, "DMG", [10, 229, 225, 255], 4, 3)
        }
    }
    Global.RegisterCallback("Draw", "main");
    Global.RegisterCallback("Draw", "tp");
    Global.RegisterCallback("Draw", "hs");
    Global.RegisterCallback("Draw", "dmg");
    Global.RegisterCallback("ragebot_fire", "modecheck");
    Global.RegisterCallback("Draw", "EXTToggle");
    EXTKey();
    var fps = 0;
    var iterate = 0;
    var averagefps = 0;

    function watermark() {
        var fps1 = 1 / Global.Frametime();
        var fps2 = Math.floor(fps1);
        averagefps = (fps1 + fps2) / 2;
        iterate++;
        if (iterate % 100 == 0) {
            fps = Math.floor(averagefps)
        }
        var today = new Date;
        var hours = today.getHours();
        var currenthours = hours % 12;
        var pmamtext = hours >= 12 ? "PM" : "AM";
        var minutestext = today.getMinutes() >= 10 ? today.getMinutes() : "0" + today.getMinutes();
        var datetime = currenthours + ":" + minutestext + " " + pmamtext;
        Render.FilledRect(0, 0, 6e3, 25, [30, 30, 39, 255]);
        Render.GradientRect(0, 25, 6e3, 3, 3, [165, 24, 71, 255], [58, 31, 87, 255]);
        font = Render.AddFont("eagle", 14, 100);
        font2 = Render.AddFont("Gotham Bold", 12, 100);
        Render.StringCustom(180, 2, 1, "  insecure | " + Cheat.GetUsername() + " | " + datetime + " | fps: " + fps, [255, 255, 255, 255], font2);
        Render.StringCustom(15, 2, 1, " a", [255, 255, 255, 255], font)
    }
    UI.AddCheckbox("Teleport on peek");
    UI.AddHotkey("Key");
    UI.AddSliderInt("Predicted ticks", 2, 5);
    UI.AddSliderFloat("Teleport cooldown", 1, 10);
    UI.AddSliderInt("Minimum damage to trigger teleport", 1, 20);
    UI.AddCheckbox("Enable doubletap after teleport");
    UI.AddCheckbox("Recharge after teleport");
    UI.AddCheckbox("Render indicator");
    var vector = {
        _class: "vector"
    };
    vector["new"] = function (data) {
        return {
            x: data[0],
            y: data[1],
            z: data[2]
        }
    };
    vector.operate = function (vec, vec2, operation) {
        switch (operation) {
        case "+":
            return {
                x: vec.x + vec2.x, y: vec.y + vec2.y, z: vec.z + vec2.z
            };
        case "-":
            return {
                x: vec.x - vec2.x, y: vec.y - vec2.y, z: vec.z - vec2.z
            };
        case "*":
            return {
                x: vec.x * vec2.x, y: vec.y * vec2.y, z: vec.z * vec2.z
            };
        case "x":
            return {
                x: vec.x * vec2, y: vec.y * vec2, z: vec.z * vec2
            };
        case "/":
            return {
                x: vec.x / vec2.x, y: vec.y / vec2.y, z: vec.z / vec2.z
            };
        default:
            throw new Error("[Vector] Invalid operation type.")
        }
    };
    vector.to_array = function (vec) {
        return [vec.x, vec.y, vec.z]
    };

    function extrapolate_tick(headpos, velocity, tick_amt) {
        return vector.operate(headpos, vector.operate(velocity, tick_amt * Globals.TickInterval(), "x"), "+")
    }
    var has_teleported = false;
    var should_teleport = false;
    var last_teleport_time = .5;
    var js_items = ["Misc", "JAVASCRIPT", "Script Items"];

    function on_move() {
        if (UI.GetValue(js_items, "Teleport on peek") && UI.IsHotkeyActive(js_items, "Key")) {
            var is_dt_enabled = UI.IsHotkeyActive("Rage", "Exploits", "Doubletap");
            var teleport_cooldown = UI.GetValue(js_items, "Teleport cooldown");
            if (Globals.Curtime() > last_teleport_time + teleport_cooldown) {
                if (is_dt_enabled && Exploit.GetCharge() < .17) {
                    return
                }
                if (should_teleport && !has_teleported) {
                    if (is_dt_enabled) {
                        UI.ToggleHotkey("Rage", "Exploits", "Doubletap");
                        last_teleport_time = Globals.Curtime();
                        should_teleport = false;
                        has_teleported = true;
                        return
                    } else {
                        UI.ToggleHotkey("Rage", "Exploits", "Doubletap");
                        return
                    }
                }
                var local = Entity.GetLocalPlayer();
                var local_eyepos = Entity.GetEyePosition(local);
                var local_eyepos_vector = vector["new"](local_eyepos);
                var local_velocity = Entity.GetProp(local, "CBasePlayer", "m_vecVelocity[0]");
                var local_velocity_vector = vector["new"](local_velocity);
                var extrapolated_headpos = extrapolate_tick(local_eyepos_vector, local_velocity_vector, UI.GetValue(js_items, "Predicted ticks"));
                var enemies = Entity.GetEnemies();
                var teleport_mindamage = UI.GetValue(js_items, "Minimum damage to trigger teleport");
                if (!should_teleport && !has_teleported) {
                    for (var i = 0; i < enemies.length; i++) {
                        if (Entity.IsValid(enemies[i]) && Entity.IsAlive(enemies[i]) && !Entity.IsDormant(enemies[i])) {
                            var enemy_headpos = Entity.GetHitboxPosition(enemies[i], 0);
                            var enemy_pelvispos = Entity.GetHitboxPosition(enemies[i], 2);
                            var trace = Trace.Bullet(local, enemies[i], vector.to_array(extrapolated_headpos), enemy_pelvispos);
                            var trace2 = Trace.Bullet(local, enemies[i], vector.to_array(extrapolated_headpos), enemy_headpos);
                            if (trace[1] > teleport_mindamage || trace2[1] > teleport_mindamage) {
                                should_teleport = true;
                                break
                            }
                        }
                    }
                }
            } else if (has_teleported) {
                var should_attempt_to_reenable_dt = UI.GetValue(js_items, "Enable doubletap after teleport");
                var should_attempt_to_recharge = UI.GetValue(js_items, "Recharge after teleport");
                if (should_attempt_to_reenable_dt) {
                    if (!is_dt_enabled) {
                        UI.ToggleHotkey("Rage", "Exploits", "Doubletap")
                    }
                    if (should_attempt_to_recharge) {
                        Exploit.Recharge()
                    }
                }
                has_teleported = false
            }
        }
    }

    function update_menu() {
        var is_script_enabled = UI.GetValue(js_items, "Teleport on peek");
        UI.SetEnabled(js_items, "Key", is_script_enabled);
        UI.SetEnabled(js_items, "Predicted ticks", is_script_enabled);
        UI.SetEnabled(js_items, "Teleport cooldown", is_script_enabled);
        UI.SetEnabled(js_items, "Minimum damage to trigger teleport", is_script_enabled);
        UI.SetEnabled(js_items, "Enable doubletap after teleport", is_script_enabled);
        var is_dt_shit_enabled = UI.GetValue(js_items, "Enable doubletap after teleport");
        UI.SetEnabled(js_items, "Recharge after teleport", is_script_enabled && is_dt_shit_enabled);
        UI.SetEnabled(js_items, "Render indicator", is_script_enabled)
    }

    function indicator() {
        if (UI.GetValue(js_items, "Teleport on peek") && UI.GetValue(js_items, "Render indicator") && UI.IsHotkeyActive(js_items, "Key")) {
            if (World.GetServerString() == "") {
                return
            }
            if (!Entity.IsAlive(Entity.GetLocalPlayer())) {
                return
            }
            var screen_size = Render.GetScreenSize();
            var teleport_cooldown = UI.GetValue(js_items, "Teleport cooldown");
            Render.String(30, screen_size[1] * .924, 1, "                  Teleport on peek", Globals.Curtime() > last_teleport_time + teleport_cooldown ? [255 * (1 - Exploit.GetCharge()), 2555 * Exploit.GetCharge(), 0, 255] : [255, 0, 0, 200], 4)
        }
    }

    function reset_shit() {
        has_teleported = false;
        should_teleport = false;
        last_teleport_time = 0
    }
    var tags = {
        "insecure.js": "insecure.js"
    };

    function collect_keys(tbl, custom) {
        var keys = Object.keys(tbl);
        if (custom) {
            keys.unshift("Disabled");
            keys.push("Custom")
        }
        return keys
    }
    var __lastSetClanTag = "";

    function _setClanTag(tag) {
        if (__lastSetClanTag == tag) return false;
        __lastSetClanTag = tag;
        Local.SetClanTag(tag);
        return true
    }
    var tag = "";
    var tag_index = 0;
    var tag_index_offset = 0;
    var tag_length = 0;
    var tag_reverse = 0;
    var tag_last_index = 0;
    var time_last_update = 0;
    var update_after = Globals.Curtime();
    var commands = 0;

    function staticTag() {
        if (tag == "Disabled") return;
        _setClanTag(tag)
    }

    function timeTag() {
        var curTime = Globals.Curtime();
        if (curTime - time_last_update < 1) return;
        time_last_update = curTime;
        var curDate = new Date;
        var hours = curDate.getHours() + "";
        if (hours.length == 1) hours = "0" + hours;
        var minutes = curDate.getMinutes() + "";
        if (minutes.length == 1) minutes = "0" + minutes;
        var seconds = curDate.getSeconds() + "";
        if (seconds.length == 1) seconds = "0" + seconds;
        var time_tag = hours + ":" + minutes + ":" + seconds;
        _setClanTag(time_tag)
    }

    function defaultTag() {
        if (tag_index == tag_last_index) return;
        _setClanTag(tag_index == 0 ? "\0" : tag.substr(0, tag_index))
    }

    function reverseTag() {
        if (tag_index == tag_last_index) return;
        if (tag_reverse <= tag_length) {
            _setClanTag(tag.substr(0, tag_index))
        } else {
            _setClanTag(tag_length - tag_index == 0 ? "\0" : tag.substr(0, tag_length - tag_index))
        }
    }

    function loopTag() {
        if (tag_index == tag_last_index) return;
        var loop_tag = tag;
        for (var i = 0; i <= tag_index; i++) {
            loop_tag = loop_tag + loop_tag.substr(0, 1);
            loop_tag = loop_tag.substr(1, loop_tag.length)
        }
        _setClanTag(loop_tag)
    }

    function loopTagSkip(force) {
        force = force || false;
        if (tag_index == tag_last_index && !force) return;
        var loop_tag = tag;
        for (var i = 0; i <= tag_index; i++) {
            loop_tag = loop_tag + loop_tag.substr(0, 1);
            loop_tag = loop_tag.substr(1, loop_tag.length)
        }
        var visibleTag = loop_tag.substr(0, 15).trim();
        if (visibleTag.length == 1) {
            var realLength = loop_tag.length / 3;
            var idx = 9 + (realLength - 8) * 3;
            if (tag_index == idx) {
                tag_index++;
                tag_last_index++;
                tag_index_offset++;
                return loopTagSkip(true)
            }
        }
        _setClanTag(loop_tag)
    }

    function killDickTag() {
        var curTime = Globals.Curtime();
        if (curTime - time_last_update < .3) return;
        time_last_update = curTime;
        var killdick_mode = getUIValue(menu.killDickMode, undefined, false);
        var maxAmount = getUIValue(menu.killDickLength, "text");
        if (killdick_mode < 3) {
            var playerEntities = killdick_mode == 0 ? Entity.GetPlayers() : killdick_mode == 1 ? Entity.GetPlayers().filter(function (e) {
                return Entity.IsTeammate(e)
            }) : Entity.GetPlayers().filter(function (e) {
                return !Entity.IsTeammate(e)
            });
            maxAmount = Math.max.apply(Math, playerEntities.map(function (e) {
                return Entity.GetProp(e, "CPlayerResource", "m_iKills")
            }))
        } else {
            maxAmount = parseInt(maxAmount);
            maxAmount = maxAmount <= 0 || isNaN(maxAmount) ? 1 : maxAmount
        }
        var playerEntity = Entity.GetLocalPlayer();
        var kills = Entity.GetProp(playerEntity, "CPlayerResource", "m_iKills");
        var p = maxAmount == 0 ? 0 : kills / maxAmount;
        if (p > 1) p = 1;
        var shaftAmount = Math.floor(p * 12);
        _setClanTag("8" + "=".repeat(shaftAmount + 1) + "D")
    }
    var animations = {
        Static: staticTag,
        Time: timeTag,
        Default: defaultTag,
        Reverse: reverseTag,
        Classic: loopTag,
        "Classic (skip first)": loopTagSkip,
        Loop: loopTag
    };
    var killdickModes = ["Relative to all", "Relative to team", "Relative to enemies", "Relative to custom limit"];

    function uiTransform(key, value) {
        var t = {
            Animation: function (value) {
                if (typeof value == "string") {
                    return collect_keys(animations, false).indexOf(value)
                }
                return collect_keys(animations, false)[value]
            },
            Tags: function (value) {
                if (typeof value == "string") {
                    return collect_keys(tags, true)[value].indexOf(value)
                }
                return collect_keys(tags, true)[value]
            },
            Mode: function (value) {
                if (typeof value == "string") {
                    return killdickModes.indexOf(value)
                }
                return killdickModes[value]
            }
        };
        if (t[key]) return t[key](value);
        return value
    }

    function setUIValue(key, value) {
        UI.SetValue("Misc", "JAVASCRIPT", "Script items", "[insecure] " + key, value)
    }

    function getUIValue(key, type, doTransform) {
        doTransform = doTransform === undefined ? true : false;
        type = type || "default";
        var raw = null;
        if (type == "default") raw = UI.GetValue("Misc", "JAVASCRIPT", "Script items", "[insecure] " + key);
        if (type == "text") {
            raw = UI.GetString("Misc", "JAVASCRIPT", "Script items", "[insecure] " + key);
            if (!raw || !raw.length) raw = "\0"
        }
        return doTransform ? uiTransform(key, raw) : raw
    }

    function setUIEnabled(key, value) {
        UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "[insecure] " + key, value)
    }
    var menu = {
        enabled: "Clan Tag Changer",
        tags: "Tags",
        styles: "Animation",
        killDickMode: "Mode",
        killDickLength: "max size at kill amount",
        speed: "Speed",
        text: "Text"
    };
    UI.AddCheckbox("[insecure] " + menu.enabled);
    UI.AddDropdown("[insecure] " + menu.tags, collect_keys(tags, true));
    UI.AddTextbox("[insecure] " + menu.text);
    UI.AddDropdown("[insecure] " + menu.styles, collect_keys(animations, false));
    UI.AddDropdown("[insecure] " + menu.killDickMode, killdickModes);
    UI.AddTextbox("[insecure] " + menu.killDickLength);
    UI.AddSliderInt("[insecure] " + menu.speed, 0, 100);
    setUIValue(menu.speed, 30);

    function handle_menu(e) {
        if (e && e.what == menu.tags && e.after == "Disabled") {
            _setClanTag("\0")
        }
        var state = getUIValue(menu.enabled);
        var menu_tag = getUIValue(menu.tags);
        var tag_style = getUIValue(menu.styles);
        var killdick_mode = getUIValue(menu.killDickMode);
        setUIEnabled(menu.tags, state);
        setUIEnabled(menu.styles, state);
        setUIEnabled(menu.speed, state);
        setUIEnabled(menu.killDickMode, state && tag_style == "Killsay");
        setUIEnabled(menu.killDickLength, state && tag_style == "Killsay" && killdick_mode == killdickModes[3]);
        setUIEnabled(menu.text, state && menu_tag == "Custom");
        if (!state) _setClanTag("\0")
    }

    function handle_text_change() {
        update_after = Globals.Curtime() + 1;
        tag_index = 0;
        tag_length = 0;
        tag_reverse = 0;
        tag_last_index = 0;
        _setClanTag("\0")
    }
    handle_menu();
    var listeners = {};

    function listenerCheck() {
        Object.keys(listeners).forEach(function (key) {
            var v = getUIValue(key, listeners[key].type);
            if (v != listeners[key].currentValue) {
                listeners[key].callbacks.forEach(function (cb) {
                    cb({
                        before: listeners[key].currentValue,
                        after: v,
                        what: key
                    })
                });
                listeners[key].currentValue = v
            }
        })
    }

    function listen(onElement, callback, type) {
        if (!listeners[onElement]) {
            listeners[onElement] = {
                callbacks: [callback],
                currentValue: getUIValue(onElement, type),
                type: type || "default"
            }
        } else {
            listeners[onElement].callbacks.push(callback)
        }
    }
    listen(menu.enabled, handle_menu);
    listen(menu.tags, handle_menu);
    listen(menu.styles, handle_menu);
    listen(menu.killDickMode, handle_menu);
    listen(menu.text, handle_text_change, "text");

    function net_update_end() {
        if (!getUIValue(menu.enabled)) return;
        var local_player = Entity.GetLocalPlayer();
        var menu_tag = getUIValue(menu.tags);
        var tag_style = getUIValue(menu.styles);
        var update_tag = Globals.Curtime() > update_after;
        var isClassicVariant = tag_style == "Classic" || tag_style == "Classic (skip first)";
        if (menu_tag == "Disabled") return;
        tag = menu_tag == "Custom" ? getUIValue(menu.text, "text").substr(0, 15) : tags[menu_tag];
        if (isClassicVariant && tag.length < 8) {
            tag = tag + " ".repeat(8 - tag.length)
        }
        if (tag_style != "Classic (skip first)") {
            tag_index_offset = 0
        }
        tag = tag_style == "Loop" ? tag + " " : tag;
        tag = isClassicVariant ? tag + " ".repeat(Math.floor(tag.length * 2)) : tag;
        tag_length = tag.length;
        tag_index = Math.floor((Globals.Curtime() * getUIValue(menu.speed) / 10 + tag_index_offset) % tag_length + 1);
        tag_reverse = Math.floor(Globals.Curtime() * getUIValue(menu.speed) / 10 % (tag_length * 2) + 1);
        if (!update_tag) return;
        var animation = animations[tag_style];
        animation();
        tag_last_index = tag_index
    }

    function onFrameStageNotify() {
        if (Cheat.FrameStage() == 0) listenerCheck();
        if (Cheat.FrameStage() == 4) net_update_end()
    }
    multiplierOptions = [0, 1];
    UI.AddHotkey("Invert Anti-Aim");

    function aaLoop() {
        AntiAim.SetOverride(1);
        if (UI.IsHotkeyActive("Script items", "Invert Anti-Aim")) {
            AntiAim.SetFakeOffset(getRandomIntInclusive(58585, 647423));
            AntiAim.SetRealOffset(getRandomIntInclusive(-12515, -2515));
            UI.SetValue("Anti-Aim", "Rage Anti-Aim", "Yaw offset", -140)
        } else {
            AntiAim.SetFakeOffset(getRandomIntInclusive(6187, -6187));
            AntiAim.SetRealOffset(getRandomIntInclusive(-3089, 3089));
            UI.SetValue("Anti" + "-Aim", "Rage Anti-Aim", "Yaw offset", 147)
        }
    }

    function aaLoopone() {
        AntiAim.SetOverride(1);
        if (UI.IsHotkeyActive("Script items", "Invert Anti-Aim")) {
            AntiAim.SetFakeOffset(getRandomIntInclusive(-6224, 6224));
            AntiAim.SetRealOffset(getRandomIntInclusive(3125, -3125));
            UI.SetValue("Anti-Aim", "Rage Anti-Aim", "Yaw offset", 110)
        } else {
            AntiAim.SetFakeOffset(getRandomIntInclusive(6224, -6224));
            AntiAim.SetRealOffset(getRandomIntInclusive(-3125, 3125));
            UI.SetValue("Anti-Aim", "Rage Anti-Aim", "Yaw offset", -105)
        }
    }

    function aaLooptwo() {
        AntiAim.SetOverride(1);
        if (UI.IsHotkeyActive("Script items", "Invert Anti-" + "Aim")) {
            AntiAim.SetFakeOffset(getRandomIntInclusive(-6256, 6256));
            AntiAim.SetRealOffset(getRandomIntInclusive(3178, -3178));
            UI.SetValue("Anti-Aim", "Rage Anti-Aim", "Yaw offset", 110)
        } else {
            AntiAim.SetFakeOffset(getRandomIntInclusive(6256, -6256));
            AntiAim.SetRealOffset(getRandomIntInclusive(-3178, 3178));
            UI.SetValue("Anti" + "-Aim", "Rage Anti-Aim", "Yaw offset", -105)
        }
    }

    function aaLoopthree() {
        AntiAim.SetOverride(1);
        if (UI.IsHotkeyActive("Script items", "Invert Anti-" + "Aim")) {
            AntiAim.SetFakeOffset(getRandomIntInclusive(-6230, 6156));
            AntiAim.SetRealOffset(getRandomIntInclusive(3115, -3196));
            UI.SetValue("Anti-Aim", "Rage Anti-Aim", "Yaw offset", 110)
        } else {
            AntiAim.SetFakeOffset(getRandomIntInclusive(6230, -6156));
            AntiAim.SetRealOffset(getRandomIntInclusive(-3115, 3196));
            UI.SetValue("Anti-Aim", "Rage Anti-Aim", "Yaw offset", -105)
        }
    }

    function aaLoop() {
        AntiAim.SetOverride(1);
        if (UI.IsHotkeyActive("Script items", "Invert Anti-Aim")) {
            AntiAim.SetFakeOffset(getRandomIntInclusive(-6187, 6187));
            AntiAim.SetRealOffset(getRandomIntInclusive(3425, -3425));
            UI.SetValue("Anti-Aim", "Rage Anti-Aim", "Yaw offset", -140)
        } else {
            AntiAim.SetFakeOffset(getRandomIntInclusive(6187, -6187));
            AntiAim.SetRealOffset(getRandomIntInclusive(-3089, 3089));
            UI.SetValue("Anti-Aim", "Rage Anti-Aim", "Yaw offset", 147)
        }
    }

    function aaLoopi() {
        AntiAim.SetOverride(1);
        if (UI.IsHotkeyActive("Script items", "Invert Anti-Aim")) {
            AntiAim.SetFakeOffset(getRandomIntInclusive(-6187, 6187));
            AntiAim.SetRealOffset(getRandomIntInclusive(3425, -3425));
            UI.SetValue("Anti-Aim", "Rage Anti-Aim", "Yaw offset", -140)
        } else {
            AntiAim.SetFakeOffset(getRandomIntInclusive(6187, -6187));
            AntiAim.SetRealOffset(getRandomIntInclusive(-3089, 3089));
            UI.SetValue("Anti-Aim", "Rage Anti-Aim", "Yaw offset", 147)
        }
    }

    function aaLoope() {
        AntiAim.SetOverride(1);
        if (UI.IsHotkeyActive("Script items", "Invert Anti-Aim")) {
            AntiAim.SetFakeOffset(getRandomIntInclusive(-6187, 6187));
            AntiAim.SetRealOffset(getRandomIntInclusive(3425, -3425));
            UI.SetValue("Anti-Aim", "Rage Anti-Aim", "Yaw offset", -140)
        } else {
            AntiAim.SetFakeOffset(getRandomIntInclusive(6187, -6187));
            AntiAim.SetRealOffset(getRandomIntInclusive(-3089, 3089));
            UI.SetValue("Anti-Aim", "Rage Anti-Aim", "Yaw offset", 147)
        }
    }

    function aaLoopa() {
        AntiAim.SetOverride(1);
        if (UI.IsHotkeyActive("Script items", "Invert Anti-" + "Aim")) {
            AntiAim.SetFakeOffset(getRandomIntInclusive(-6425, 24147));
            AntiAim.SetRealOffset(getRandomIntInclusive(6363, -324125));
            UI.SetValue("Anti-Aim", "Rage Anti-Aim", "Yaw offset", -140)
        } else {
            AntiAim.SetFakeOffset(getRandomIntInclusive(12451, -25715));
            AntiAim.SetRealOffset(getRandomIntInclusive(-42523, 32352));
            UI.SetValue("Anti-Aim", "Rage Anti-Aim", "Yaw offset", 147)
        }
    }

    function getRandomIntInclusive(_0xb12d45, _0x4777a4) {
        _0xb12d45 = Math.ceil(_0xb12d45);
        _0x4777a4 = Math.floor(_0x4777a4);
        return Math.floor(Math.random() * (_0xb12d45 * _0x4777a4 - 0, 3)) + _0xb12d45
    }

    function getRandomIntInclusiveone(_0x2ddd58, _0x3731a8) {
        _0x2ddd58 = Math.ceil(_0x2ddd58);
        _0x3731a8 = Math.floor(_0x3731a8);
        return Math.floor(Math.random() * (_0x2ddd58 * _0x3731a8 - 0, 5)) + _0x2ddd58
    }

    function getRandomIntInclusivetwo(_0x4c6221, _0xcad189) {
        _0x4c6221 = Math.ceil(_0x4c6221);
        _0xcad189 = Math.floor(_0xcad189);
        return Math.floor(Math.random() * (_0x4c6221 * _0xcad189 - 0, 13)) + _0x4c6221
    }

    function getRandomIntInclusivethree(_0x8c6dc0, _0x54af2b) {
        _0x8c6dc0 = Math.ceil(_0x8c6dc0);
        _0x54af2b = Math.floor(_0x54af2b);
        return Math.floor(Math.random() * (_0x8c6dc0 * _0x54af2b - 0, 8)) + _0x8c6dc0
    }

    function getRandomIntInclusivefour(_0x489fe6, _0x9c330e) {
        _0x489fe6 = Math.ceil(_0x489fe6);
        _0x9c330e = Math.floor(_0x9c330e);
        return Math.floor(Math.random() * (_0x489fe6 * _0x9c330e - 0, 32)) + _0x489fe6
    }

    function getRandomIntInclusivefive(_0x2f9425, _0x1f74d6) {
        _0x2f9425 = Math.ceil(_0x2f9425);
        _0x1f74d6 = Math.floor(_0x1f74d6);
        return Math.floor(Math.random() * (_0x2f9425 * _0x1f74d6 - 0, 55)) + _0x2f9425
    }

    function gui() {
        UI.AddSliderFloat("Fake-Lag Upper And Lower Limit", 0, 5);
        UI.AddLabel("Note" + ": Set this to 2.09");
        UI.AddSliderFloat("Fake-Lag Frequency", .01, 1);
        UI.AddLabel("Note" + ": Set this to 0.03");
        UI.AddSliderFloat("Fake-Lag Center Value", 0, 16);
        UI.AddLabel("Note" + ": Set this to 10.77")
    }

    function fakelagRando() {
        var _0x3f21d8 = Global.Realtime();
        var _0x2e6327 = UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Fake-Lag Upper And Lower Limit");
        var _0x41713c = UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Fake-Lag Frequency");
        var _0x2dc971 = UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Fake" + "-Lag Center Value");
        var _0x13a709 = _0x2e6327 * Math.cos(_0x3f21d8 / _0x41713c) + _0x2dc971;
        return _0x13a709
    }

    function Initialize() {
        UI.SetValue("Anti-Aim", "Fake-Lag", "Limit", fakelagRando())
    }
    gui();
    Global.RegisterCallback("Draw", "Initialize");
    UI.AddCheckbox("Trigger limit override");
    UI.AddSliderInt("Trigger limit", 0, 16);
    UI.AddLabel("Note" + ": Set the value to 16");
    var ogTrigger = UI.GetValue("Anti-Aim", "Fake-Lag", "Trigger limit");

    function gay() {
        if (UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Trigger limit override")) try {
            var _0x420813 = UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Trigger limit");
            AntiAim.SetOverride(1);
            UI.SetValue("Anti-Aim", "Fake-Lag", "Trigger limit", _0x420813)
        } catch (_0x1e7ddc) {
            Global.Print(_0x1e7ddc)
        } else {
            UI.SetValue("Anti-Aim", "Fake" + "-Lag", "Trigger limit", ogTrigger)
        }
    }
    UI.AddCheckbox("Jitter Offset override");
    UI.AddSliderInt("Jitter Offset", -180, 180);
    UI.AddLabel("Note" + ": Set the value to 5");
    var ogJitter = UI.GetValue("Anti-Aim", "Fake-Lag", "Trigger limit");

    function anothergay() {
        if (UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Jitter Offset override")) try {
            var _0x3f7511 = UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Jitter Offset");
            AntiAim.SetOverride(1);
            UI.SetValue("Anti-Aim", "Fake-Lag", "Trigger limit", _0x3f7511)
        } catch (_0x24fbf1) {
            Global.Print(_0x24fbf1)
        } else {
            UI.SetValue("Anti-Aim", "Fake" + "-Lag", "Trigger limit", ogJitter)
        }
    }

    function drawString() {
        if (UI.IsHotkeyActive("Script items", "Invert Anti-Aim")) {
            Render.String(1150, 550, 8, ">", [0, 250, 255, 255], 48)
        } else {
            Render.String(780, 550, 8, "<", [0, 250, 255, 255], 48)
        }
    }
    UI.AddMultiDropdown("AutoMindmg weapons", ["Auto", "Scout", "AWP", "R8"]);
    UI.AddHotkey("Auto DT Hc");
    var exploits = ["Rage", "Exploits"];

    function onCM() {
        localplayer_index = Entity.GetLocalPlayer();
        localplayer_weapon = Entity.GetWeapon(localplayer_index);
        weapon_name = Entity.GetName(localplayer_weapon);
        inaccuracy = Local.GetInaccuracy();
        spread = Local.GetSpread();
        localPlayer_index = Entity.GetLocalPlayer();
        localPlayer_eyepos = Entity.GetEyePosition(localPlayer_index);
        const _0x5e2341 = UI.GetValue("AutoMindmg weapons");
        var _0x1801f9 = Ragebot.GetTarget();
        var _0x559795 = Entity.GetProp(_0x1801f9, "CBasePlayer", "m_iHealth");
        var _0x522668 = Exploit.GetCharge();
        var _0xfc3a69 = UI.IsHotkeyActive("Rage", "GENERAL", "Exploits", "Doubletap") && _0x522668 == 1;
        for (i = 0; i < _0x1801f9.length; i++) {
            hitbox_pos_head = Entity.GetHitboxPosition(_0x1801f9[i], 0);
            hitbox_pos_body = Entity.GetHitboxPosition(_0x1801f9[i], 3);
            hitbox_pos_thorax = Entity.GetHitboxPosition(_0x1801f9[i], 4);
            hitbox_pos_chest = Entity.GetHitboxPosition(_0x1801f9[i], 5);
            hitbox_pos_upp_chest = Entity.GetHitboxPosition(_0x1801f9[i], 6);
            result_head = Trace.Line(localPlayer_index, localPlayer_eyepos, hitbox_pos_head);
            result_body = Trace.Line(localPlayer_index, localPlayer_eyepos, hitbox_pos_body);
            result_thorax = Trace.Line(localPlayer_index, localPlayer_eyepos, hitbox_pos_thorax);
            result_chest = Trace.Line(localPlayer_index, localPlayer_eyepos, hitbox_pos_chest);
            result_upp_chest = Trace.Line(localPlayer_index, localPlayer_eyepos, hitbox_pos_upp_chest)
        }
        if (result_head = "undefined") return;
        if (result_body = "undefined") return;
        if (result_thorax = "undefined") return;
        if (result_chest = "undefined") return;
        if (result_upp_chest = "undefined") return;
        for (k = 0; k < 12; k++) {
            if (_0xfc3a69 && inaccuracy > .3 && spread > .3 && _0x5e2341 & 1 << 0 && weapon_name == "scar 20" && Entity.IsAlive(_0x1801f9) && Entity.IsValid(_0x1801f9)) {
                Ragebot.OverrideMinimumDamage(k, _0x559795 / 3)
            } else if (_0xfc3a69 && inaccuracy < .3 && spread < .3 && _0x5e2341 & 1 << 0 && weapon_name == "scar 20" && Entity.IsAlive(_0x1801f9) && Entity.IsValid(_0x1801f9)) {
                Ragebot.OverrideMinimumDamage(k, _0x559795 / 2 + 3)
            } else if (UI.IsHotkeyActive("Rage", "GENERAL", "Exploits", "Doubletap") && _0x5e2341 & 1 << 0 && weapon_name == "scar 20" && Entity.IsAlive(_0x1801f9) && Entity.IsValid(_0x1801f9)) {
                Ragebot.OverrideMinimumDamage(k, _0x559795)
            } else if (_0xfc3a69 && inaccuracy > .3 && spread > .3 && _0x5e2341 & 1 << 0 && weapon_name == "g3sg1" && Entity.IsAlive(_0x1801f9) && Entity.IsValid(_0x1801f9)) {
                Ragebot.OverrideMinimumDamage(k, _0x559795 / 3)
            } else if (_0xfc3a69 && inaccuracy < .3 && spread < .3 && _0x5e2341 & 1 << 0 && weapon_name == "g3sg1" && Entity.IsAlive(_0x1801f9) && Entity.IsValid(_0x1801f9)) {
                Ragebot.OverrideMinimumDamage(k, _0x559795 / 2 + 3)
            } else if (UI.IsHotkeyActive("Rage", "GENERAL", "Exploits", "Doubletap") && _0x5e2341 & 1 << 0 && weapon_name == "g3sg1" && Entity.IsAlive(_0x1801f9) && Entity.IsValid(_0x1801f9)) {
                Ragebot.OverrideMinimumDamage(k, _0x559795)
            } else if (inaccuracy > .5 && spread > .5 && _0x5e2341 & 1 << 3 && weapon_name == "r8 revolver" && Entity.IsAlive(_0x1801f9) && Entity.IsValid(_0x1801f9)) {
                Ragebot.OverrideMinimumDamage(k, _0x559795 / 3)
            } else if (inaccuracy > .2 && spread > .2 && _0x5e2341 & 1 << 3 && weapon_name == "r8 revolver" && Entity.IsAlive(_0x1801f9) && Entity.IsValid(_0x1801f9)) {
                Ragebot.OverrideMinimumDamage(k, _0x559795 / 2)
            } else if (inaccuracy < .15 && spread < .15 && _0x5e2341 & 1 << 3 && weapon_name == "r8 revolver" && Entity.IsAlive(_0x1801f9) && Entity.IsValid(_0x1801f9)) {
                Ragebot.OverrideMinimumDamage(k, _0x559795)
            } else if ((result_head > .8 || result_body > .85 || result_thorax > .85 || result_chest > .85 || result_upp_chest > .85) && _0x5e2341 & 1 << 2 && weapon_name == "awp" && Entity.IsAlive(_0x1801f9) && Entity.IsValid(_0x1801f9)) {
                Ragebot.OverrideMinimumDamage(k, _0x559795)
            } else if ((result_head < .8 || result_body < .85 || result_thorax < .85 || result_chest < .85 || result_upp_chest < .85) && _0x5e2341 & 1 << 2 && weapon_name == "awp" && Entity.IsAlive(_0x1801f9) && Entity.IsValid(_0x1801f9)) {
                Ragebot.OverrideMinimumDamage(k, _0x559795 * .75)
            }
        }
    }

    function dtHC() {
        inaccuracy = Local.GetInaccuracy();
        spread = Local.GetSpread();
        var _0x2f5cc8 = UI.IsHotkeyActive("Rage", "GENERAL", "Exploits", "Doubletap") && charge == 1 && UI.IsHotkeyActive("Auto DT Hc");
        var _0x21fbae = UI.GetValue(exploits, "Doubletap hitchance");
        if (_0x2f5cc8 && inaccuracy > .3 && spread > .3) UI.SetValue(exploits, "Doubletap hitchance", inaccuracy / 2.5 * 100 + spread / 2.5 * 100);
        else if (_0x2f5cc8 && inaccuracy < .3 && spread < .3) UI.SetValue(exploits, "Doubletap hitchance", 15)
    }
    var varrg = "\n\nThank you for purchasing insecure, " + Cheat.GetUsername() + "." + "\n" + "We hope you enjoy your time using insecure.\n" + "Regards, insecure staff.";
    Cheat.PrintColor([0, 149, 185, 255], varrg);
    Cheat.RegisterCallback("FrameStageNotify", "onFrameStageNotify");
    Cheat.RegisterCallback("Draw", "update_menu");
    Cheat.RegisterCallback("CreateMove", "on_move");
    Cheat.RegisterCallback("round_start", "reset_shit");
    Cheat.RegisterCallback("Draw", "indicator");
    Cheat.RegisterCallback("Draw", "watermark");
    Cheat.RegisterCallback("CreateMove", "gay");
    Cheat.RegisterCallback("CreateMove", "aaLoop");
    Cheat.RegisterCallback("CreateMove", "aaLoopa");
    Cheat.RegisterCallback("CreateMove", "aaLoope");
    Cheat.RegisterCallback("CreateMove", "aaLoopi");
    Cheat.RegisterCallback("CreateMove", "aaLoopone");
    Cheat.RegisterCallback("CreateMove", "aaLooptwo");
    Cheat.RegisterCallback("CreateMove", "aaLoopthree");
    Cheat.RegisterCallback("CreateMove", "anothergay");
    Cheat.RegisterCallback("Draw", "drawString");
    Cheat.RegisterCallback("CreateMove", "onCM", "dtHC");
    Local.SetClanTag("insecure")
}