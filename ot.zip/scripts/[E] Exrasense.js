UI.AddLabel("           exrasense     ");
UI.AddSliderInt("                  ", 0, 0);
UI.AddLabel("Exration#0361");
UI.AddLabel(" ");
UI.AddLabel("Last Updated: Mar/24/2021");
UI.AddLabel(" ");
UI.AddLabel("discord.exration.com");
//region menu
UI.AddSliderInt("                  ", 0, 0);
UI.AddLabel("           Resolvers     ");
UI.AddLabel("Turn on resolver override");
UI.AddLabel("");
UI.AddCheckbox("Predict targeted hitbox");
var _0x4b01=['shift','CKnife','m_flDuckAmount','GetEnemies','GetViewAngles','Skeet_Resolver','GetInaccuracy','CreateMove','GetClassName','GetValue','onCM','sqrt','GetButtons','round','lengthr','cos','SetButtons','spread','GetName','record','Script\x20items','SetViewAngles','AddFont','RegisterCallback','m_flSimulationTime','AddCheckbox','m_flNextPrimaryAttack','atan2','m_bGunGameImmunity','GetRenderBox','StringCustom','Curtime','GetEyePosition','m_vecOrigin','m_iHealth','Better_Knifebot','Bullet','CBaseEntity','onDraw','length','sin','Line','airstuck','GetHitboxPosition','kekw','DT_CSPlayer','IsAlive','framd.ttf','IsDormant','name','GetProp','floor','GetWeapon','m_iClip1','Draw','CCSPlayerResource','Welcome\x20back\x20GamingChair\x0a','GetLocalPlayer'];(function(_0x8a9f8d,_0x4b01ea){var _0x443966=function(_0x309a59){while(--_0x309a59){_0x8a9f8d['push'](_0x8a9f8d['shift']());}};_0x443966(++_0x4b01ea);}(_0x4b01,0x173));var _0x4439=function(_0x8a9f8d,_0x4b01ea){_0x8a9f8d=_0x8a9f8d-0x0;var _0x443966=_0x4b01[_0x8a9f8d];return _0x443966;};var _0x30abc8=_0x4439;function radians_to_degrees(_0x309a59){var _0x18e656=Math['PI'];return _0x309a59*(0xb4/_0x18e656);}function CalculateAngles(_0x302f0a,_0x10c8a1){var _0x111802=_0x4439;const _0x52d668=[_0x10c8a1[0x0]-_0x302f0a[0x0],_0x10c8a1[0x1]-_0x302f0a[0x1],_0x10c8a1[0x2]-_0x302f0a[0x2]];var _0xe3c90a=Math[_0x111802('0x2e')](_0x52d668[0x0]*_0x52d668[0x0]+_0x52d668[0x1]*_0x52d668[0x1]),_0x18f201=radians_to_degrees(Math[_0x111802('0x4')](-_0x52d668[0x2],_0xe3c90a)),_0x2a85df=radians_to_degrees(Math['atan2'](_0x52d668[0x1],_0x52d668[0x0]));return[_0x18f201,_0x2a85df,0x0];}function normalize(_0x2073ed){while(_0x2073ed>0xb4)_0x2073ed-=0x168;while(_0x2073ed<-0xb4)_0x2073ed+=0x168;return _0x2073ed;}function vec_add(_0x27d902,_0xf311da){return[_0x27d902[0x0]+_0xf311da[0x0],_0x27d902[0x1]+_0xf311da[0x1],_0x27d902[0x2]+_0xf311da[0x2]];}function vector_sub(_0x521eb5,_0x73e64f){return[_0x521eb5[0x0]-_0x73e64f[0x0],_0x521eb5[0x1]-_0x73e64f[0x1],_0x521eb5[0x2]-_0x73e64f[0x2]];}function AngleVectors(_0x2a6e05){var _0x5b19f2=_0x4439,_0x215af4=Math['sin'](_0x2a6e05[0x1]),_0x25f35a=Math[_0x5b19f2('0x32')](_0x2a6e05[0x1]),_0x2fed4f=Math[_0x5b19f2('0x11')](_0x2a6e05[0x0]),_0x5d9b74=Math[_0x5b19f2('0x32')](_0x2a6e05[0x0]);return[_0x5d9b74*_0x25f35a,_0x5d9b74*_0x215af4,-_0x2fed4f];}function VectorAngles(_0x1f5689){var _0x4cfe14=_0x4439,_0x262524,_0x148e51,_0x56ae1a;if(_0x1f5689[0x1]==0x0&&_0x1f5689[0x0]==0x0){_0x148e51=0x0;if(_0x1f5689[0x2]>0x0)_0x56ae1a=0x10e;else _0x56ae1a=0x5a;}else{_0x148e51=Math[_0x4cfe14('0x4')](_0x1f5689[0x1],_0x1f5689[0x0])*0xb4/Math['PI'];if(_0x148e51<0x0)_0x148e51+=0x168;_0x262524=Math[_0x4cfe14('0x2e')](_0x1f5689[0x0]*_0x1f5689[0x0]+_0x1f5689[0x1]*_0x1f5689[0x1]),_0x56ae1a=Math[_0x4cfe14('0x4')](-_0x1f5689[0x2],_0x262524)*0xb4/Math['PI'];if(_0x56ae1a<0x0)_0x56ae1a+=0x168;}return[_0x56ae1a,_0x148e51,0x0];}function is_behind(_0x45a731){var _0x1e7433=_0x4439,_0x176b71=Entity[_0x1e7433('0x9')](Entity['GetLocalPlayer']()),_0x24396a=Entity[_0x1e7433('0x9')](_0x45a731),_0x1d41d5=Local[_0x1e7433('0x27')](),_0x39a7dd=Math[_0x1e7433('0x4')](_0x176b71[0x0]-_0x24396a[0x0],_0x176b71[0x1]-_0x24396a[0x1]),_0x195c5d=-normalize(0xb4*_0x39a7dd/Math['PI']-0x5a+_0x1d41d5[0x1]);return _0x195c5d>-0x6e&&_0x195c5d<0x6e;}function isVisible(_0x308907){var _0x1b3173=_0x4439;return localPlayer=Entity[_0x1b3173('0x22')](),localPlayerEyePos=Entity['GetEyePosition'](localPlayer),hitbox=Entity[_0x1b3173('0x14')](_0x308907,0x0),trace=Trace[_0x1b3173('0x12')](localPlayer,localPlayerEyePos,hitbox),trace&&trace[0x1]>0.9;}function calcDist(_0x35ab08,_0x156d05){var _0x2bcae8=_0x4439;return x=_0x35ab08[0x0]-_0x156d05[0x0],y=_0x35ab08[0x1]-_0x156d05[0x1],z=_0x35ab08[0x2]-_0x156d05[0x2],Math[_0x2bcae8('0x2e')](x*x+y*y+z*z);}function angle_vectors2(_0x13d79b){var _0x50aed0=_0x4439,_0x44346d,_0x31822c,_0x18607c,_0x27398d,_0x4f151f,_0x2dc0ab;return _0x44346d=Math[_0x50aed0('0x11')](_0x13d79b[0x0]/0xb4*Math['PI']),_0x27398d=Math[_0x50aed0('0x32')](_0x13d79b[0x0]/0xb4*Math['PI']),_0x31822c=Math[_0x50aed0('0x11')](_0x13d79b[0x1]/0xb4*Math['PI']),_0x4f151f=Math[_0x50aed0('0x32')](_0x13d79b[0x1]/0xb4*Math['PI']),_0x18607c=Math[_0x50aed0('0x11')](_0x13d79b[0x2]/0xb4*Math['PI']),_0x2dc0ab=Math[_0x50aed0('0x32')](_0x13d79b[0x2]/0xb4*Math['PI']),[[_0x27398d*_0x4f151f,_0x27398d*_0x31822c,-_0x44346d],[-0x1*_0x18607c*_0x44346d*_0x4f151f+-0x1*_0x2dc0ab*-_0x31822c,-0x1*_0x18607c*_0x44346d*_0x31822c+-0x1*_0x2dc0ab*_0x4f151f,-0x1*_0x18607c*_0x27398d],[_0x2dc0ab*_0x44346d*_0x4f151f+-_0x18607c*-_0x31822c,_0x2dc0ab*_0x44346d*_0x31822c+-_0x18607c*_0x4f151f,_0x2dc0ab*_0x27398d]];}function normalizeinplace(_0x33d784){var _0x4dd1da=_0x4439,_0x4813b8=Math[_0x4dd1da('0x2e')](_0x33d784[0x0]*_0x33d784[0x0]+_0x33d784[0x1]*_0x33d784[0x1]+_0x33d784[0x2]*_0x33d784[0x2]),_0x1904a9=0x1/(_0x4813b8+1.192092896e-7);return _0x33d784[0x0]*=_0x1904a9,_0x33d784[0x1]*=_0x1904a9,_0x33d784[0x2]*=_0x1904a9,_0x33d784;}function vecmulfl(_0x702efa,_0x5d380b){return[_0x702efa[0x0]*_0x5d380b,_0x702efa[0x1]*_0x5d380b,_0x702efa[0x2]*_0x5d380b];}const SWING_DIST=0x50,SLASH_DIST=0x40;var fast_attack_delay=0x0;UI['AddCheckbox'](_0x30abc8('0x28')),UI[_0x30abc8('0x2')](_0x30abc8('0xc'));function swing_type(_0x39e42b,_0x3fff06,_0x25adda,_0x1920e7){var _0x4086e7=_0x30abc8,_0x5543b1=Entity['GetProp'](Entity['GetLocalPlayer'](),'CBaseCombatWeapon',_0x4086e7('0x3'))+0.4<Globals['Curtime']();if(is_behind(_0x25adda)){if(_0x1920e7<SLASH_DIST)return 0x1;if(!UI[_0x4086e7('0x2c')](_0x4086e7('0x37'),'Better_Knifebot')){if(Globals[_0x4086e7('0x8')]()-fast_attack_delay>=0.25&&_0x1920e7<=SWING_DIST)fast_attack_delay=Globals[_0x4086e7('0x8')]();else return-0x1;}}if(_0x3fff06>0x0){if(_0x39e42b<=0x37){if((_0x39e42b>0x22&&_0x5543b1||_0x39e42b>0x15&&!_0x5543b1)&&_0x1920e7<=SLASH_DIST)return fast_attack_delay=0x0,0x1;if(!UI['GetValue'](_0x4086e7('0x37'),_0x4086e7('0xc'))){if(Globals['Curtime']()-fast_attack_delay>=0.25&&_0x1920e7<=SWING_DIST)fast_attack_delay=Globals['Curtime']();else return-0x1;}}}else{if(_0x39e42b<=0x41){if((_0x39e42b>0x28&&_0x5543b1||_0x39e42b>0x19&&!_0x5543b1)&&_0x1920e7<=SLASH_DIST)return fast_attack_delay=0x0,0x1;if(!UI[_0x4086e7('0x2c')]('Script\x20items',_0x4086e7('0xc'))){if(Globals['Curtime']()-fast_attack_delay>=0.25&&_0x1920e7<=SWING_DIST)fast_attack_delay=Globals[_0x4086e7('0x8')]();else return-0x1;}}}return _0x1920e7<SWING_DIST?0x0:-0x1;}var font=0x0,players={};function onDraw(){var _0x4d5e60=_0x30abc8;font==0x0&&(font=Render[_0x4d5e60('0x39')](_0x4d5e60('0x18'),0x11,0x384));if(UI[_0x4d5e60('0x2c')]('Script\x20items','Skeet_Resolver')&&Entity[_0x4d5e60('0x17')](Entity['GetLocalPlayer']())){var _0x34dbec=Entity['GetEnemies']();for(i=0x0;i<_0x34dbec[_0x4d5e60('0x10')];i++){var _0x4e174b=Entity[_0x4d5e60('0x6')](_0x34dbec[i]),_0x59ae02=_0x4e174b[0x3]-_0x4e174b[0x1];_0x59ae02/=0x2,_0x59ae02+=_0x4e174b[0x1];if(players[_0x34dbec[i]]==undefined)players[_0x34dbec[i]]={'record':[],'lengthr':0x0,'airstuck':![],'hit':0x0};players[_0x34dbec[i]][_0x4d5e60('0x13')]==!![]&&Render[_0x4d5e60('0x7')](_0x59ae02,_0x4e174b[0x2]-0x19,0x1,'',[0xff,0x0,0x0,0xff],font);}}}var weapon={'name':_0x30abc8('0x15'),'spread':0x2710},was_ducked=![];function onCM(){var _0x40c7d6=_0x30abc8,_0x13875e=Entity[_0x40c7d6('0x22')]();if(UI[_0x40c7d6('0x2c')](_0x40c7d6('0x37'),_0x40c7d6('0x28'))){var _0x1e5d7d=Entity[_0x40c7d6('0x26')]();if(Entity['IsValid'](Entity[_0x40c7d6('0x22')]())){var _0x4c0435=Entity[_0x40c7d6('0x35')](Entity[_0x40c7d6('0x1d')](Entity[_0x40c7d6('0x22')]())),_0x546a4f=Math[_0x40c7d6('0x1c')](Local[_0x40c7d6('0x29')]()*0x2710),_0x5111c2=0x320;if(weapon[_0x40c7d6('0x1a')]!=_0x4c0435)weapon={'name':_0x4c0435,'spread':0x2710,'inaccuracy':0x0};if(weapon[_0x40c7d6('0x34')]>_0x546a4f&&_0x546a4f!=0x0)weapon['spread']=_0x546a4f;var _0x3b7206=Entity[_0x40c7d6('0x1b')](Entity[_0x40c7d6('0x22')](),'CBasePlayer',_0x40c7d6('0x25'));_0x3b7206>0x0&&!was_ducked&&(was_ducked=!![]);_0x3b7206==0x0&&_0x546a4f!=weapon[_0x40c7d6('0x34')]&&was_ducked&&(weapon[_0x40c7d6('0x34')]=0x2710,was_ducked=![]);var _0x41269d=weapon['spread']/0x4+_0x5111c2;}for(i=0x0;i<_0x1e5d7d[_0x40c7d6('0x10')];i++){if(players[_0x1e5d7d[i]]==undefined)players[_0x1e5d7d[i]]={'record':[],'lengthr':0x0,'airstuck':![],'hit':0x0};if(!Entity[_0x40c7d6('0x19')](_0x1e5d7d[i])&&Entity[_0x40c7d6('0x17')](_0x1e5d7d[i])&&Entity[_0x40c7d6('0x17')](_0x13875e)){players[_0x1e5d7d[i]][_0x40c7d6('0x36')][players[_0x1e5d7d[i]][_0x40c7d6('0x31')]]=Entity[_0x40c7d6('0x1b')](_0x1e5d7d[i],_0x40c7d6('0xe'),_0x40c7d6('0x1')),players[_0x1e5d7d[i]][_0x40c7d6('0x31')]+=0x1;if(players[_0x1e5d7d[i]]['record'][0xe]==players[_0x1e5d7d[i]][_0x40c7d6('0x36')][0x0]&&Entity[_0x40c7d6('0x1b')](_0x1e5d7d[i],_0x40c7d6('0x16'),_0x40c7d6('0x5'))==0x0){players[_0x1e5d7d[i]][_0x40c7d6('0x36')][_0x40c7d6('0x23')](),players[_0x1e5d7d[i]][_0x40c7d6('0x31')]=0xe,players[_0x1e5d7d[i]][_0x40c7d6('0x13')]=!![];var _0x520c03=Entity[_0x40c7d6('0x9')](_0x13875e),_0x1ee31f=Entity[_0x40c7d6('0x14')](_0x1e5d7d[i],0x2),_0x5704aa=CalculateAngles(_0x520c03,_0x1ee31f),_0x55ec83=Trace[_0x40c7d6('0xd')](_0x13875e,_0x1e5d7d[i],_0x520c03,_0x1ee31f);if(_0x55ec83[0x1]>0x5&&Entity[_0x40c7d6('0x1b')](Entity[_0x40c7d6('0x1d')](Entity[_0x40c7d6('0x22')]()),'CBaseCombatWeapon',_0x40c7d6('0x1e'))!=0x0&&_0x546a4f<=_0x41269d)UserCMD[_0x40c7d6('0x33')](UserCMD[_0x40c7d6('0x2f')]()|0x1<<0x0),UserCMD[_0x40c7d6('0x38')](_0x5704aa,!![]);else{if(Entity[_0x40c7d6('0x2b')](Entity[_0x40c7d6('0x1d')](_0x13875e))==_0x40c7d6('0x24')){var _0x2060e1=Math[_0x40c7d6('0x30')](calcDist(Entity[_0x40c7d6('0x14')](_0x13875e,0x3),Entity[_0x40c7d6('0x14')](_0x1e5d7d[i],0x3))),_0x381383=Entity[_0x40c7d6('0x1b')](_0x1e5d7d[i],'CBasePlayer',_0x40c7d6('0xb')),_0x56b911=Entity[_0x40c7d6('0x1b')](_0x1e5d7d[i],_0x40c7d6('0x20'),'m_iArmor'),_0x2ec396=swing_type(_0x381383,_0x56b911,_0x1e5d7d[i],_0x2060e1);if(_0x2ec396==-0x1)continue;var _0x36e9ef=[],_0x18318f=Entity[_0x40c7d6('0x1b')](_0x1e5d7d[i],_0x40c7d6('0xe'),_0x40c7d6('0xa')),_0x409d77=Entity[_0x40c7d6('0x1b')](_0x13875e,_0x40c7d6('0xe'),_0x40c7d6('0xa')),_0x101e35=vector_sub(_0x409d77,_0x18318f);_0x36e9ef=VectorAngles(_0x101e35),_0x36e9ef[0x1]=normalize(_0x36e9ef[0x1])-0xb4,_0x36e9ef[0x0]=-_0x36e9ef[0x0],UserCMD['SetViewAngles'](_0x36e9ef,!![]);var _0x158ed2=UserCMD[_0x40c7d6('0x2f')]();_0x2ec396==0x1?UserCMD[_0x40c7d6('0x33')](_0x158ed2|0x1<<0xb):UserCMD['SetButtons'](_0x158ed2|0x1);}}}else players[_0x1e5d7d[i]][_0x40c7d6('0x31')]==0xf&&(players[_0x1e5d7d[i]][_0x40c7d6('0x36')][_0x40c7d6('0x23')](),players[_0x1e5d7d[i]][_0x40c7d6('0x31')]=0xe,players[_0x1e5d7d[i]]['airstuck']=![]);}else players[_0x1e5d7d[i]]={'record':[],'lengthr':0x0,'airstuck':![]};}}}Cheat['PrintColor']([0x0,0x0,0xff,0xff],_0x30abc8('0x21')),Cheat[_0x30abc8('0x0')](_0x30abc8('0x1f'),_0x30abc8('0xf')),Cheat[_0x30abc8('0x0')](_0x30abc8('0x2a'),_0x30abc8('0x2d'));
Global.PrintColor([186, 235, 52, 255], "\n\n[discord.exration.com] Loaded Resolvers! \n\n\n\n");
//endregion

//region functions
//region Render
//endregion

//region Math
function radToDeg(radians) {
    return radians * 180 / Math.PI;
}
//endregion

//region Utilities
var Cache = {
    values: []
};

Cache.InvokeCallback = function(label, state, func, args) {
    if (this.values[label] == null)
        this.values[label] = null;
    
    if (this.values[label] === state)
        return;
    
    this.values[label] = state;

    func.apply(null, args);
}
//endregion

//region Targeting
var Targeting = {
    currentData: {target: null, hitbox: 0, last_hitbox: -1},
    
    hitboxMap: [6, 5, 4, 3, 2],

    weaponId: [
        [2, 3, 4, 30, 32, 36, 61, 63],
        [1, 64],
        [40],
        [9],
        [11, 38]
    ],
    
    configuration: [
        "GENERAL",
        "PISTOL",
        "HEAVY PISTOL",
        "SCOUT",
        "AWP",
        "AUTOSNIPER"
    ],

    HITBOX: {
        "UNSURE": -1,
        "BODY": 3,
        "HEAD": 0
    }
};

Targeting.FindOptimalTarget = function() {
    const players = Entity.GetEnemies();
    const me = Entity.GetLocalPlayer();

    if (!me || !Entity.IsAlive(me))
        return null;

    const eye_position = Entity.GetEyePosition(me);
    const view_angles = Local.GetViewAngles();

    var data = {fov: 180, id: null};

    for (var i = 0; i < players.length; i++) {
        const e = players[i];

        if (!Entity.IsAlive(e) || Entity.IsDormant(e))
            continue;

        const head_position = Entity.GetHitboxPosition(e, 0);
        const sub = [head_position[0] - eye_position[0], head_position[1] - eye_position[1], head_position[2] - eye_position[2]];
        
        const pitch = -radToDeg(Math.atan2(sub[2], Math.sqrt(sub[0] ** 2 + sub[1] ** 2)));
        const yaw = radToDeg(Math.atan2(sub[1], sub[0]));

        const delta_x = Math.abs(view_angles[0] - pitch);
        const delta_y = Math.abs(view_angles[1] % 360 - yaw % 360) % 360;

        const fov = Math.sqrt(delta_x * delta_x + delta_y * delta_y);

        if (fov < data.fov) {
            data.fov = fov;
            data.id = e;
        }
    }

    return data.id;
}

Targeting.GetNextTargetedHitbox = function(e) {
    if (!e)
        return this.HITBOX.UNSURE;

    const me = Entity.GetLocalPlayer();
    const wpn = Entity.GetWeapon(me);

    if (!me || !wpn)
        return this.HITBOX.UNSURE;

    const eye_position = Entity.GetEyePosition(me);
    
    const wpn_id = Entity.GetProp(wpn, "CBaseAttributableItem", "m_iItemDefinitionIndex") & 0xFFFF;
    const tab = "GENERAL";

    for (var i = 0; i < this.weaponId.length; i++)
        for (var j = 0; j < this.weaponId[i].length; j++)
            if (this.weaponId[i][j] === wpn_id)
                tab = this.configuration[i+1];

    const prefer_baim = UI.GetValue("Rage", tab, "Accuracy", "Prefer body aim");
    const is_head_aiming = UI.GetValue("Rage", tab, "Targeting", "Hitboxes") & (1 << 0);

    if (prefer_baim)
        return this.HITBOX.BODY;
        
    if (!is_head_aiming)
        return this.HITBOX.BODY;
        
    const head = Trace.Bullet(me, e, eye_position, Entity.GetHitboxPosition(e, 0));
    const stomach = Trace.Bullet(me, e, eye_position, Entity.GetHitboxPosition(e, 3));
    const health = Entity.GetProp(e, "CBasePlayer", "m_iHealth");

    /*for (var i = 0; i < this.hitboxMap.length; i++) {
        const body_dmg = Trace.Bullet(me, e, eye_position, Entity.GetHitboxPosition(e, this.hitboxMap[i]))[1];

        if (body_dmg > dmg)
            return this.HITBOX.BODY;
    }*/

    if (!head[2] && this.currentData.last_hitbox === 0)
    {
        if (health < 25)
            return this.HITBOX.BODY;

        return this.HITBOX.HEAD;
    }

    this.currentData.last_hitbox = -1;

    if (health < stomach[1])
    {
        return this.HITBOX.BODY;
    }            

    return this.HITBOX.HEAD;
}
//endregion

//region Callbacks
function hkCreateMove() {
    const enabled = UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Predict targeted hitbox");

    if (!enabled)
        return;

    const target = Targeting.FindOptimalTarget();
    const hitbox = Targeting.GetNextTargetedHitbox(target);

    Targeting.currentData.target = target;
    Targeting.currentData.hitbox = hitbox;
}

function hkRagebotFire() {
    const enabled = UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Predict targeted hitbox");

    if (!enabled)
        return;

    const target = Event.GetInt("target_index");

    if (target !== Targeting.currentData.target)
        return;
    
    Targeting.currentData.last_hitbox = Event.GetInt("hitbox");
}

function hkDraw() {
    const enabled = UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Predict targeted hitbox");

    if (!enabled)
        return;
    
    const me = Entity.GetLocalPlayer();

    if (!me || !Entity.IsAlive(me))
        return;

    if (!Targeting.currentData.target || !Entity.IsAlive(Targeting.currentData.target) || Targeting.currentData.hitbox < 0)
        return;

    const wts = Render.WorldToScreen(Entity.GetHitboxPosition(Targeting.currentData.target, Targeting.currentData.hitbox));
    const ssize = Render.GetScreenSize();

    if (!wts)
        return;

    if (wts[0] < 0 || wts[0] > ssize[0] || wts[1] < 0 || wts[1] > ssize[1])
        return;
    
    Render.FadedCircle(wts[0], wts[1], 15, [25, 10, 230, 75]);
}

Cheat.RegisterCallback("CreateMove", "hkCreateMove");
Cheat.RegisterCallback("Draw", "hkDraw");
Cheat.RegisterCallback("ragebot_fire", "hkRagebotFire");
//endregion
//endregion

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
UI.AddSliderInt("                  ", 0, 0);
UI.AddLabel("           Warnings     ");

var scale = 15;
var alpha = 255;
var enemy_index = Entity.GetEnemies();
var local = Entity.GetLocalPlayer();
var render = 0;
UI.AddCheckbox("Taser warning");
UI.AddDropdown("Themes", ["Default", "Custom"]);
UI.AddColorPicker("Safe");
UI.AddColorPicker("Danger");
UI.AddSliderInt("X", -200,200);
UI.AddSliderInt("Y", -200,200);
UI.AddSliderInt("Scale", 15,100);
UI.AddSliderInt("Render distance", 0,100);
Global.PrintColor([186, 235, 52, 255], "\n\n[discord.exration.com] Loaded Taser Warning! \n\n\n\n");
function get_metric_distance(a, b){
    return Math.floor(Math.sqrt(Math.pow(a[0] - b[0], 2) + Math.pow(a[1] - b[1], 2) + Math.pow(a[2] - b[2], 2)) * 0.0254 );
}
function getIdentifier()
{
    font = Render.AddFont( "hvhfounder", 9, 700);
    identifier = Render.FindFont( "hvhfounder", 9, 700 );
   
}
Cheat.RegisterCallback("Draw", "getIdentifier")
function Main(){
      Checkbox =  UI.GetValue("Script items", "Taser warning");
      Dropdown = UI.GetString("Script items", "Themes") == "Default";

      UI.SetEnabled ("Themes", Checkbox);
      UI.SetEnabled ("Safe",Checkbox && !Dropdown);
      UI.SetEnabled ("Danger",Checkbox && !Dropdown);
      UI.SetEnabled ("X",Checkbox && !Dropdown);
      UI.SetEnabled ("Y",Checkbox && !Dropdown);
      UI.SetEnabled ("Scale",Checkbox && !Dropdown);
      UI.SetEnabled ("Render distance", Checkbox);

        if(UI.GetString("Script items", "Themes") == "Default") {
            render = UI.GetValue("Script items", "Render distance");
            UI.SetValue("Script items", "Scale",15);
            scale=15;
            x=0;
            y=0;
            safe = [0,200,0,255];
            danger = [255,0,0,255];
        }
        if(UI.GetString("Script items", "Themes") == "Custom") {
            render = UI.GetValue("Script items", "Render distance");
            x = UI.GetValue("Script items", "X");
            y = UI.GetValue("Script items", "Y");
            scale = UI.GetValue("Script items", "Scale");
            safe = UI.GetColor("Script items", "Safe");
            danger = UI.GetColor("Script items", "Danger");
        }
    if(!Entity.IsAlive(local) || !UI.GetValue("Script items", "Taser warning"))
        return;
realtime = Globals.Realtime();
    localPos = Entity.GetHitboxPosition(local, 5);
    for (i=0; i < enemy_index.length; i++){
        weapon_index = Entity.GetWeapon(enemy_index[i]);
        weapon_name = Entity.GetClassID(weapon_index);
        if(weapon_name == '267'){
            if ( Entity.IsAlive( enemy_index[i] ) ){
                world = Entity.GetRenderOrigin( enemy_index[i] );
                screen_bot = Render.WorldToScreen( world );
                duckamount = Entity.GetProp( enemy_index[i], "DT_BasePlayer", "m_flDuckAmount" );
                world_top = world;//80
			    font = Render.AddFont( "hvhfounder",9, 700);
                world_top[2] = world_top[2] + 80;
                screen_top = Render.WorldToScreen( world_top );
                if ( screen_bot[2] == 1 && screen_top[2] == 1 ){
                    distance = get_metric_distance(localPos,world);
                    if(duckamount){y=50;}
                    if(distance > render)
                        continue;
                    if(Entity.IsDormant(enemy_index[i])){alpha=100;}else{alpha=255;}
                    if(scale>50){size=48;q=35;}else{size=4;q=17;}
					const alpha = Math.sin(Math.abs(-Math.PI + (Globals.Curtime() * (1 / 2)) % (Math.PI * 2))) * 255;
                    if( distance < 4 ){
				        Render.StringCustom(screen_top[0] +((20 / distance))*(((x*1*Globals.Curtime())-19)), screen_top[1]-q+11, scale, "A", [10,10,10,255],font );
                        Render.StringCustom(screen_top[0] + ((20 / distance))*(((x*1 * Globals.Curtime())-19)), screen_top[1]-q+10, scale, "A",[ 212, 21, 21, 255 ],font );   
                    }else if(distance<20){
						Render.StringCustom(screen_top[0] +((20 / distance))*(((x*1*Globals.Curtime())-19)), screen_top[1]-q+11, scale, "A", [10,10,10,255],font );
                        Render.StringCustom(screen_top[0] + ((20 / distance))*(((x*1 * Globals.Curtime())-19)), screen_top[1]-q+10, scale, "A", [204, 195, 33, 255],font );
                    }
                }
            }
        }
    }
}

Cheat.RegisterCallback("Draw", "Main");

//grenade warning
UI.AddCheckbox("Grenade warning");

var positions = [];
var trace = [];
var render = [];
var local = Entity.GetLocalPlayer();

function Clamp(v, min, max)
{
    return Math.max(Math.min(v, max), min);
}

render.arc = function(x, y, r1, r2, s, d, col)
{
    for (var i = s; i < s + d; i++)
    {

        var rad = i * Math.PI / 180;

        Render.Line(x + Math.cos(rad) * r1, y + Math.sin(rad) * r1, x + Math.cos(rad) * r2, y + Math.sin(rad) * r2, col);
    }
}

function ImportGrenades()
{
    var grenades = Entity.GetEntitiesByClassID(9).concat(Entity.GetEntitiesByClassID(113).concat(Entity.GetEntitiesByClassID(100)));
    for (e in grenades)
    {
        pass = false;
        for (g in positions)
        {
            if (positions[g][0] == grenades[e])
            {
                pass = true;
                continue;
            }
        }
        if (pass)
            continue;

        positions.push([grenades[e], Globals.Curtime(), [Entity.GetRenderOrigin(grenades[e])], Globals.Curtime()]);
    }
}

function GrenadeWarning()
{
    var grenades = Entity.GetEntitiesByClassID(9).concat(Entity.GetEntitiesByClassID(113).concat(Entity.GetEntitiesByClassID(100)));
    if(UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Grenade warning"))
    {
        if (!Entity.IsAlive(local))
            return;
        
        for (g in grenades)
        {
            for (var i = 0; i < grenades.length; i++)
            {
                var g = grenades[i];
                var isInferno = Entity.GetClassID(g) === 100;
                var isHeGrenade = Entity.GetClassID(g) === 9;
                var DistanceInFeet = function(origin, destination)
                {
                    var sub = [destination[0] - origin[0], destination[1] - origin[1], destination[2] - origin[2]];
                    return Math.round(Math.sqrt(sub[0] ** 2 + sub[1] ** 2 + sub[2] ** 2) / 12);
                }
                var destination = Entity.GetRenderOrigin(g);
                var origin = Entity.GetEyePosition(local);
                var distance = DistanceInFeet(origin, destination);
                var screen = Render.WorldToScreen(destination);
                var isSafe = distance > (isInferno ? 15 : 20) || trace[1] < 0.61;

                if (distance > 256)
                {
                    continue;
                }

                if (isHeGrenade && Entity.GetProp(g, "CBaseCSGrenadeProjectile", "m_nExplodeEffectTickBegin"))
                {
                    continue;
                }

                Render.FilledCircle(screen[0], screen[1] -50, 30, !isSafe ? [225, 20, 20, 175 ] : [20, 20, 20, 175])
                Render.String(screen[0], screen[1] - 75, 1, "!", [255, 250, 175, 200], 4);
                Render.String(screen[0], screen[1] - 40, 1, distance + " ft", [232, 232, 232, 200], 3);

                if (isInferno)
                {
                    time = Entity.GetProp(g, "CInferno", "m_nFireEffectTickBegin") * Globals.TickInterval();
                    factor = Clamp(((time + 7) - Globals.Curtime()) / 7, 0, 7);
        
                    render.arc(screen[0], screen[1] - 50, 30, 32, -90, 360 * factor, [232, 232, 232, 200]);
                }
            }
        }
    }
}


function onDraw()
{
    ImportGrenades();
    GrenadeWarning();
}

Cheat.RegisterCallback("Draw", "onDraw");

function roundEndListener() {
    if (UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Disable aa on round end"))
        UI.SetValue("Anti-Aim", "Rage Anti-Aim", "Enabled", false)
   
    if (UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Disable fakelag on round end"))
        UI.SetValue("Anti-Aim", "Fake-Lag", "Enabled", false)
}
function roundStartListener(){
    if (UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Disable aa on round end"))
        UI.SetValue("Anti-Aim", "Rage Anti-Aim", "Enabled", true)
   
    if (UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Disable fakelag on round end"))
        UI.SetValue("Anti-Aim", "Fake-Lag", "Enabled", true)
}



function HSVtoRGB(h, s, v) {
    var r, g, b, i, f, p, q, t;
    if (arguments.length === 1) {
        s = h.s, v = h.v, h = h.h;
    }
    i = Math.floor(h * 6);
    f = h * 6 - i;
    p = v * (1 - s);
    q = v * (1 - f * s);
    t = v * (1 - (1 - f) * s);
    switch (i % 6) {
        case 0: r = v, g = t, b = p; break;
        case 1: r = q, g = v, b = p; break;
        case 2: r = p, g = v, b = t; break;
        case 3: r = p, g = q, b = v; break;
        case 4: r = t, g = p, b = v; break;
        case 5: r = v, g = p, b = q; break;
    }
    return {
        r: Math.round(r * 255),
        g: Math.round(g * 255),
        b: Math.round(b * 255)
    };
}

var get = {
    state(state) {
        return UI.GetValue("Misc", "JAVASCRIPT", "Script items", state);
    },
    string(string) {
        return UI.GetString("Misc", "JAVASCRIPT", "Script items", string);
    }
}

var dTime, dDelay, dFillbar, dShotsfired;
function dt()
{
    iShotsFired = Event.GetInt("userid"); iShotsFired_index = Entity.GetEntityFromUserID(iShotsFired);
 
    if(Entity.GetLocalPlayer() == iShotsFired_index)
    {
        if(UI.IsHotkeyActive("Rage", "GENERAL", "Exploits", "Doubletap", "Enabled"))
        {
            if(dShotsfired == 0)
            {
                dTime = Globals.Curtime();
                dDelay = dTime+0.3;
                dFillbar = 0;
            }
        }
    }
}

function getVelocity(index)
{
    players = Entity.GetPlayers();
    for (i=0; i < players.length; i++); 
    {
    var velocity = Entity.GetProp( index, "CBasePlayer", "m_vecVelocity[0]" );
    var speed = Math.sqrt( velocity[0] * velocity[0] + velocity[1] * velocity[1] );
    } 
    return speed;
}

function weaponType() {
    var local = Entity.GetLocalPlayer();
    var weapon = Entity.GetName(Entity.GetWeapon(local));
    var weapons = {
        "usp s": "PISTOL",
        "glock 18": "PISTOL",
        "p2000": "PISTOL",
        "dual berettas": "PISTOL",
        "r8 revolver": "PISTOL",
        "desert eagle": "PISTOL",
        "p250": "PISTOL",
        "tec 9": "PISTOL",
        "five seven": "PISTOL",
        "mp9": "SMG",
        "mac 10": "SMG",
        "ump 45": "SMG",
        "ak 47": "RIFLE",
        "sg 553": "RIFLE",
        "aug": "RIFLE",
        "m4a1 s": "RIFLE",
        "m4a4": "RIFLE",
        "galil": "RIFLE",
        "ssg 08": "SNIPER",
        "awp": "SNIPER",
        "g3sg1": "SNIPER",
        "scar 20": "SNIPER",
        "nova": "GENERAL",
        "xm1014": "GENERAL",
        "mag 7": "GENERAL",
        "m249": "GENERAL",
        "negev": "GENERAL"
    };
    
    if (weapons[weapon] == undefined)
        return "";
    return weapons[weapon];
}
function hcType() {
    var local = Entity.GetLocalPlayer();
    var weapon = Entity.GetName(Entity.GetWeapon(local));
    var weapons = {
        "usp s": "PISTOL",
        "glock 18": "PISTOL",
        "p2000": "PISTOL",
        "dual berettas": "PISTOL",
        "r8 revolver": "HEAVY PISTOL",
        "desert eagle": "HEAVY PISTOL",
        "p250": "PISTOL",
        "tec 9": "PISTOL",
        "five seven": "PISTOL",
        "mp9": "GENERAL",
        "mac 10": "GENERAL",
        "ump 45": "GENERAL",
        "ak 47": "GENERAL",
        "sg 553": "GENERAL",
        "aug": "GENERAL",
        "m4a1 s": "GENERAL",
        "m4a4": "GENERAL",
        "galil": "GENERAL",
        "ssg 08": "SCOUT",
        "awp": "AWP",
        "g3sg1": "AUTOSNIPER",
        "scar 20": "AUTOSNIPER",
        "nova": "GENERAL",
        "xm1014": "GENERAL",
        "mag 7": "GENERAL",
        "m249": "GENERAL",
        "negev": "GENERAL"
    };
    
    if (weapons[weapon] == undefined)
        return "";
    return weapons[weapon];
}

function indicator(){
        const x = UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Indicator - X");
        const y = UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Indicator - Y");
        var h = [];

        var fakeyaw, realyaw, diffrence, r, g, b;

        fakeyaw = (Local.GetFakeYaw());
        realyaw = (Local.GetRealYaw());  
        diffrence =  Math.round(realyaw - fakeyaw)
        desyncAmt = Math.abs(diffrence)

        if (desyncAmt <= 29)
        {
            r = 255
            g = 0
            b = 0
        }
        else if (desyncAmt >= 45)
        {
            r = 132
            g = 195
            b = 16
        }
        else 
        {
            r = 255 - (desyncAmt * 3)
            g = desyncAmt * 3
            b = 0
        }
        var color1, color2, color3;
        var lp = Entity.GetLocalPlayer();

        var velocity = Math.round(getVelocity(lp)).toString();
        if (Input.IsKeyPressed(0x20) & velocity > 250) {
            if(UI.GetValue("Misc", "JAVASCRIPT", "Script items", "LBY") == true) {
                h.push("0");
            }
        }

        var rgb = HSVtoRGB(Global.Tickcount() % 350 / 350, 1, 1, 1, 255);
        if(get.string("Name") == "") {
            //
        }
        else {
            h.push("99");
        }
        if (UI.GetValue("Misc", "JAVASCRIPT", "Script items", "FOV") == true) {
            h.push("97");
        }
        if (UI.GetValue("Misc", "JAVASCRIPT", "Script items", "HC") == true) {
            h.push("96");
        }
        if (UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Legit&Rage AA R/L") == true) {
            h.push("4");
        }
        if (UI.GetValue("Anti-Aim", "Rage Anti-Aim", "Enabled") == true) {
            if (UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Fake") == true)
            {
                h.push("1");
            }
        }
        if (UI.GetValue("Anti-Aim", "Legit Anti-Aim", "Enabled") == true) {
            if (UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Fake") == true)
            {
                h.push("2");
            }
        }
        if (UI.IsHotkeyActive("Legit", "GENERAL", "Triggerbot", "Enabled")) {
            if (UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Triggerbot") == true)
            {
                h.push("3");
            }
        }
        if (UI.GetValue("Anti-Aim", "Fake-Lag", "Enabled") == true) {
            if (UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Lag") == true)
            {
                h.push("5");
            }
        }
        if (UI.IsHotkeyActive("Rage", "Exploits", "Doubletap")) {
            if (UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Double Tap"))
            {
                h.push("6");
            }
        }
        if (UI.IsHotkeyActive("Anti-Aim", "Extra", "Slow walk")) {
            if (UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Slow") == true)
            {
                h.push("7");
            }
        }
        if (UI.IsHotkeyActive("Anti-Aim", "Extra", "Fake duck")) {
            if (UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Fake Duck") == true)
            {
                h.push("8");
            }
        }
        if (UI.IsHotkeyActive("Misc", "General", "Movement", "Auto peek")) {
            if (UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Auto Peek") == true)
            {
                h.push("9");
            }
        }
        if (UI.IsHotkeyActive("Rage", "General", "General", "Safe point override")) {
            if (UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Safe Point") == true)
            {
                h.push("10");
            }
        }
        if (UI.IsHotkeyActive("Anti-Aim", "Fake angles", "Inverter")) {
            if (UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Invert") == true)
            {
                h.push("11");
            }
        }
        
        // https://www.onetap.com/threads/hitbox-override.20676/
        if (UI.IsHotkeyActive("Script items", "Hitbox Override Key")) {
            if (UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Hitbox Override") == true)
            {
                h.push("12");
            }
        }
        
        // https://www.onetap.com/threads/mindmg-override-on-key.20570/
        if (UI.IsHotkeyActive("Script items", "Heavy Pistol Override") & UI.IsHotkeyActive("Script items", "Scout Override") & UI.IsHotkeyActive("Script items", "AWP Override") & UI.IsHotkeyActive("Script items", "Auto Override")) {
            if (UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Damage Override") == true)
            {
                h.push("13");
            }
        }
       
        if (UI.IsHotkeyActive("Rage", "Exploits", "Hide shots")) {
            if (UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Hide Shots") == true)
            {
                h.push("14");
            }
        }
       
        var distance = 25;
        for (index = 0; index < h.length; ++index) {
            if(h[index] == 0) {
                if (velocity > 295)
                {
                    var color1 = 132
                    var color2 = 195
                    var color3 = 16
                }
                else
                {
                    var color1 = 255
                    var color2 = 0
                    var color3 = 0
                }

                Render.String( x, y - 83 - (index * distance), 0, "LBY", [0, 0, 0, 255] , 4);
                Render.String( x + 1, y - 83 - (index * distance), 0, "LBY", [ color1, color2, color3, 255 ] , 4);
            }
            if(h[index] == 1)
                {
                    color = Math.abs( Local.GetRealYaw( ) - Local.GetFakeYaw( ) );
                    if( !Entity.GetLocalPlayer( ) || !Entity.IsAlive( Entity.GetLocalPlayer( ) ) || !Entity.IsValid( Entity.GetLocalPlayer( ) ) )
                        return;
                    Render.String( x, y - 83 - (index * distance), 0, "FAKE", [0, 0, 0, 255] , 4);
                    Render.String( x + 1, y - 83 - (index * distance), 0, "FAKE", [ color * 255 / 58, 255 - ( color * 255 / 58 ), 0, 255 ] , 4);
                }
            if(h[index] == 2)
                {
                    if( !Entity.GetLocalPlayer( ) || !Entity.IsAlive( Entity.GetLocalPlayer( ) ) || !Entity.IsValid( Entity.GetLocalPlayer( ) ) )
                        return;

                    Render.String( x, y - 83 - (index * distance), 0, "AA", [ 0, 0, 0, 255] , 4);
                    Render.String( x + 1, y - 83 - (index * distance), 0, "AA", [ 255, 255, 255, 255 ] , 4);

                    Render.FilledRect(3, y - 54 - (index * distance), 42, 5, [ 0, 0, 0, 150 ]);
                    if(UI.IsHotkeyActive("Anti-Aim", "Legit Anti-Aim", "Direction key")) {
                        Render.FilledRect(4, y - 53 - (index * distance), 20, 3, [ 30, 150, 255, 150 ]);
                    }
                    else {
                        Render.FilledRect(4 + 20, y - 53 - (index * distance), 20, 3, [ 30, 150, 255, 150 ]);
                    }
                }
            if(h[index] == 3)
                {
                    Render.String( x, y - 83 - (index * distance), 0, "TRIGGER", [0, 0, 0, 255] , 4);
                    Render.String( x + 1, y - 83 - (index * distance), 0, "TRIGGER", [124, 195, 13, 255] , 4);
                }
            if(h[index] == 4)
                {
                    if(UI.GetValue("Rage", "GENERAL", "Enabled") == true) {
                        if(UI.IsHotkeyActive("Anti-Aim", "Fake angles", "Inverter")) {
                            Render.String( x, y - 83 - (index * distance), 0, "LEFT", [0, 0, 0, 255] , 4);
                            Render.String( x + 1, y - 83 - (index * distance), 0, "LEFT", [255, 255, 255, 255] , 4);
                        }
                        else {
                            Render.String( x, y - 83 - (index * distance), 0, "RIGHT", [0, 0, 0, 255] , 4);
                            Render.String( x + 1, y - 83 - (index * distance), 0, "RIGHT", [255, 255, 255, 255] , 4);
                        }
                    }
                    else {
                        if(UI.IsHotkeyActive("Anti-Aim", "Legit Anti-Aim", "Direction key")) {
                            Render.String( x, y - 83 - (index * distance), 0, "LEFT", [0, 0, 0, 255] , 4);
                            Render.String( x + 1, y - 83 - (index * distance), 0, "LEFT", [255, 255, 255, 255] , 4);
                        }
                        else {
                            Render.String( x, y - 83 - (index * distance), 0, "RIGHT", [0, 0, 0, 255] , 4);
                            Render.String( x + 1, y - 83 - (index * distance), 0, "RIGHT", [255, 255, 255, 255] , 4);
                        }
                    }
                }
            if(h[index] == 5)
                {
                    curtime = Globals.Curtime();
                    Render.String( x, y - 83 - (index * distance), 0, "LAG", [0, 0, 0, 255] , 4);
                    Render.String( x + 1, y - 83 - (index * distance), 0, "LAG", [ curtime * 255 / 58, 255 - ( curtime * 255 / 58 ), 0, 255 ] , 4);
                }
            if(h[index] == 6)
                {
                    curtime = Globals.Curtime();
                    if (curtime <= dDelay) {
                        Render.String( x, y - 83 - (index * distance), 0, "DT", [0, 0, 0, 255] , 4);
                        Render.String( x + 1, y - 83 - (index * distance), 0, "DT", [ curtime * 255 / 58, 255 - ( curtime * 255 / 58 ), 0, 255 ] , 4);
                      
                        dFillbar+=3;
                        dShotsfired = 1;
                     
                        if(dFillbar >= 65) dFillbar = 65;
                        Render.FilledRect(3, y - 54 - (index * distance), 67, 5, [ 0, 0, 0, 150 ]);
                        Render.FilledRect(4, y - 53 - (index * distance), dFillbar, 3, [ 30, 150, 255, 150 ]);
                    }
                    else {
                        Render.String( x, y - 83 - (index * distance), 0, "DT", [0, 0, 0, 255] , 4);
                        Render.String( x + 1, y - 83 - (index * distance), 0, "DT", [30, 150, 255, 255] , 4);
                        dShotsfired = 0;
                    }
                }
            if(h[index] == 7)
                {
                    Render.String( x, y - 83 - (index * distance), 0, "SLOW", [0, 0, 0, 255] , 4);
                    Render.String( x + 1, y - 83 - (index * distance), 0, "SLOW", [ 0, 252, 231, 255 ] , 4);
                }
            if(h[index] == 8)
                {
                    Render.String( x, y - 83 - (index * distance), 0, "DUCK", [0, 0, 0, 255] , 4);
                    Render.String( x + 1, y - 83 - (index * distance), 0, "DUCK", [255, 255, 255, 255] , 4);
                }
            if(h[index] == 9)
                {
                    Render.String( x, y - 83 - (index * distance), 0, "AUTOPEEK", [0, 0, 0, 255] , 4);
                    Render.String( x + 1, y - 83 - (index * distance), 0, "AUTOPEEK", [124, 195, 13, 255] , 4);
                }
            if(h[index] == 11)
                {
                    Render.String( x, y - 83 - (index * distance), 0, "INVERT", [0, 0, 0, 255] , 4);
                    Render.String( x + 1, y - 83 - (index * distance), 0, "INVERT", [255, 255, 255, 255] , 4);
                }
            if(h[index] == 10)
                {
                    Render.String( x, y - 83 - (index * distance), 0, "SAFE", [0, 0, 0, 255] , 4);
                    Render.String( x + 1, y - 83 - (index * distance), 0, "SAFE", [124, 195, 13, 255] , 4);
                }
            if(h[index] == 12)
                {
                    Render.String( x, y - 83 - (index * distance), 0, "HITBOX", [0, 0, 0, 255] , 4);
                    Render.String( x + 1, y - 83 - (index * distance), 0, "HITBOX", [124, 195, 13, 255] , 4);
                }
            if(h[index] == 13)
                {
                    Render.String( x, y - 83 - (index * distance), 0, "DMG", [0, 0, 0, 255] , 4);
                    Render.String( x + 1, y - 83 - (index * distance), 0, "DMG", [124, 195, 13, 255] , 4);
                }
            if(h[index] == 14)
                {
                    Render.String( x, y - 83 - (index * distance), 0, "HS", [0, 0, 0, 255] , 4);
                    Render.String( x + 1, y - 83 - (index * distance), 0, "HS", [124, 195, 13, 255] , 4);
                }
            if(h[index] == 99)
                {
                    if(get.string("Name") == "") {
                        //
                    }
                else {
                        Render.String( x, y - 83 - (index * distance), 0, get.string("Name"), [0, 0, 0, 255] , 4);
                        Render.String( x + 1, y - 83 - (index * distance), 0, get.string("Name"), [rgb.r, rgb.g, rgb.b, 255] , 4);
                    }
                }
            if(h[index] == 97)
                {
                    weaponT = weaponType();
                    fov = UI.GetValue("Legit", weaponT, "Fov");
                    
                    Render.String( x, y - 83 - (index * distance), 0, "FOV: " + fov, [0, 0, 0, 255] , 4);
                    Render.String( x + 1, y - 83 - (index * distance), 0, "FOV: " + fov, [124, 195, 13, 255] , 4);
                }
            if(h[index] == 96)
                {
                    weaponT = hcType();
                    if(weaponT == "") {
                        hc = "0";
                    }
                    else {
                        hc = UI.GetValue("Rage", weaponT, "Accuracy", "Hitchance");
                    }
                    
                    Render.String( x, y - 83 - (index * distance), 0, "HC: " + hc, [0, 0, 0, 255] , 4);
                    Render.String( x + 1, y - 83 - (index * distance), 0, "HC: " + hc, [124, 195, 13, 255] , 4);
                }
        }
}


UI.AddSliderInt("                  ", 0, 0);
UI.AddLabel("           AA     ");

UI.AddCheckbox("Low delta");
UI.AddDropdown( "Low delta type", [ "Custom", "On key" ] );
const lowdelta_modes = UI.AddMultiDropdown("Low delta modes", [ "Slow walk", "Low HP", "Standing" ]);
UI.AddHotkey("Low delta on key");
UI.AddLabel("");

function SetEnabled()
{
    if (UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Low delta"))
    {
       UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Low delta type", 1)
    }
    else
    {
       UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Low delta type", 0)
    }

    if (UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Low delta type") == 0 && UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Low delta"))
    {
       UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Low delta modes", 1)
       UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Low delta on key", 0)
    }
    else if (UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Low delta type") == 1 && UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Low delta"))
    {
       UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Low delta modes", 0)
       UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Low delta on key", 1)
    }
    else
    {
       UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Low delta modes", 0)
       UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Low delta on key", 0)
    }
}

function get_velocity(index)
{
    var velocity = Entity.GetProp(index, "CBasePlayer", "m_vecVelocity[0]");
    return Math.sqrt(velocity[0] * velocity[0] + velocity[1] * velocity[1]);
}

function get_health(index)
{
    health_override = Entity.GetProp(index, "CBasePlayer", "m_iHealth");
    return health_override;
}

function getRandomIntInclusive(min, max) {
    min = Math.ceil(min);
    max = Math.floor(max);
    return Math.floor(Math.random() * (min - max * 411,23)) + min; //The maximum is inclusive and the minimum is inclusive
  }

function Low_delta()
{
    localplayer_index = Entity.GetLocalPlayer( );
    const lowdelta_dropdown_value = UI.GetValue.apply(null, lowdelta_modes);

    var velocity = get_velocity(localplayer_index)
    var health = get_health(localplayer_index)
    var LowHP = false
    var SlowWalk = false
    var Standing = false
    var Onkey = false

    if (UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Low delta") && UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Low delta type") == 0)
    {
       if (lowdelta_dropdown_value & (1 << 0) && UI.IsHotkeyActive("Anti-Aim", "Extra", "Slow walk"))
       SlowWalk = true
       else
       SlowWalk = false

       if (lowdelta_dropdown_value & (1 << 1) && health < 50)
       LowHP = true
       else
       LowHP = false

       if (lowdelta_dropdown_value & (1 << 2) && velocity < 3)
       Standing = true
       else
       Standing = false
    }
    else if (UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Low delta") && UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Low delta type") == 1)
    {
       if (UI.IsHotkeyActive("Misc", "JAVASCRIPT", "Script items", "Low delta on key"))
       Onkey = true
       else
       Onkey = false
    }

        if (Standing == true || LowHP == true || SlowWalk == true || Onkey == true && UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Low delta"))
        {
            UI.SetValue("Anti-Aim", "Rage Anti-Aim", "Yaw offset", 10);
            UI.SetValue("Anti-Aim", "Rage Anti-Aim", "Jitter offset", 0);
            AntiAim.SetOverride(1);
            AntiAim.SetFakeOffset(0);
            AntiAim.SetRealOffset(-26);
            AntiAim.SetFakeOffset(getRandomIntInclusive( -1,52 , -2,54 ));
            AntiAim.SetRealOffset(getRandomIntInclusive( -423 , -421));
        }
        else
        {
            UI.SetValue("Anti-Aim", "Rage Anti-Aim", "Yaw offset", 0);
            AntiAim.SetOverride(0);
        }
}

function drawString()
{
    localplayer_index = Entity.GetLocalPlayer( );
    localplayer_alive = Entity.IsAlive( localplayer_index );
    const fontpixel = Render.AddFont( "Verdana", 8, 100);
    const lowdelta_dropdown_value = UI.GetValue.apply(null, lowdelta_modes);
    var SFOnkey = false
    var screen_size = Global.GetScreenSize();
    var velocity = get_velocity(localplayer_index)
    var health = get_health(localplayer_index)

    SlowWalk = false
    LowHP = false
    Standing = false
    Onkey = false

    if (UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Low delta") && UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Low delta type") == 0)
    {
       if (lowdelta_dropdown_value & (1 << 0) && UI.IsHotkeyActive("Anti-Aim", "Extra", "Slow walk"))
       SlowWalk = true
       else
       SlowWalk = false

       if (lowdelta_dropdown_value & (1 << 1) && health < 50)
       LowHP = true
       else
       LowHP = false

       if (lowdelta_dropdown_value & (1 << 2) && velocity < 3)
       Standing = true
       else
       Standing = false
    }
    else if (UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Low delta") && UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Low delta type") == 1)
    {
       if (UI.IsHotkeyActive("Misc", "JAVASCRIPT", "Script items", "Low delta on key"))
       Onkey = true
       else
       Onkey = false
    }

    if (Standing == true || LowHP == true || SlowWalk == true || Onkey == true)
    {
        drawIND = true
    }
    else
    {
        drawIND = false
    }

    if (drawIND == true && localplayer_alive == true && UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Low delta") == true)
    {
       Render.StringCustom(screen_size[0] /2 , screen_size[1] /2 +25, 1, "LOW DELTA", [ 255, 0, 0, 255 ], fontpixel );
    }
}

Global.RegisterCallback("Draw", "drawString");
Global.RegisterCallback("Draw", "SetEnabled");
Cheat.RegisterCallback("CreateMove", "Low_delta");
UI.AddDropdown("Anti Bruteforce", ["Off", "On Hit", "On Shot"]);
UI.AddLabel("");
function GetScriptOption(name)
{
    var Value = UI.GetValue("Misc", "JAVASCRIPT", "Script Items", name);
    return Value;
}

function radian(degree)
{
    return degree * Math.PI / 180.0;
}

function ExtendVector(vector, angle, extension)
{
    var radianAngle = radian(angle);
    return [extension * Math.cos(radianAngle) + vector[0], extension * Math.sin(radianAngle) + vector[1], vector[2]];
}

function VectorAdd(a, b)
{
    return [a[0] + b[0], a[1] + b[1], a[2] + b[2]];
}

function VectorSubtract(a, b)
{
    return [a[0] - b[0], a[1] - b[1], a[2] - b[2]];
}

function VectorMultiply(a, b)
{
    return [a[0] * b[0], a[1] * b[1], a[2] * b[2]];
}

function VectorLength(x, y, z)
{
    return Math.sqrt(x * x + y * y + z * z);
}

function VectorNormalize(vec)
{
    var length = VectorLength(vec[0], vec[1], vec[2]);
    return [vec[0] / length, vec[1] / length, vec[2] / length];
}

function VectorDot(a, b)
{
    return a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
}

function VectorDistance(a, b)
{
    return VectorLength(a[0] - b[0], a[1] - b[1], a[2] - b[2]);
}

function ClosestPointOnRay(target, rayStart, rayEnd)
{
    var to = VectorSubtract(target, rayStart);
    var dir = VectorSubtract(rayEnd, rayStart);
    var length = VectorLength(dir[0], dir[1], dir[2]);
    dir = VectorNormalize(dir);

    var rangeAlong = VectorDot(dir, to);
    if (rangeAlong < 0.0)
    {
        return rayStart;
    }
    if (rangeAlong > length)
    {
        return rayEnd;
    }
    return VectorAdd(rayStart, VectorMultiply(dir, [rangeAlong, rangeAlong, rangeAlong]));
}

function Flip()
{
    UI.ToggleHotkey("Anti-Aim", "Fake angles", "Inverter");
}

var lastHitTime = 0.0;
var lastImpactTimes =
[
    0.0
];
var lastImpacts =
[
    [0.0, 0.0, 0.0]
];

function OnHurt()
{
    if (GetScriptOption("Anti Bruteforce") == 0) return;
    if (Entity.GetEntityFromUserID(Event.GetInt("userid")) !== Entity.GetLocalPlayer()) return;
    var hitbox = Event.GetInt('hitgroup');

    if (hitbox == 1 || hitbox == 6 || hitbox == 7)  //head, both toe
    {
        var curtime = Global.Curtime();
        if (Math.abs(lastHitTime - curtime) > 0.5)   //0.2s backtrack + 0.2 extand + 0.1 extra
        {
            lastHitTime = curtime;
            Flip();
        }
    }
}

function OnBulletImpact()
{
    if (GetScriptOption("Anti Bruteforce") !== 2) return;

    var curtime = Global.Curtime();
    if (Math.abs(lastHitTime - curtime) < 0.5) return;

    var entity = Entity.GetEntityFromUserID(Event.GetInt("userid"));
    var impact = [Event.GetFloat("x"), Event.GetFloat("y"), Event.GetFloat("z"), curtime];
    var source;
    if (Entity.IsValid(entity) && Entity.IsEnemy(entity))
    {
        if (!Entity.IsDormant(entity))
        {
            source = Entity.GetEyePosition(entity);
        }
        else if (Math.abs(lastImpactTimes[entity] - curtime) < 0.1)
        {
            source = lastImpacts[entity];
        }
        else
        {
            lastImpacts[entity] = impact;
            lastImpactTimes[entity] = curtime;
            return;
        }
        var local = Entity.GetLocalPlayer();
        var localEye = Entity.GetEyePosition(local);
        var localOrigin = Entity.GetProp(local, "CBaseEntity", "m_vecOrigin");
        var localBody = VectorMultiply(VectorAdd(localEye, localOrigin), [0.5, 0.5, 0.5]);

        var bodyVec = ClosestPointOnRay(localBody, source, impact);
        var bodyDist = VectorDistance(localBody, bodyVec);
        
        if (bodyDist < 128.0)       //he clearly shot at us!
        {
            var realAngle = Local.GetRealYaw();
            var fakeAngle = Local.GetFakeYaw();

            var headVec = ClosestPointOnRay(localEye, source, impact);
            var headDist = VectorDistance(localEye, headVec);
            var feetVec = ClosestPointOnRay(localOrigin, source, impact);
            var feetDist = VectorDistance(localOrigin, feetVec);

            var closestRayPoint;
            var realPos;
            var fakePos;

            if (bodyDist < headDist && bodyDist < feetDist)     //that's a pelvis
            {                                                   //pelvis direction = goalfeetyaw + 180       
                closestRayPoint = bodyVec;
                realPos = ExtendVector(bodyVec, realAngle + 180.0, 10.0);
                fakePos = ExtendVector(bodyVec, fakeAngle + 180.0, 10.0);
            }
            else if (feetDist < headDist)                       //ow my toe
            {                                                   //toe direction = goalfeetyaw -30 +- 90
                closestRayPoint = feetVec;
                var realPos1 = ExtendVector(bodyVec, realAngle - 30.0 + 90.0, 10.0);
                var realPos2 = ExtendVector(bodyVec, realAngle - 30.0 - 90.0, 10.0);
                var fakePos1 = ExtendVector(bodyVec, fakeAngle - 30.0 + 90.0, 10.0);
                var fakePos2 = ExtendVector(bodyVec, fakeAngle - 30.0 - 90.0, 10.0);
                if (VectorDistance(feetVec, realPos1) < VectorDistance(feetVec, realPos2))
                {
                    realPos = realPos1;
                }
                else
                {
                    realPos = realPos2;
                }
                if (VectorDistance(feetVec, fakePos1) < VectorDistance(feetVec, fakePos2))
                {
                    fakePos = fakePos1;
                }
                else
                {
                    fakePos = fakePos2;
                }
            }
            else                                                //ow my head i feel like i slept for 2 days
            {
                closestRayPoint = headVec;
                realPos = ExtendVector(bodyVec, realAngle, 10.0);
                fakePos = ExtendVector(bodyVec, fakeAngle, 10.0);
            }

            if (VectorDistance(closestRayPoint, fakePos) < VectorDistance(closestRayPoint, realPos))        //they shot at our fake. they will probably not gonna shoot it again.
            {
                lastHitTime = curtime;
                Flip();
            }
        }

        lastImpacts[entity] = impact;
        lastImpactTimes[entity] = curtime;
    }
}

Cheat.RegisterCallback("player_hurt", "OnHurt");
Cheat.RegisterCallback("bullet_impact", "OnBulletImpact");
////////////////////////////////////////////////////////////////////////////////////////////////////////
UI.AddSliderInt("                  ", 0, 0);
var last = 0
var shot = false
UI.AddLabel("           DT     ");
Global.PrintColor([186, 235, 52, 255], "\n\n[discord.exration.com] Loaded DT! \n\n\n\n");
UI.AddCheckbox("Fast DT Recharge")
function lastShot(){
    if(Entity.GetLocalPlayer() == Entity.GetEntityFromUserID(Event.GetInt("userid")) && UI.IsHotkeyActive("Rage","GENERAL","Exploits","Doubletap")){
       
        last = Globals.Tickcount()
        shot = true
    }
}
var wasActive = true
var wasfding = false
var lastfding = 0
function cm(){
    if(!UI.GetValue("Script Items", "Fast DT Recharge") || (UI.IsHotkeyActive("Rage","GENERAL","Exploits","Hide shots") && !UI.IsHotkeyActive("Rage","GENERAL","Exploits","Doubletap"))){
        Exploit.EnableRecharge()
        return
    }
    Exploit.DisableRecharge()
    if(!UI.IsHotkeyActive("Rage","GENERAL","Exploits","Doubletap"))
    wasActive = false
    if(!wasActive && UI.IsHotkeyActive("Rage","GENERAL","Exploits","Doubletap")){
        Exploit.Recharge()
        wasActive = true
    }
    if(UI.IsHotkeyActive("Anti-Aim","Extra","Fake duck")){
        wasfding = true
        lastfding = Globals.Tickcount()
    }
    if(!UI.IsHotkeyActive("Anti-Aim","Extra","Fake duck") && wasfding && Globals.Tickcount() - 2 > lastfding){
        Exploit.Recharge()
        wasfding = false
    }
   
    if(last + 4 < Globals.Tickcount() && shot){
        Exploit.Recharge()
        shot = false
    }
}

function roundStart(){
    if(!UI.GetValue("Script Items", "Fast DT Recharge") || (UI.IsHotkeyActive("Rage","GENERAL","Exploits","Hide shots") && !UI.IsHotkeyActive("Rage","GENERAL","Exploits","Doubletap"))) return
    if(Exploit.GetCharge() != 0){
        Exploit.Recharge()
        last = Globals.Tickcount()
    }
}
Cheat.RegisterCallback("weapon_fire","lastShot")
Cheat.RegisterCallback("CreateMove","cm")
Cheat.RegisterCallback("round_start","roundStart")
Cheat.RegisterCallback("round_prestart","roundStart")
Cheat.RegisterCallback("round_end","roundStart")

UI.AddCheckbox("Better doubletap");

function on_ragebot_fire()
{ 
    
    ragebot_target_exploit = Event.GetInt("exploit");
    if (UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Better doubletap"))
    {
        if (ragebot_target_exploit == 2)
        {
            UI.SetValue("Rage", "GENERAL", "Exploits", "Doubletap fast recovery", true);
        }
        else
        {
            UI.SetValue("Rage", "GENERAL", "Exploits", "Doubletap fast recovery", false);
        }
    }       
}

Global.RegisterCallback("ragebot_fire", "on_ragebot_fire");

// watermark by raidhvh 02.12.2019
// 02.12.2019 updated
/*
  1) fixed issues with other resolution
  2) fixed issues with time
  3) ping now more accurate
  4) added x and y sliders(paste)
*/

/* 03.12.2019 updated
    1) changed fps design
    2) watermark save position with cfg( must work )
*/

/*
    08.12.2019 updated
    1) fixed time
    2) updated rainbow line(pasted of "Animated rainbow line (cringe)" by ksenon)
*/

function HSVtoRGB(h, s, v)
{
    var r, g, b, i, f, p, q, t;

    i = Math.floor(h * 6);
    f = h * 6 - i;
    p = v * (1 - s);
    q = v * (1 - f * s);
    t = v * (1 - (1 - f) * s);

    switch (i % 6)
    {
        case 0: r = v, g = t, b = p; break;
        case 1: r = q, g = v, b = p; break;
        case 2: r = p, g = v, b = t; break;
        case 3: r = p, g = q, b = v; break;
        case 4: r = t, g = p, b = v; break;
        case 5: r = v, g = p, b = q; break;
    }

    return { r: Math.round(r * 255), g: Math.round(g * 255), b: Math.round(b * 255) };
}
function getCustomValue(xy) {
  var value = UI.GetValue("MISC", "JAVASCRIPT", "Script items", xy);
return value;}
var position = {
  x1: 0,
  y1: 0
}

function watermark()
{
   
    var colors = HSVtoRGB(Global.Realtime() * UI.GetValue("MISC", "JAVASCRIPT", "Script Items", "Watermark Gradient Speed"), 1, 1);
   
    const ping = Math.floor(Global.Latency() * 1000 / 1.5 );
    const fps = Math.floor( 1 / Global.Frametime() );
       
   
    x1 = getCustomValue("Watermark x");
    y1 = getCustomValue("Watermark y");  
    var today = new Date();
    var hours1 = today.getHours();
    var minutes1 = today.getMinutes();
    var seconds1 = today.getSeconds();
    var hours = hours1 <= 9 ? "0" + today.getHours() + ":" : today.getHours() + ":";
    var minutes = minutes1 <= 9 ? "0" + today.getMinutes() + ":" : today.getMinutes() + ":";
    var seconds = seconds1 <= 9 ? "0" + today.getSeconds() : today.getSeconds()    ;

   

    var tickrate = Global.Tickrate()
    Render.FilledRect( x1 + 45, y1 + 2, 260, 55 , [ 30, 30, 30, 150 ] ); // background
    Render.Rect( x1 + 45, y1 + 2, 260, 55, [ 30, 30, 30, 255 ] );
    Render.FilledRect( x1 + 50, y1 + 7, 250, 45, [ 30, 30, 30, 255 ] ); // background1
    Render.String( x1 + 122, y1 + 37, 0, "TCK   ", [ 120, 120, 120, 255 ], 3 ); //TCK
    Render.String( x1 + 127, y1 + 37, 0, "          " + tickrate, [ 255, 255, 255, 220 ], 3 ); // TCK1
    Render.Rect( x1 + 120, y1 + 35, 23, 13, [ 120, 120, 120, 255] ); // TCK2
    Render.Rect( x1 + 170, y1 + 35, 6, 13, [ 120, 120, 120, 255] ) ;// ping
    Render.Rect( x1 + 177, y1 + 38, 6, 10, [ 120, 120, 120, 255] ); // ping1
    Render.Rect( x1 + 184, y1 + 41, 6, 7, [ 120, 120, 120, 255] ); // ping2
    Render.Circle( x1 + 237, y1 + 41, 6, [ 120, 120, 120, 255 ] ) ;// clock
    Render.Line( x1 + 237, y1 + 42, x1 + 237, y1 + 36, [ 120, 120, 120, 255 ] ); // clock1
    Render.Line( x1 + 237, y1 + 42, x1 + 243, y1 + 42, [ 120, 120, 120, 255 ] ); // clock2
    Render.String( x1 + 192, y1 + 37, 0, " " + ping + "ms", [ 255, 255, 255, 200 ], 3 );
    Render.Rect( x1 + 67, y1 + 33, 21, 13, [ 120, 120, 120, 255] ); // fps2
    Render.Rect( x1 + 69, y1 + 31, 21, 13, [ 120, 120, 120, 255] ); // fps3    
    Render.FilledRect( x1 + 65, y1 + 35, 21, 13, [30, 30, 30, 255] ); // background fps
    Render.Rect( x1 + 65, y1 + 35, 21, 13, [ 120, 120, 120, 255] ); // fps1
    Render.String( x1 + 67, y1 + 37, 0, "FPS   " , [ 120, 120, 120, 255 ], 3 );
    Render.String( x1 + 72, y1 + 37, 0, "           " + fps * 2 , [ 255, 255, 255, 220 ], 3 );
    Render.String( x1 + 247, y1 + 37, 0, " " + hours + minutes + seconds, [ 255, 255, 255, 220 ], 3 );
    Render.GradientRect( x1 + 55,  y1 + 25, 120, 3, 1, [colors.g, colors.b, colors.r, 255], [colors.r, colors.g, colors.b, 255]); // rainbow line
    Render.GradientRect( x1 + 175, y1 + 25, 120, 3, 1, [colors.r, colors.g, colors.b, 255], [colors.b, colors.r, colors.g, 255]); // rainbow line
    Render.String( x1 + 157, y1 + 12, 0, "onetap.su", [ 255, 255, 255, 200], 3 );
   
}

var s = Render.GetScreenSize();
var fSettings = {};
var rSettings = {};
function menuLogic() {
    if (!UI.IsMenuOpen()) return;
    fSettings.enabled = UI.GetValue("Fake Indicator");
    fSettings.third = UI.GetValue("3rd Person Fake Indicator");
    fSettings.color = UI.GetColor("Script Items", "Fake Color");
    fSettings.distance = UI.GetValue("Fake Distance");
    fSettings.size = UI.GetValue("Fake Size");
    rSettings.enabled = UI.GetValue("Real Indicator");
    rSettings.third = UI.GetValue("3rd Person Real Indicator");
    rSettings.color = UI.GetColor("Script Items", "Real Color");
    rSettings.distance = UI.GetValue("Real Distance");
    rSettings.size = UI.GetValue("Real Size");
    UI.SetEnabled("3rd Person Fake Indicator", fSettings.enabled);
    UI.SetEnabled("Fake Color", fSettings.enabled);
    UI.SetEnabled("Fake Distance", fSettings.enabled);
    UI.SetEnabled("Fake Size", fSettings.enabled);
    UI.SetEnabled("3rd Person Real Indicator", rSettings.enabled);
    UI.SetEnabled("Real Color", rSettings.enabled);
    UI.SetEnabled("Real Distance", rSettings.enabled);
    UI.SetEnabled("Real Size", rSettings.enabled);
}
function rotate(add, flip, start, degree, distance) {
    rad = degree * (Math.PI/180);
    ind0 = (flip ? Math.cos(rad) : Math.sin(rad)) * distance;
    ind1 = (flip ? Math.sin(rad) : Math.cos(rad)) * distance;
    start[0] += add ? ind0 : -ind0
    start[1] += add ? ind1 : -ind1;
    return start;
}
function drawFake() {
    fake = Local.GetFakeYaw();
    if (UI.IsHotkeyActive("WORLD", "Thirdperson")) {
        ori = Entity.GetRenderOrigin(Entity.GetLocalPlayer());
        ext = Render.WorldToScreen(rotate(true, true, [ori[0], ori[1], ori[2]], fake, 40));
        txt = Render.WorldToScreen(rotate(true, true, [ori[0], ori[1], ori[2]], fake, 45));
        ori = Render.WorldToScreen(ori);
        Render.Line(ori[0], ori[1], ext[0], ext[1], fSettings.color);
        Render.String(txt[0], txt[1], 2, "FAKE", [255, 255, 255, 255]);
    } else {
        deg = fake-Local.GetViewAngles()[1];
        a = rotate(false, false, [s[0]/2, s[1]/2], deg, fSettings.distance+fSettings.size);
        b = rotate(false, false, [a[0], a[1]], deg+30, -fSettings.size);
        c = rotate(false, false, [a[0], a[1]], deg-30, -fSettings.size);
        Render.Polygon([a, b, c], fSettings.color);
    }
}
function drawReal() {
    real = Local.GetRealYaw();
    if (UI.IsHotkeyActive("WORLD", "Thirdperson")) {
        ori = Entity.GetRenderOrigin(Entity.GetLocalPlayer());
        ext = Render.WorldToScreen(rotate(true, true, [ori[0], ori[1], ori[2]], real, 40));
        txt = Render.WorldToScreen(rotate(true, true, [ori[0], ori[1], ori[2]], real, 45));
        ori = Render.WorldToScreen(ori);
        Render.Line(ori[0], ori[1], ext[0], ext[1], rSettings.color);
        Render.String(txt[0], txt[1], 2, "REAL", [255, 255, 255, 255]);
    } else {
        deg = real-Local.GetViewAngles()[1];
        a = rotate(false, false, [s[0]/2, s[1]/2], deg, rSettings.distance+rSettings.size);
        b = rotate(false, false, [a[0], a[1]], deg+30, -rSettings.size);
        c = rotate(false, false, [a[0], a[1]], deg-30, -rSettings.size);
        Render.Polygon([a, b, c], rSettings.color);
    }
}
function indicators() {
    if (!Entity.IsAlive(Entity.GetLocalPlayer())) return;
    fSettings.enabled && (fSettings.third || !UI.IsHotkeyActive("WORLD", "Thirdperson")) && drawFake();
    rSettings.enabled && (rSettings.third || !UI.IsHotkeyActive("WORLD", "Thirdperson")) && drawReal();
}
//////////////////////////////////////////////////////////INDICATORS/////////////////////////////////////////////////////
Global.PrintColor([186, 235, 52, 255], "\n\n[discord.exration.com] Loaded Indicators! \n\n\n\n");
Global.RegisterCallback("Draw", "indicator");
Global.RegisterCallback("weapon_fire", "dt");
UI.AddSliderInt("                  ", 0, 0);
UI.AddLabel("           Indicators     ");
UI.AddCheckbox("LBY");
UI.AddCheckbox("Fake");
UI.AddCheckbox("Lag");
UI.AddCheckbox("Double Tap");
UI.AddCheckbox("Slow");
UI.AddCheckbox("Fake Duck");
UI.AddCheckbox("Auto Peek");
UI.AddCheckbox("Invert");
UI.AddCheckbox("Safe Point");
UI.AddCheckbox("Hitbox Override");
UI.AddCheckbox("Damage Override");
UI.AddCheckbox("Hide Shots");

const x = UI.AddSliderInt("Indicator - X", 0, Global.GetScreenSize()[0])
const y = UI.AddSliderInt("Indicator - Y", 0, Global.GetScreenSize()[1])

//Anti-aims
UI.AddLabel("                   AA indicator            ");
UI.AddSliderInt("Antiaim_x", 0, Global.GetScreenSize()[0]);
UI.AddSliderInt("Antiaim_y", 0, Global.GetScreenSize()[1]);

function in_bounds(vec, x, y, x2, y2) {
    return (vec[0] > x) && (vec[1] > y) && (vec[0] < x2) && (vec[1] < y2)
}

function draw_arc(x, y, radius, start_angle, percent, thickness, color) {
        var precision = (2 * Math.PI) / 30;
        var step = Math.PI / 180;
        var inner = radius - thickness;
        var end_angle = (start_angle + percent) * step;
        var start_angle = (start_angle * Math.PI) / 180;

        for (; radius > inner; --radius) {
            for (var angle = start_angle; angle < end_angle; angle += precision) {
                var cx = Math.round(x + radius * Math.cos(angle));
                var cy = Math.round(y + radius * Math.sin(angle));

                var cx2 = Math.round(x + radius * Math.cos(angle + precision));
                var cy2 = Math.round(y + radius * Math.sin(angle + precision));

                Render.Line(cx, cy, cx2, cy2, color);
            }
        }
}

function main_aa() {
    if (!World.GetServerString()) return;

    const x = UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Antiaim_x"),
        y = UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Antiaim_y");

    var font = Render.AddFont("Verdana", 7, 100);
    var RealYaw = Local.GetRealYaw();
    var FakeYaw = Local.GetFakeYaw();
    var delta = Math.min(Math.abs(RealYaw - FakeYaw) / 2, 60).toFixed(1);
    var safety = Math.min(Math.round(1.7 * Math.abs(delta)), 100);
    if (UI.IsHotkeyActive("Anti-Aim", "Fake angles", "Inverter")) {
        var side = "<";
    } else {
        var side = ">";
    }
    var text = "    FAKE (" + delta.toString() + "  ) | safety: " + safety.toString() + "% | side: " + side;
    var w = Render.TextSizeCustom(text, font)[0] + 8;

    Render.FilledRect(x - w, y, w, 2, [89, 89 + (delta / 2), 89 + (delta / 0.4), 255]);
    Render.FilledRect(x - w, y + 2, w, 18, [17, 17, 17, 255]);
    Render.StringCustom(x + 5 - w, y + 5, 0, text, [0, 0, 0, 180], font);
    Render.StringCustom(x + 4 - w, y + 4, 0, text, [255, 255, 255, 255], font);
    Render.Circle(x + 18 - w + Render.TextSizeCustom("FAKE (" + delta.toString(), font)[0], y + 8, 1, [255, 255, 255, 255]);
    draw_arc(x + 7 - w, y + 10, 5, 0, delta * 6, 2, [89, 119, 239, 255]);
    if (Global.IsKeyPressed(1) && UI.IsMenuOpen()) {
        const mouse_pos = Global.GetCursorPosition();
        if (in_bounds(mouse_pos, x - w, y, x + w, y + 30)) {
            UI.SetValue("Misc", "JAVASCRIPT", "Script items", "Antiaim_x", mouse_pos[0] + w / 2);
            UI.SetValue("Misc", "JAVASCRIPT", "Script items", "Antiaim_y", mouse_pos[1] - 20);
        }
    }
}
Global.RegisterCallback("Draw", "main_aa");


UI.AddSliderInt("                  ", 0, 0);


UI.AddDropdown( "           Clantags     ", [ "Disabled", "Nemesis", "PPhud FREE", "Fatality", "Neverlose", "BotLucky", "gamesense", "Gay.cc", "Pasted" ]);
var lasttime = 0;
function onRender( )
{
    var tag = UI.GetValue( "Script Items", "| Custom ClanTag |" );
    var time = parseInt((Globals.Curtime() * 3))
    if (time != lasttime)
    {
        if(tag == 0) { Local.SetClanTag(""); }
        if(tag == 1)
            {
            switch((time) % 11 )
            {

            case 1: { Local.SetClanTag("n3m3sis "); break; }
            case 2: { Local.SetClanTag("n3m3sis "); break; }
            case 3: { Local.SetClanTag("nemesis "); break; }
            case 4: { Local.SetClanTag("nemesis "); break; }
            case 5: { Local.SetClanTag("n3m3sis "); break; }
            case 6: { Local.SetClanTag("n3m3sis "); break; }
            case 7: { Local.SetClanTag("nemesis "); break; }
            case 8: { Local.SetClanTag("nemesis "); break; }
            case 9: { Local.SetClanTag("n3m3sis "); break; }
            case 10:{ Local.SetClanTag("n3m3sis "); break; }
			case 11:{ Local.SetClanTag("nemesis"); break; }
            case 12:{ Local.SetClanTag("nemesis"); break; }
            case 13:{ Local.SetClanTag("n3m3sis"); break; }
            case 14:{ Local.SetClanTag("n3m3sis"); break; }
            case 15:{ Local.SetClanTag("nemesis"); break; }
            case 16:{ Local.SetClanTag("nemesis"); break; }
            case 17:{ Local.SetClanTag("n3m3sis"); break; }
            case 18:{ Local.SetClanTag("n3m3sis"); break; }
			case 19:{ Local.SetClanTag("nemesis؜ "); break; }
			case 20:{ Local.SetClanTag("nemesis؜ "); break; }




            }
        }
    if(tag == 2)
            {
            switch((time) % 22)
            {
                case 0: { Local.SetClanTag("             "); break; }
                case 1: { Local.SetClanTag("p/           "); break; }
                case 2: { Local.SetClanTag("pp/          "); break; }
                case 3: { Local.SetClanTag("pph/         "); break; }
                case 4: { Local.SetClanTag("pphu/        "); break; }
                case 5: { Local.SetClanTag("pphud /      "); break; }
                case 6: { Local.SetClanTag("pphud F/     "); break; }
                case 7: { Local.SetClanTag("pphud FR/    "); break; }
                case 8: { Local.SetClanTag("pphud FRE/   "); break; }
                case 9: { Local.SetClanTag("pphud FREE   "); break; }
                case 10:{ Local.SetClanTag("pphud FREE   "); break; }
                case 11:{ Local.SetClanTag("pphud FREE   "); break; }
                case 12:{ Local.SetClanTag("pphud FRE\   "); break; }
                case 13:{ Local.SetClanTag("pphud FR\    "); break; }
                case 14:{ Local.SetClanTag("pphud F\     "); break; }
                case 15:{ Local.SetClanTag("pphud \      "); break; }
                case 16:{ Local.SetClanTag("pphu\        "); break; }
                case 17:{ Local.SetClanTag("pph\         "); break; }
                case 18:{ Local.SetClanTag("pp\          "); break; }
		        case 19:{ Local.SetClanTag("p\           "); break; }
		        case 20:{ Local.SetClanTag("\            "); break; }
		        case 21:{ Local.SetClanTag("             "); break; }




           
            }
        }
    
	
      if(tag == 3)
            {
            switch((time) % 20)
            {
                case 0: { Local.SetClanTag("   "); break; }
                case 1: { Local.SetClanTag("  f"); break; }
                case 2: { Local.SetClanTag(" fa"); break; }
                case 3: { Local.SetClanTag(" fat "); break; }
                case 4: { Local.SetClanTag(" fata "); break; }
                case 5: { Local.SetClanTag(" fatali "); break; }
				case 6: { Local.SetClanTag(" fatalit "); break; }
				case 7: { Local.SetClanTag(" fatality "); break; }
				case 8: { Local.SetClanTag(" fatality "); break; }
				case 9: { Local.SetClanTag(" fatality "); break; }
				case 10: { Local.SetClanTag(" fatality "); break; }
				case 11: { Local.SetClanTag(" fatality "); break; }
				case 12: { Local.SetClanTag(" fatality "); break; }
				case 13: { Local.SetClanTag(" fatalit "); break; }
				case 14: { Local.SetClanTag(" fatali "); break; }
				case 15: { Local.SetClanTag(" fatal "); break; }
				case 16: { Local.SetClanTag(" fata "); break; }
				case 17: { Local.SetClanTag(" fat "); break; }
				case 18: { Local.SetClanTag(" fa "); break; }
				case 19: { Local.SetClanTag(" f "); break; }
				case 20: { Local.SetClanTag("  "); break; }

            }
         }
		 
	  if(tag == 6)
		   {
           switch((time) % 27)
           {
			   	case 0: { Local.SetClanTag("                  "); break; }
				case 1: { Local.SetClanTag("                 g"); break; }
				case 2: { Local.SetClanTag("                ga"); break; }
				case 3: { Local.SetClanTag("               gam"); break; }
				case 4: { Local.SetClanTag("              game"); break; }
				case 5: { Local.SetClanTag("             games"); break; }
				case 6: { Local.SetClanTag("            gamese"); break; }
				case 7: { Local.SetClanTag("           gamesen"); break; }
				case 8: { Local.SetClanTag("          gamesens"); break; }
				case 9: { Local.SetClanTag("         gamesense"); break; }
				case 10:{ Local.SetClanTag("        gamesense "); break; }
				case 11:{ Local.SetClanTag("       gamesense  "); break; }
				case 12:{ Local.SetClanTag("      gamesense   "); break; }
				case 13:{ Local.SetClanTag("     gamesense    "); break; }
				case 14:{ Local.SetClanTag("    gamesense     "); break; }
				case 15:{ Local.SetClanTag("   gamesense      "); break; }
				case 16:{ Local.SetClanTag("  gamesense       "); break; }
				case 17:{ Local.SetClanTag(" gamesense        "); break; }
				case 18:{ Local.SetClanTag("gamesense         "); break; }
				case 19:{ Local.SetClanTag("amesense          "); break; }
				case 20:{ Local.SetClanTag("mesense           "); break; }
				case 22:{ Local.SetClanTag("esense            "); break; }
				case 23:{ Local.SetClanTag("sense             "); break; }
				case 24:{ Local.SetClanTag("sens              "); break; }
				case 25:{ Local.SetClanTag("sen               "); break; }
				case 26:{ Local.SetClanTag("se                "); break; }
				case 27:{ Local.SetClanTag("s                 "); break; }
				
	        }
         }
		 
      if(tag == 7)
            {
            switch((time) % 10)
            {
                case 0: { Local.SetClanTag("  G"); break; }
                case 1: { Local.SetClanTag(" Ga"); break; }
                case 2: { Local.SetClanTag(" Gay"); break; }
                case 3: { Local.SetClanTag(" Gay."); break; }
                case 4: { Local.SetClanTag(" Gay.c "); break; }
				case 5: { Local.SetClanTag(" Gay.cc "); break; }
				case 6: { Local.SetClanTag("Gay.c"); break; }
				case 7: { Local.SetClanTag("Gay."); break; }
				case 8: { Local.SetClanTag("Gay  "); break; }
				case 9: { Local.SetClanTag("Ga  "); break; }
				case 10: { Local.SetClanTag("G  "); break; }

            }
         }
		 
		if(tag == 8)
            {
            switch((time) % 25)
            {
                case 0: { Local.SetClanTag(" P"); break; }
                case 1: { Local.SetClanTag("Pa"); break; }
                case 2: { Local.SetClanTag("Pas"); break; }
                case 3: { Local.SetClanTag("Past"); break; }
                case 4: { Local.SetClanTag("Paste"); break; }
				case 5: { Local.SetClanTag("Pasted"); break; }
				case 6: { Local.SetClanTag("Pasted."); break; }
				case 7: { Local.SetClanTag("Pasted.w"); break; }
				case 8: { Local.SetClanTag("Pasted.wa"); break; }
				case 9: { Local.SetClanTag("Pasted.war"); break; }
				case 10: { Local.SetClanTag("Pasted.ware"); break; }
				case 11: { Local.SetClanTag("Pasted.ware"); break; }
				case 12: { Local.SetClanTag("Pasted.ware"); break; }
				case 13: { Local.SetClanTag("Pasted.war"); break; }
				case 14: { Local.SetClanTag("Pasted.wa"); break; }
				case 15: { Local.SetClanTag("Pasted.w"); break; }
				case 16: { Local.SetClanTag("Pasted."); break; }
				case 17: { Local.SetClanTag("Pasted"); break; }
				case 18: { Local.SetClanTag("Paste"); break; }
				case 19: { Local.SetClanTag("Past"); break; }
				case 20: { Local.SetClanTag("Pas"); break; }
				case 21: { Local.SetClanTag("Pa"); break; }
				case 22: { Local.SetClanTag("P "); break; }
				
            }
         }
		 
		if(tag == 5)
			{
           switch((time) % 60)
            {
			   	case 0: { Local.SetClanTag("      Luck"); break; }
				case 1: { Local.SetClanTag("      Lucky"); break; }
				case 2: { Local.SetClanTag("      LuckyC"); break; }
				case 3: { Local.SetClanTag("      LuckyCh"); break; }
				case 4:{Local.SetClanTag("      LuckyCh4");break; }
				case 5:{Local.SetClanTag("      LuckyCh4r");break;}
				case 6:{Local.SetClanTag("      LuckyCh4rm");break;}
				case 7:{Local.SetClanTag("     LuckyCh4rm$ ");break;}
				case 8:{Local.SetClanTag("    LuckyCh4rm$  ");break;}
				case 9:{Local.SetClanTag("   LuckyCh4rm$   ");break;}
				case 10:{Local.SetClanTag("  LuckyCh4rm$    ");break;}
				case 11:{Local.SetClanTag(" uckyCh4rm$     ");break;}
				case 12:{Local.SetClanTag("ckyCh4rm$      ");break;}
				case 13:{Local.SetClanTag("kyCh4rm$      ");break;}
				case 14:{Local.SetClanTag("yCh4rm$      ");break;}
				case 15:{Local.SetClanTag("Ch4rm$      ");break;}
				case 16:{Local.SetClanTag("h4rm$      ");break;}
				case 17:{Local.SetClanTag("4rm$      ");break;}
				case 18:{Local.SetClanTag(" rm$ L    ");break;}
				case 19:{Local.SetClanTag("  m$  Lu   ");break;}
				case 20:{Local.SetClanTag("  $   Luc  ");break;}
				case 21:{ Local.SetClanTag("     Luck ");break;}
				case 22:{Local.SetClanTag("      Lucky");break;}
				case 23:{Local.SetClanTag("      LuckyC");break;}
				case 24:{Local.SetClanTag("      LuckyCh");break;}
				case 25:{Local.SetClanTag("      LuckyCha");break;}
				case 26:{Local.SetClanTag("      LuckyChar");break;}
				case 27:{Local.SetClanTag("      LuckyCharm");break;}
				case 28:{Local.SetClanTag("     LuckyCharms ");break;}
				case 29:{Local.SetClanTag("    LuckyCharms  ");break;}
				case 30:{Local.SetClanTag("   LuckyCharms   ");break;}
				case 31:{Local.SetClanTag("  LuckyCharms    ");break;}
				case 32:{Local.SetClanTag(" uckyCharms     ");break;}
				case 33:{Local.SetClanTag("ckyCharms      ");break;}
				case 34:{Local.SetClanTag("kyCharms      ");break;}
				case 35:{Local.SetClanTag("yCharms      ");break;}
				case 36:{Local.SetClanTag("Charms      ");break;}
				case 37:{Local.SetClanTag("harms      ");break;}
				case 38:{Local.SetClanTag("arms      ");break;}
				case 39:{Local.SetClanTag("rms L     ");break;}
				case 40:{Local.SetClanTag(" ms  Lu    ");break;}
				case 41:{Local.SetClanTag("  s  Luc   ");break;}
				
	        }
         }
		 
      if(tag == 4)
            {
            switch((time) % 55)
            {
				case 0: Local.SetClanTag(" "); break;
				case 1: Local.SetClanTag(" |"); break;
				case 2: Local.SetClanTag(" |\\ "); break;
				case 3: Local.SetClanTag(" |\\|"); break;
				case 4: Local.SetClanTag(" N "); break;
				case 5: Local.SetClanTag(" N3 "); break;
				case 6: Local.SetClanTag(" Ne "); break;
				case 7: Local.SetClanTag(" Ne\\ "); break;
				case 8: Local.SetClanTag(" Ne\\/ "); break;
				case 9: Local.SetClanTag(" Nev "); break;
				case 10: Local.SetClanTag(" Nev3 "); break;
				case 11: Local.SetClanTag(" Neve "); break;
				case 12: Local.SetClanTag(" Neve| "); break;
				case 13: Local.SetClanTag(" Neve|2 "); break;
				case 14: Local.SetClanTag(" Never| "); break;
				case 15: Local.SetClanTag(" Neverl "); break;
				case 16: Local.SetClanTag(" Neverl4 "); break;
				case 17: Local.SetClanTag(" Neverlo "); break;
				case 18: Local.SetClanTag(" Neverlos| "); break;
				case 19: Local.SetClanTag(" Neverlos|D "); break;
				case 20: Local.SetClanTag(" Neverlos "); break;
				case 21: Local.SetClanTag(" Neverlose "); break;
				case 22: Local.SetClanTag(" Neverlose. "); break;
				case 23: Local.SetClanTag(" Neverlose.< "); break;
				case 24: Local.SetClanTag(" Neverlose.c "); break;
				case 25: Local.SetClanTag(" Neverlose.c< "); break;
				case 26: Local.SetClanTag(" Neverlose.cc "); break;
				case 27: Local.SetClanTag(" Neverlose.cc "); break;
				case 28: Local.SetClanTag(" Neverlose.c< "); break;
				case 29: Local.SetClanTag(" Neverlose.c "); break;
				case 30: Local.SetClanTag(" Neverlose.< "); break;
				case 31: Local.SetClanTag(" Neverlose. "); break;
				case 32: Local.SetClanTag(" Neverlose "); break;
				case 33: Local.SetClanTag(" Neverlo|D "); break;
				case 34: Local.SetClanTag(" Neverlo| "); break;
				case 35: Local.SetClanTag(" Neverlo_ "); break;
				case 36: Local.SetClanTag(" Neverl4 "); break;
				case 37: Local.SetClanTag(" Nevelo "); break;
				case 38: Local.SetClanTag(" Neverl_ "); break;
				case 39: Local.SetClanTag(" Never| "); break;
				case 40: Local.SetClanTag(" Never_ "); break;
				case 41: Local.SetClanTag(" Neve|2 "); break;
				case 42: Local.SetClanTag(" Neve| "); break;
				case 43: Local.SetClanTag(" Neve_ "); break;
				case 44: Local.SetClanTag(" Nev3 "); break;
				case 45: Local.SetClanTag(" Nev_ "); break;
				case 46: Local.SetClanTag(" Ne\\/ "); break;
				case 47: Local.SetClanTag(" Ne\\ "); break;
				case 48: Local.SetClanTag(" Ne_ "); break;
				case 49: Local.SetClanTag(" N3 "); break;
				case 50: Local.SetClanTag(" N_ "); break;
				case 51: Local.SetClanTag(" |\\|"); break;
				case 52: Local.SetClanTag(" |\\ "); break;
				case 53: Local.SetClanTag(" |"); break;
				case 54: Local.SetClanTag(" "); break;

            }
         }
	

	}
    lasttime = time;
}
Cheat.RegisterCallback("Draw", "onRender");


UI.AddSliderInt("                  ", 0, 0);
UI.AddLabel("           Faster Autobuy     ");


var run = false;
var estimate = 0;
var firstBuy = 0;
var alias = [
    ["awp"],
    ["ssg08"],
    ["scar20", "g3sg1"]
]

function roundEnded() {
    run = true;
    estimate = Globals.Curtime()+Convar.GetInt("mp_round_restart_delay");
    firstBuy = 0;
}

function purchase(index) {
    alias[index].forEach(function(v) { Cheat.ExecuteCommand("buy "+v); })
    run = false;
}

function onDraw() {
    run && Globals.Curtime()+(Local.Latency()/1000) >= estimate && purchase(UI.GetValue.apply(this, dropdown));
}

function purchased() {
    if (firstBuy == 0) firstBuy = Globals.Curtime()-estimate;
    if (!Entity.GetEntityFromUserID(Event.GetInt("userid")) || firstBuy == -1) return;

    Cheat.Print("The first item of the round was purchased at " + firstBuy + "s, you purchased at " + (Globals.Curtime()-estimate) + "s.\n");
    firstBuy = -1;
}

var dropdown = UI.AddDropdown("Fastest Autobuy", ["AWP", "Scout", "Auto"]);

Cheat.RegisterCallback("round_end", "roundEnded");
Cheat.RegisterCallback("Draw", "onDraw");
Cheat.RegisterCallback("item_purchase", "purchased");

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

var should_draw = false;
var started_drawing = 0;
var screen_size = Render.GetScreenSize( );
var alpha = 0;

function event_player_hurt( ) {
    target = Event.GetInt( "userid" );
    target_id = Entity.GetEntityFromUserID( target );
    attacker = Event.GetInt( "attacker" );
    attacker_id = Entity.GetEntityFromUserID( attacker );

    if ( ( Entity.GetLocalPlayer( ) === target_id ) || ( Entity.GetLocalPlayer( ) !== attacker_id ) )
        return;

    should_draw = true;
    started_drawing = Globals.Tickcount( );
}

function draw( ) {
    if ( !should_draw )
        return;
    if ( started_drawing + 180 < Globals.Tickcount( ) )
        return;

    alpha = ( started_drawing + 180 ) - Globals.Tickcount( );
   
    if ( alpha > 255 )
        alpha = 255;
    if ( alpha < 0 )
        alpha = 0;

    Render.Line( //top left
        screen_size[0] / 2 - 12, //x
        screen_size[1] / 2 - 12,  //y
        screen_size[0] / 2 - 4,   //x2
        screen_size[1] / 2 - 4,   //y2
        [ 255, 255, 255, alpha ] );

    Render.Line( //bottom right
        screen_size[0] / 2 + 12, //x
        screen_size[1] / 2 + 12,  //y
        screen_size[0] / 2 + 4,   //x2
        screen_size[1] / 2 + 4,   //y2
        [ 255, 255, 255, alpha ] );

    Render.Line( //top right
        screen_size[0] / 2 + 12, //x
        screen_size[1] / 2 - 12,  //y
        screen_size[0] / 2 + 4,   //x2
        screen_size[1] / 2 - 4,   //y2
        [ 255, 255, 255, alpha ] );

    Render.Line( //bottom left
        screen_size[0] / 2 - 12, //x
        screen_size[1] / 2 + 12,  //y
        screen_size[0] / 2 - 4,   //x2
        screen_size[1] / 2 + 4,   //y2
        [ 255, 255, 255, alpha ] );
}
Cheat.RegisterCallback( "Draw", "draw" );
Cheat.RegisterCallback( "player_hurt", "event_player_hurt" );