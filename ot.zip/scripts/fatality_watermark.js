UI.AddSliderInt( "                Fatality watermark  ", 0,0 );

function HSVtoRGB(h, s, v)
{
    var r, g, b, i, f, p, q, t;

    i = Math.floor(h * 6);
    f = h * 6 - i;
    p = v * (1 - s);
    q = v * (1 - f * s);
    t = v * (1 - (1 - f) * s);

    switch (i % 6)
    {
        case 0: r = v, g = t, b = p; break;
        case 1: r = q, g = v, b = p; break;
        case 2: r = p, g = v, b = t; break;
        case 3: r = p, g = q, b = v; break;
        case 4: r = t, g = p, b = v; break;
        case 5: r = v, g = p, b = q; break;
    }

    return { r: Math.round(r * 255), g: Math.round(g * 255), b: Math.round(b * 255) };
}
function hsv_to_rgb(h, s, v)
{
    var r, g, b, i, f, p, q, t;
    return { r: Math.round(r * 255), g: Math.round(g * 255), b: Math.round(b * 255) };
}

function getCustomValue(xy) {
var value = UI.GetValue("MISC", "JAVASCRIPT", "Script items", xy);
return value;}
var position = {
  x1: 0,
  y1: 0
}

function draw_fatality_rect(x, y, width, height)
{
	  Render.FilledRect( x + 42, y - 1, width+ -81, height + 20, [ 0, 3, 56, 255 ] ); //light
	  Render.FilledRect( x + 45.5, y + 2, width+ -87, height + 14, [ 0, 3, 28, 255 ] ); //light
	  Render.FilledRect( x + 49, y + 6, width+ -95, height + 6, [ 0, 3, 56, 255 ] ); //dark
	  Render.FilledRect( x + 52, y + 9, width+ -101, height, [ 0, 3, 28, 255 ] ); //light in
}

function draw_fatality_rect2(x2, y2, width2, height2)
{
        var rgbcolor = hsv_to_rgb(Global.Realtime() * UI.GetValue("MISC", "JAVASCRIPT", "Script Items", "Gradient Speed"), 1, 1);

      Render.FilledRect( x2 + 42, y2 - 1, width2+ 66, height2 + 20, [ 0, 3, 56, 255 ] ); //light
	  Render.FilledRect( x2 + 45.5, y2 + 2, width2+ 60, height2 + 14, [ 0, 3, 28, 255 ] ); //light
	  Render.FilledRect( x2 + 49, y2 + 6, width2+ 52, height2 + 6, [ 0, 3, 56, 255 ] ); //dark
	  Render.FilledRect( x2 + 52, y2 + 9, width2+ 46, height2 , [ 0, 3, 28, 255 ] ); //light in
}

function draw_fatality_rect3(x3, y3, width3, height3)
{
	  Render.FilledRect( x3 + 42, y3 - 1, width3 + -21, height3 + 20, [ 0, 3, 56, 255 ] ); //light
	  Render.FilledRect( x3 + 45.5, y3 + 2, width3 + -27, height3 + 14, [ 0, 3, 28, 255 ] ); //light
	  Render.FilledRect( x3 + 49, y3 + 6, width3 + -35, height3 + 6, [ 0, 3, 56, 255 ] ); //dark
	  Render.FilledRect( x3 + 52, y3 + 9, width3 + -41, height3, [ 0, 3, 28, 255 ] ); //light in

}
function draw_gs_watermark()
{
  var rgbcolor = hsv_to_rgb(Global.Realtime() * UI.GetValue("MISC", "JAVASCRIPT", "Script Items", "Gradient Speed"), 1, 1);
  var fps1 = 1 / Global.Frametime()
  var fps2 = Math.floor(fps1);
  averagefps = (fps1 + fps2) / 2;
  var rgb = hsv_to_rgb(Global.Tickcount() % 350 / 350,1,1);
  var watermark_name = Entity.GetName(Entity.GetLocalPlayer( )); 
  const now = new Date();
  const hours = now.getHours(), mins = now.getMinutes(), secs = now.getSeconds();
  const time = (hours < 10 ? "0" + hours : hours) + ":" + (mins < 10 ? "0" + mins : mins) + ":" + (secs < 10 ? "0" + secs : secs);
  var ping = Math.round(Local.Latency( ) * 1000 - 16)
  const player = Entity.GetLocalPlayer();


    const vec = Entity.GetProp(player, "CBasePlayer", "m_vecVelocity[0]");
    const velocity = Math.sqrt(vec[0] * vec[0] + vec[1] * vec[1]);
    x1 = getCustomValue("X");
    y1 = getCustomValue("Y");
    ////////////////////////////////fatality1rect////////////////////////////
    draw_fatality_rect(x1 +60, y1, 140, 35);
	Render.String( x1 + 122, y1 + 10, 0, "F", [ 244, 64, 132, 255 ], 24 ); // logo
    ////////////////////////////////////////////////////////////////////////	
	////////////////////////////////fatality2rect////////////////////////////
    draw_fatality_rect2(x1 - 150, y1, 140, 35);
	Render.String( x1 + 3, y1 + 15, 0, Math.round(velocity).toString(), [ 166, 228, 0, 255], 12 );
	Render.String( x1 + -47, y1 + 15, 0, "" + ping, [ 166, 228, 0, 255], 12 ); //ping
	Render.String( x1 + -92, y1 + 15, 0, "" + fps2, [ 166, 228, 0, 255], 12 ); //fps
    Render.String( x1 + 57, y1 + 15, 0, "" + Globals.Tickrate(), [ 166, 228, 0, 255], 12 ); //tick
    Render.String( x1 + -90, y1 + 33, 0, "fps       ping      speed     tick", [ 255, 255, 255, 255], 8 ); //text
    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////fatality3rect//////////////////////////// 
    draw_fatality_rect3(x1 - 273, y1, 140, 35);
	Render.String( x1 + -208, y1 + 15, 0, "" + time, [ 0, 142, 222, 255], 12 ); //time
    Render.String( x1 + -206, y1 + 33, 0, "current time", [ 255, 255, 255, 255], 8 ); //text	
	////////////////////////////////////////////////////////////////////////	

}


function main()
{
        var screensize = Global.GetScreenSize();
        UI.AddSliderInt("X", 0, screensize[0]);
        UI.AddSliderInt("Y", 0, screensize[0]);
}
main()

Global.RegisterCallback("Draw", "draw_gs_watermark")
