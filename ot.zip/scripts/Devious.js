UI.AddLabel("-------------ANTI-AIM-----------------");
UI.AddDropdown( "Desync Types", ["Disabled", "Static", "Jitter", "Custom", "Dynamic", "Low Delta", "Anti Bruteforce (WIP)", "Randomized"]);
UI.AddHotkey("Invert AA");
UI.AddSliderFloat("Switch speed (seconds)", 0, 10);
UI.AddSliderInt("Min Fake 1", -60, 60);
UI.AddSliderInt("Max Fake 1", -60, 60);
UI.AddSliderInt("Min Fake 2", -60, 60);
UI.AddSliderInt("Max Fake 2", -60, 60);
UI.AddDropdown("LBY Modes", ["Normal", "Opposite", "Jitter", "Switch", "180", "Dynamic", "Custom", "Randomized"]);
UI.AddSliderFloat("LBY jitter speed (seconds)", 0, 10);
UI.AddSliderInt("Min LBY 1", -180, 180);
UI.AddSliderInt("Max LBY 1", -180, 180);
UI.AddSliderInt("Min LBY 2", -180, 180);
UI.AddSliderInt("Max LBY 2", -180, 180);
UI.AddCheckbox("Onshot AA");
UI.AddSliderInt("Fake on shot", -60, 60);
UI.AddSliderInt("Real on shot", -60, 60);
UI.AddCheckbox("Flip on shot");
UI.AddDropdown("LBY on Shot", ["180", "Opposite", "Left", "Right", "Jitter"]);
UI.AddDropdown("Fakelag Types", ["Disabled", "Send Limit", "Dynamic"]);
UI.AddSliderInt("Send Limit", 0, 16)
UI.AddSliderInt("Choke Limit", 0, 16)
UI.AddLabel("-------------RAGEBOT-----------------");
UI.AddCheckbox("Better DT Recharge");
UI.AddCheckbox("Force Safepoint on Limbs");
UI.AddCheckbox("Force Safepoint on Head");
UI.AddCheckbox("Dynamic Min Damage");
UI.AddCheckbox("Override Min Damage");
UI.AddSliderInt("Override Min Damage on Health", 0, 100);
UI.AddSliderInt("Min Damage", 0, 100);
UI.AddCheckbox("Noscope Hitchance");
UI.AddSliderInt("Hitchance", 0, 100);
UI.AddLabel("-------------VISUAL------------------");

side = 1

var tickcount = 0

var flip = false

function randomIntFrom(min,max)
{
    return Math.floor(Math.random()*(max-min+1)+min);
}

function getVelocity()
{
    velocity = Entity.GetProp(Entity.GetLocalPlayer(), "CBasePlayer", "m_vecVelocity[0]");
    speed = Math.sqrt(velocity[0] * velocity[0] + velocity[1] * velocity[1]);
    return speed;
}


function fire()
{
    var ent = Entity.GetEntityFromUserID(Event.GetInt("userid"))
    if(ent != Entity.GetLocalPlayer())
        return
    weaponfire = false
}

function radian(degree)
{
    return degree * Math.PI / 180.0;
}

function Flip()
{
    UI.ToggleHotkey("Script items", "Invert AA");
}

var delay = 1 / Globals.Tickrate();

var target = 0

var globalTime = Globals.Realtime();

var screen_size = Global.GetScreenSize();

var isInverted;

var drawLeft = 0;

var drawRight = 0;

var drawBack = 1;

var tickcount = 0

var flip = false

real = 0

fake = 0

lby = 0


function fakelag()
{
	fakelag = UI.GetValue("Anti-Aim", "Fake-Lag", "Limit")
	
	fakelagMode = UI.GetValue("Fakelag Types")
	
    var send = UI.GetValue("Send Limit")
	
    var choke = UI.GetValue("Choke Limit")
	
	if(fakelagMode == 0)
	{
		return;
	}
    else if (fakelagMode == 1)
    {
    	if(tickcount >= choke && !flip)
    	{
        	flip = true
        	tickcount = 0
    	}
    	if(tickcount >= send && flip)
    	{
    	    flip = false
   	    	tickcount = 0
   		}
    	UI.SetValue("Anti-Aim", "Fake-Lag", "Limit", !flip ? choke : 0)
    	tickcount++
    }
	else if (fakelagMode == 2)
	{
		if(getVelocity > 3)
		{
			fakelag = randomIntFrom(0, 2);
			if(getVelocity > 100)
			{
				fakelag = randomIntFrom(9, 11);
				if(getVelocity > 150)
				{
					fakelag = randomIntFrom(6, 7);
					if(getVelocity > 252)
					{
						fakelag = randomIntFrom(12, 16);
					}
				}
			}
		}
	}
}
function roundstart()
{
    tickcount = 0
}


function lbyModes()
{
	side1 = 1
	
	cusSpeed = UI.GetValue("LBY jitter speed (seconds)")

	cusLBY1 = UI.GetValue("Min LBY 1")

	cusLBY2 = UI.GetValue("Max LBY 1")

	cusLBY3 = UI.GetValue("Min LBY 2")

	cusLBY4 = UI.GetValue("Max LBY 2")
	
	lbyMode = UI.GetValue("LBY Modes")
	
	var sway = lby += 1

	var sway2 = lby -= 1

	if (lbyMode == 0)
	{
		if(UI.IsHotkeyActive("Invert AA"))
		{
			lby = -30;
		}
		else
		{
			lby = 30
		}
	}
	else if (lbyMode == 1)
    {
		if(UI.IsHotkeyActive("Invert AA"))
		{
			if(real < 0)
			{
				lby = real * 3;
			}
			if(real > 0)
			{
				lby = real * -3;
			}
		}
		else
		{
			if(real < 0)
			{
				lby = real * -3;
			}
			if(real > 0)
			{
				lby = real * 3;
			}
		}
    }  
	else if (lbyMode == 2)
    {
    	if(UI.IsHotkeyActive("Invert AA"))
    	{
    		lby = randomIntFrom(-180, -30);
    	}
    	else
    	{
    		lby = randomIntFrom(30, 180);
    	}
    } 
	else if (lbyMode == 3)
    {
		if(UI.IsHotkeyActive("Invert AA"))
		{
			if(Globals.Realtime() > globalTime + 0.1)
			{
				globalTime = Globals.Realtime();
				if(side = 1)
				lby = -110;
				side = 0
			}
			else
			{
				lby = 110;
				side = 1
			}
		}
		else
		{
			if(Globals.Realtime() > globalTime + 0.1)
			{
				globalTime = Globals.Realtime();
				if(side = 1)
				lby = 110;
				side = 0
			}
			else
			{
				lby = -110;
				side = 1
			}
		}
			
    } 
	else if (lbyMode == 4)
    {
		if(UI.IsHotkeyActive("Invert AA"))
		{
			lby = 180;
		}
		else
		{
			lby = 0
		}
    } 
	else if (lbyMode == 5)
	{
		if(UI.IsHotkeyActive("Invert AA"))
		{
			if (getVelocity() > 2)
			{
				lby = -110;
			}
			else
			{
				lby = -30;
			}
		}
		else
		{
			if (getVelocity() > 2)
			{
				lby = 110;
			}
			else
			{
				lby = 30;
			}
		}
	}
	else if (lbyMode == 6)
	{
		if(Globals.Realtime() > globalTime + cusSpeed)
		{
			globalTime = Globals.Realtime();
			if(side1 = 1)
			lby = randomIntFrom(cusLBY1, cusLBY2);
			side1 = 0
		}
		else
		{
			lby = randomIntFrom(cusLBY3, cusLBY4);
			side1 = 1
		}
	}
	else if(lbyMode == 7)
	{
		if(UI.IsHotkeyActive("Invert AA"))
		{
			{
				lby = randomIntFrom(30, 110);
			}

		}
		else
		{
			{
				lby = randomIntFrom(-30, -110);
			}
		}
	}
}


function ragebotFeatures()
{
	var localplayer = Entity.GetLocalPlayer();
	
	var localplayerweapon = Entity.GetWeapon(localplayer);
	
	var weaponname = Entity.GetName(localplayerweapon);
	
	inaccuracy = Local.GetInaccuracy();
	
	spread = Local.GetSpread();
	
	var target = Ragebot.GetTarget()
	
    var health = Entity.GetProp(target, "CBasePlayer", "m_iHealth");
	
    var active = UI.IsHotkeyActive("Rage", "GENERAL", "Exploits", "Doubletap") && charge == 1
	
	doubletap = UI.GetValue("Script items", "Better DT")
	
	overridemin = UI.GetValue("Script items", "Override Min Damage on Health")
	
	minoverride = UI.GetValue("Script items", "Min Damage")

	isScoped = Entity.GetProp(localplayer, "CCSPlayer", "m_bIsScoped")

	noscopeHC = UI.GetValue("Script items", "Hitchance")

	if(UI.GetValue("Force Safepoint on Limbs"))
	{
		Ragebot.ForceHitboxSafety(7, 8, 9, 10 ,11 ,12)
	}
	if(UI.GetValue("Force Safepoint on Head"))
	{
		Ragebot.ForceHitboxSafety(0)
	}
	if(UI.GetValue("Better DT Recharge"))
	{
		if(inaccuracy > 0.3 && spread > 0.3)
		{
			Exploit.DisableRecharge()
		}
		else
		{
			Exploit.EnableRecharge()
		}
	}
	if(UI.GetValue("Script items", "Dynamic Min Damage"))
	{
		if(active > 0.95 && (weaponname == "scar 20" || weaponname == "g3sg1") && Entity.IsAlive(target) && Entity.IsValid(target))
		{
			Ragebot.OverrideMinimumDamage((health / 2) + 3)
		}
		else if(inaccuracy > 0.4 && spread > 0.5 && (weaponname == "scar 20" || weaponname == "g3sg1") && Entity.IsAlive(target) && Entity.IsValid(target))
		{
			Ragebot.OverrideMinimumDamage((health / 3) + 10)
		}
		else if(inaccuracy > 0.15 && spread > 0.15 && (weaponname == "scar 20" || weaponname == "g3sg1") && Entity.IsAlive(target) && Entity.IsValid(target))
		{
			Ragebot.OverrideMinimumDamage((health / 2) + 3)
		}
		else if(health < 80 && (weaponname == "scar 20" || weaponname == "g3sg1") && Entity.IsAlive(target) && Entity.IsValid(target))
		{
			Ragebot.OverrideMinimumDamage((health / 2) + 3)
		}
		else if(health < 40 && (weaponname == "scar 20" || weaponname == "g3sg1") && Entity.IsAlive(target) && Entity.IsValid(target))
		{
			Ragebot.OverrideMinimumDamage(health + 3)
		}
		else if(inaccuracy > 0.5 && spread > 0.5 && weaponname == "r8 revolver" && Entity.IsAlive(target) && Entity.IsValid(target))
		{
            Ragebot.OverrideMinimumDamage(health / 2)
		}
		else if(inaccuracy > 0.15 && spread > 0.15 && weaponname == "r8 revolver" && Entity.IsAlive(target) && Entity.IsValid(target))
		{
			Ragebot.OverrideMinimumDamage(health + 1)
		}
		else if(health < 65 && weaponname == "r8 revolver" && Entity.IsAlive(target) && Entity.IsValid(target))
		{
			Ragebot.OverrideMinimumDamage(health + 1)
		}
		else if(inaccuracy > 0.4 && spread > 0.4 && (weaponname == "glock 18" || weaponname == "usp-s") && Entity.IsAlive(target) && Entity.IsValid(target))
		{
			Ragebot.OverrideMinimumDamage(health / 4)
		}
		else if(inaccuracy > 0.2 && spread > 0.2 && (weaponname == "glock 18" || weaponname == "usp-s") && Entity.IsAlive(target) && Entity.IsValid(target))
		{
			Ragebot.OverrideMinimumDamage(health / 2)
		}
		else if(inaccuracy > 0.4 && spread > 0.4 && (weaponname == "awp") && Entity.IsAlive(target) && Entity.IsValid(target))
		{
			Ragebot.OverrideMinimumDamage(health + 1)
		}
		else if(inaccuracy > 0.2 && spread > 0.2 && (weaponname == "awp") && Entity.IsAlive(target) && Entity.IsValid(target))
		{
			Ragebot.OverrideMinimumDamage(health + 3)
		}
		else if(inaccuracy > 0.4 && spread > 0.4 && (weaponname == "ssg08") && Entity.IsAlive(target) && Entity.IsValid(target))
		{
			Ragebot.OverrideMinimumDamage(health)
		}
		else if(inaccuracy > 0.1 && spread > 0.1 && (weaponname == "ssg08") && Entity.IsAlive(target) && Entity.IsValid(target))
		{
			Ragebot.OverrideMinimumDamage(health / 2)
		}
		else if(health < 91 && (weaponname == "ssg08") && Entity.IsAlive(target) && Entity.IsValid(target))
		{
			Ragebot.OverrideMinimumDamage(health + 1)
		}
	}
	if(UI.GetValue("Override Min Damage"))
	{
		if(health > overridemin)
		{
			if(weaponname == "glock 18" || weaponname == "dual berretas")
			{
				Ragebot.OverrideMinimumDamage(UI.GetValue("Rage", "PISTOL", "Targeting", "Minimum damage"))
			}
			if(weaponname == "r8 revolver" || weaponname == "deagle")
			{
				Ragebot.OverrideMinimumDamage(UI.GetValue("Rage", "HEAVY PISTOL", "Targeting", "Minimum damage"))
			}
			if(weaponname == "ssg08")
			{
				Ragebot.OverrideMinimumDamage(UI.GetValue("Rage", "SCOUT", "Targeting", "Minimum damage"))
			}
			if(weaponname == "awp")
			{
				Ragebot.OverrideMinimumDamage(UI.GetValue("Rage", "AWP", "Targeting", "Minimum damage"))
			}
			if(weaponname == "scar 20" || weaponname == "g3sg1")
			{
				Ragebot.OverrideMinimumDamage(UI.GetValue("Rage", "AUTOSNIPER", "Targeting", "Minimum damage"))
			}
		}
		else
		{
			Ragebot.OverrideMinimumDamage(minoverride)
		}
	}
	if(UI.GetValue("Script items", "Noscope Hitchance"))
	{
		if(!isScoped)
		{
			Ragebot.ForceTargetHitchance(target, noscopeHC)
		}
	}
}


function setOffsets()
{
	side2 = 1
	
	realSpeed = UI.GetValue("Switch speed (seconds)")

	cusReal1 = UI.GetValue("Min Fake 1")

	cusReal2 = UI.GetValue("Max Fake 1")

	cusReal3 = UI.GetValue("Min Fake 2")

	cusReal4 = UI.GetValue("Max Fake 2")
	
	var sway3 = real += 1

	var sway4 = real -= 1
	
	realMode = UI.GetValue("Desync Types")
	
	if(realMode == 0)
	{
	}
	else if(realMode == 1)
	{
		if(UI.GetValue("Invert AA"))
		{
			if (getVelocity() > 2)
			{
				real = 57;
				fake = -10;
			}
			else
			{
				real = 30;
				fake = -10;
			}
		}
		else
		{
			if (getVelocity() > 2)
			{
				real = -57;
				fake = 10;
			}
			else
			{
				real = -30;
				fake = 10;
			}
		}
	}
	else if(realMode == 2)
	{
		if (Globals.Realtime() > globalTime + 0)
		{
			globalTime = Globals.Realtime();
			if (fake < 0)
			{
				fake = randomIntFrom(15, 17);
			}
			else
			{
				fake = randomIntFrom(-17, -15);
			}
		}
		if(UI.GetValue("Invert AA"))
		{
			real = randomIntFrom(38, 60);
		}
		else
		{
			real = randomIntFrom(-60, -38);
		}
	}
	else if(realMode == 3)
	{
		if(Globals.Realtime() > globalTime + realSpeed)
		{
			globalTime = Globals.Realtime();
			if(side2 = 1)
			real = randomIntFrom(cusReal1, cusReal2);
			side2 = 0
		}
		else
		{
			real = randomIntFrom(cusReal3, cusReal4);
			side2 = 1
		}
	}		
	else if(realMode == 4)
	{
		if(UI.GetValue("Invert AA"))
		{
			if(getVelocity > 3)
			{
				if(getVelocity > 252)
				{
					real = randomIntFrom(50, 20)
					fake = randomIntFrom(-10, -20)
				}
				real = randomIntFrom(-58, -48);
				fake = -30;
			}
			else
			{
				real = randomIntFrom(-48, -38);
				fake = -10;
			}
		}
		else
		{
			if(getVelocity > 3)
			{
				if(getVelocity > 252)
				{
					real = randomIntFrom(-50, -20)
					fake = randomIntFrom(10, 20)
				}
				real = randomIntFrom(58, 48);
				fake = 30;
			}
			else
			{
				real = randomIntFrom(48, 38);
				fake = 10;
			}
		}
	}
	else if(realMode == 5)
	{
		if(UI.GetValue("Invert AA"))
		{
			if(getVelocity > 3)
			{
				real = randomIntFrom(-60, -57);
				fake = -4;
			}
			else
			{
				real = randomIntFrom(-40, -38);
				fake = -10;
			}
		}
		else
		{
			if(getVelocity > 3)
			{
				real = randomIntFrom(57, 60);
				fake = 4;
			}
			else
			{
				real = randomIntFrom(38, 40);
				fake = 10;
			}
		}
	}
	else if(realMode == 6)
	{
		
	}
	else if(realMode == 7)
	{
		if(UI.IsHotkeyActive("Invert AA"))
		{
			real = getrandomIntFrom(-60, -40);
		}
		else
		{
			real = getrandomIntFrom(40, 60);
		}
	}
}
function roundstart()
{
    tickcount = 0
}


function commandHandler()
{
	var dropdownValue = UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Desync Types");
  
	if (dropdownValue == 0)
	{
		AntiAim.SetOverride(0);
	}
		setOffsets();
		lbyModes();
		AntiAim.SetOverride(1);
		AntiAim.SetRealOffset(real);
		AntiAim.SetFakeOffset(fake);
		AntiAim.SetLBYOffset(lby);
}


function onshotAA()
{
	var fSpeed = 10
	var sSpeed = 10
	var bSpeed = 10
	var lbyShot = UI.GetValue("LBY on Shot")
	if(UI.GetValue("Onshot AA"))
	{
		if (!weaponfire)
		{
			UI.ToggleHotkey("Invert AA");
			
			real = UI.GetValue("Fake on shot");
			
			fake = UI.GetValue("Real on shot");
			
			ros = UI.GetValue("Fake on shot");
			
			fos = UI.GetValue("Real on shot");
			
			if(UI.GetValue("Flip on shot"))
			{
				UI.SetValue("Real on shot", fos * -1);
				UI.SetValue("Fake on shot", ros * -1);
			}
			if(lbyShot == 0)
			{
				lby = 180
			}
			else if(lbyShot == 1)
			{
				if(real > 0)
				{
					lby = -110
				}
				else
				{
					lby = 110
				}
			}
			else if(lbyShot == 2)
			{
				lby = -110
			}
			else if(lbyShot == 3)
			{
				lby = 110
			}
			else if(lbyShot == 4)
			{
				if(real > 0)
				{
					lby = randomIntFrom(-180, -30);
				}
				else
				{
					lby = randomIntFrom(30, 180);
				}
			}
			weaponfire = true
		}
    }
	else
	{
	}
}


function menu()
{
	lbyMode = UI.GetValue("LBY Modes")
	
	realMode = UI.GetValue("Desync Types")
	
	if(UI.GetValue("Override Min Damage"))
	{
		UI.SetEnabled("Override Min Damage on Health", true)
		UI.SetEnabled("Min Damage", true)
	}
	else
	{
		UI.SetEnabled("Override Min Damage on Health", false)
		UI.SetEnabled("Min Damage", false)
	}

	if(!UI.GetValue("Script items", "Desync Types"))
	{
		UI.SetEnabled("LBY Modes", false)
		UI.SetEnabled("Onshot AA", false)
		UI.SetEnabled("Invert AA", false)
	}
	else
	{
		UI.SetEnabled("LBY Modes", true)
		UI.SetEnabled("Onshot AA", true)
		UI.SetEnabled("Invert AA", true)
	}
	if(UI.GetValue("Onshot AA"))
	{
		UI.SetEnabled("LBY on Shot", true)
	}
	else
	{
		UI.SetEnabled("LBY on Shot", false)
	}
	if(UI.GetValue("Noscope Hitchance"))
	{
		UI.SetEnabled("Script items", "Hitchance", true)
	}
	else
	{
		UI.SetEnabled("Script items", "Hitchance", false)
	}
	if(lbyMode == 6)
	{
		UI.SetEnabled("LBY jitter speed (seconds)", true)
		UI.SetEnabled("Min LBY 1", true)
		UI.SetEnabled("Max LBY 1", true)
		UI.SetEnabled("Min LBY 2", true)
		UI.SetEnabled("Max LBY 2", true)
	}
	else
	{
		UI.SetEnabled("LBY jitter speed (seconds)", false)
		UI.SetEnabled("Min LBY 1", false)
		UI.SetEnabled("Max LBY 1", false)
		UI.SetEnabled("Min LBY 2", false)
		UI.SetEnabled("Max LBY 2", false)
	}
	if(realMode == 3)
	{
		UI.SetEnabled("Switch speed (seconds)", true)
		UI.SetEnabled("Jitter range", true)
		UI.SetEnabled("Min Fake 1", true)
		UI.SetEnabled("Max Fake 1", true)
		UI.SetEnabled("Min Fake 2", true)
		UI.SetEnabled("Max Fake 2", true)
	}
	else
	{
		UI.SetEnabled("Switch speed (seconds)", false)
		UI.SetEnabled("Jitter range", false)
		UI.SetEnabled("Min Fake 1", false)
		UI.SetEnabled("Max Fake 1", false)
		UI.SetEnabled("Min Fake 2", false)
		UI.SetEnabled("Max Fake 2", false)
	}
	if(UI.GetValue("Fakelag Types" == 1))
	{
		UI.SetEnable("Send Limit", true)
		UI.SetEnable("Choke Limit", true)
	}
	else
	{
		UI.SetEnable("Send Limit", false)
		UI.SetEnable("Choke Limit", false)
	}
}


function unloadReset()
{
	AntiAim.SetOverride(0);
}
Cheat.RegisterCallback("Unload", "unloadReset")
Cheat.RegisterCallback("round_start", "roundstart")
Cheat.RegisterCallback("CreateMove", "fakelag")
Cheat.RegisterCallback("weapon_fire", "fire")
Cheat.RegisterCallback("CreateMove", "commandHandler")
Cheat.RegisterCallback("CreateMove", "ragebotFeatures")
Cheat.RegisterCallback("CreateMove", "lbyModes")
Cheat.RegisterCallback("CreateMove", "setOffsets")
Cheat.RegisterCallback("Draw", "menu")