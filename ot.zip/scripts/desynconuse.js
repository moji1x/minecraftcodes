cachedYawOffset = undefined; VK_E = 69; // nice
var localplayer = Entity.GetLocalPlayer();
var localplayer_world_pos = Entity.GetRenderOrigin(localplayer);

UI.AddCheckbox("Desync on use");

function distanceVector(v1, v2) {
    var
        _v3 = v1[0x0] - v2[0x0],
        __v3 = v1[0x1] - v2[0x1],
        ___v3 = v1[0x2] - v2[0x2];
    return Math.sqrt(_v3 * _v3 + __v3 * __v3 + ___v3 * ___v3);
}

function DesyncOnUse() {
    if (!UI.GetValue("Desync on use")) return;
    if (!Entity.IsValid(localplayer)) return;
    var m_iTeamNum = Entity.GetProp(localplayer, 'CBaseEntity', 'm_iTeamNum');
    if (m_iTeamNum == 2 && Entity.GetName(Entity.GetWeapon(localplayer)) == 'c4 explosive') {
        Cheat.ExecuteCommand('bind e +use');
        return;
    }
    if (!cachedYawOffset) {
        cachedYawOffset = UI.GetValue("Anti-Aim", "Rage Anti-Aim", "Yaw offset");
    }

    var entity_list = Entity.GetEntities(),
        enemy_list,
        distance_from_enemy = Number.MAX_SAFE_INTEGER;
    for (i = 1; i < entity_list.length; i++) {
        if (Entity.GetClassID(entity_list[i]) == 97) {
            if (distance_from_enemy > distanceVector(Entity.GetRenderOrigin(entity_list[i]), Entity.GetRenderOrigin(localplayer))) {
                distance_from_enemy = distanceVector(Entity.GetRenderOrigin(entity_list[i]), Entity.GetRenderOrigin(localplayer));
            }
        }

        if (Entity.GetClassID(entity_list[i]) == 80) {
            enemy_list = entity_list[i];
            break;
        }
    }
    if (distance_from_enemy != Number.MAX_SAFE_INTEGER) {
        if (distance_from_enemy <= 65) {
            Cheat.ExecuteCommand('bind e +use'), Cheat.Print('Here');
            return;
        }
    }
    if (enemy_list != undefined) {
        var world = Entity.GetRenderOrigin(enemy_list), v3 = distanceVector(world, Entity.GetRenderOrigin(localplayer));
        if (v3 <= 65) {
            Cheat.ExecuteCommand('bind e +use');
            return;
        }
    }


    if (Input.IsKeyPressed(VK_E)) {
        UI.SetValue("Restrictions", 0);
        UI.SetValue("Anti-Aim", "Extra", "Pitch", 0);
        Cheat.ExecuteCommand('unbind e'), Cheat.ExecuteCommand('-use');
        UI.SetValue("Anti-Aim", "Rage Anti-Aim", "Yaw offset", 180);
    }
    else
    {
        Cheat.ExecuteCommand('bind e +use');
        UI.SetValue("Restrictions", 1);
        if (cachedYawOffset != undefined) {
            UI.SetValue("Anti-Aim", "Rage Anti-Aim", "Yaw offset", cachedYawOffset);
            cachedYawOffset = undefined;
        }
    }
}
Cheat.RegisterCallback("CreateMove", "DesyncOnUse");

// credit whoever fuck was writing hvh ess.js because i stole source from there
// Monotonized#6495