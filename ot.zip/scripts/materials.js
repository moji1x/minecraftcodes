var materials = [

["Default",'vgui/white'],
["Adidas",'models/inventory_items/music_kit/darude_01/mp3_detail'],
["Glowy Thing",'vgui/achievements/glow'],
["Fishing Net","models/props_shacks/fishing_net01"],
["Tree Thingy","models/props_foliage/urban_tree03_branches"],
["Cool Glow","models/inventory_items/dreamhack_trophies/dreamhack_star_blur"],
["Cool Glow 2",'models/inventory_items/dogtags/dogtags_lightray'],
["Dogtags",'models/inventory_items/dogtags/dogtags'],
["Blood",'effects/blood_gore'],
["Roof XDXDXDXD",'tile/infroofa'],
["Water","liquids/water_noise"],
["Fire :fire:","effects/fire_cloud1"],
["Bubble","effects/bubble"],
["Flare","effects/redflare"],
["Splash","effects/splash1"],
["Tesla Glow","effects/tesla_glow"],
["Blood","effects/blood_gore"],
["Tesla Glow","effects/tesla_glow"],

]
exports.materials = materials;